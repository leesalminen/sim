-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 29, 2015 at 07:01 PM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `ss_ts_simline`
--

-- --------------------------------------------------------

--
-- Table structure for table `AboutPage`
--

CREATE TABLE IF NOT EXISTS `AboutPage` (
`ID` int(11) NOT NULL,
  `PersonEnable` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `PersonHeading` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `TestimonialEnable` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `TestimonialHeading` varchar(50) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `AboutPage`
--

INSERT INTO `AboutPage` (`ID`, `PersonEnable`, `PersonHeading`, `TestimonialEnable`, `TestimonialHeading`) VALUES
(2, 1, 'Meet Our Team', 1, 'Client Feedback');

-- --------------------------------------------------------

--
-- Table structure for table `AboutPage_Live`
--

CREATE TABLE IF NOT EXISTS `AboutPage_Live` (
`ID` int(11) NOT NULL,
  `PersonEnable` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `PersonHeading` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `TestimonialEnable` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `TestimonialHeading` varchar(50) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `AboutPage_Live`
--

INSERT INTO `AboutPage_Live` (`ID`, `PersonEnable`, `PersonHeading`, `TestimonialEnable`, `TestimonialHeading`) VALUES
(2, 1, 'Meet Our Team', 1, 'Client Feedback');

-- --------------------------------------------------------

--
-- Table structure for table `AboutPage_Testimonials`
--

CREATE TABLE IF NOT EXISTS `AboutPage_Testimonials` (
`ID` int(11) NOT NULL,
  `AboutPageID` int(11) NOT NULL DEFAULT '0',
  `TestimonialID` int(11) NOT NULL DEFAULT '0',
  `SortOrder` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `AboutPage_Testimonials`
--

INSERT INTO `AboutPage_Testimonials` (`ID`, `AboutPageID`, `TestimonialID`, `SortOrder`) VALUES
(1, 2, 1, 2),
(2, 2, 3, 1),
(3, 2, 2, 3),
(4, 2, 4, 4);

-- --------------------------------------------------------

--
-- Table structure for table `AboutPage_versions`
--

CREATE TABLE IF NOT EXISTS `AboutPage_versions` (
`ID` int(11) NOT NULL,
  `RecordID` int(11) NOT NULL DEFAULT '0',
  `Version` int(11) NOT NULL DEFAULT '0',
  `PersonEnable` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `PersonHeading` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `TestimonialEnable` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `TestimonialHeading` varchar(50) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=33 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `AboutPage_versions`
--

INSERT INTO `AboutPage_versions` (`ID`, `RecordID`, `Version`, `PersonEnable`, `PersonHeading`, `TestimonialEnable`, `TestimonialHeading`) VALUES
(31, 2, 37, 1, 'Meet Our Team', 1, 'Client Feedback'),
(32, 2, 38, 1, 'Meet Our Team', 1, 'Client Feedback'),
(3, 2, 9, 0, 'Meet Our Team', 0, NULL),
(4, 2, 10, 1, 'Meet Our Team', 0, NULL),
(30, 2, 36, 1, 'Meet Our Team', 1, 'Client Feedback');

-- --------------------------------------------------------

--
-- Table structure for table `ArchiveWidget`
--

CREATE TABLE IF NOT EXISTS `ArchiveWidget` (
`ID` int(11) NOT NULL,
  `DisplayMode` varchar(50) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `BannerSlider`
--

CREATE TABLE IF NOT EXISTS `BannerSlider` (
`ID` int(11) NOT NULL,
  `ClassName` enum('BannerSlider') CHARACTER SET utf8 DEFAULT 'BannerSlider',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `Title` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `SubTitle` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Content` mediumtext CHARACTER SET utf8,
  `SortOrder` int(11) NOT NULL DEFAULT '0',
  `Buttons` mediumtext CHARACTER SET utf8,
  `Lists` mediumtext CHARACTER SET utf8,
  `ImageID` int(11) NOT NULL DEFAULT '0',
  `PageID` int(11) NOT NULL DEFAULT '0',
  `Align` enum('left','center','right') CHARACTER SET utf8 DEFAULT 'left'
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `BannerSlider`
--

INSERT INTO `BannerSlider` (`ID`, `ClassName`, `Created`, `LastEdited`, `Title`, `SubTitle`, `Content`, `SortOrder`, `Buttons`, `Lists`, `ImageID`, `PageID`, `Align`) VALUES
(1, 'BannerSlider', '2015-03-08 17:17:12', '2015-03-08 17:19:15', 'SimLine', 'Premium Bootstrap template', 'Powerful responsive theme great for corporate websites, web & mobile apps. Built with Bootstrap 3, it combines all of its great features with our clean user-friendly layout. ', 1, NULL, NULL, 35, 1, 'center'),
(2, 'BannerSlider', '2015-03-08 17:18:47', '2015-03-08 17:26:26', 'Fully responsive design', 'Looks great on all major browsers, tablets and phones ', ' Easily and efficiently scales your websites and applications with a single code base, from phones to tablets to desktops with CSS media queries.', 2, '{"scenario":"bannerslide_button","enable":true,"heading":"","items":{"map4ag":{"Text":"Purchase","Link":"http://themestripe.com","LinkBehaviour":"3","HTMLClass":"btn-red fadeInUpBig","IconClass":"fa fa-shopping-cart"},"utl68r":{"Text":"Read more","Link":"#","LinkBehaviour":"0","HTMLClass":"btn-default slideInRight","IconClass":""}}}', NULL, 36, 1, 'left'),
(3, 'BannerSlider', '2015-03-08 17:23:03', '2015-03-08 17:23:03', 'List of items without heading & text', NULL, NULL, 3, NULL, '{"scenario":"bannerslide_list","enable":true,"heading":"","items":{"yu17xf":{"Text":" Proudly built with Twitter Bootstrap 3x","HTMLClass":"slideInLeft kf-black","IconClass":"fa fa-check"},"systx5":{"Text":"15+ easy to customize templates","HTMLClass":"slideInLeft kf-black","IconClass":"fa fa-check"},"rl1gae":{"Text":"LESS files included","HTMLClass":"slideInLeft kf-black","IconClass":"fa fa-check"},"gshjm8":{"Text":"Powerful multi-purpose HTML5 template","HTMLClass":"fadeInUp kf-red kf-divider","IconClass":""},"tj6rgy":{"Text":"That works out of the box","HTMLClass":"fadeInUp kf-red","IconClass":""}}}', 37, 1, 'right');

-- --------------------------------------------------------

--
-- Table structure for table `Blog`
--

CREATE TABLE IF NOT EXISTS `Blog` (
`ID` int(11) NOT NULL,
  `PostsPerPage` int(11) NOT NULL DEFAULT '0',
  `ParentID` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Blog`
--

INSERT INTO `Blog` (`ID`, `PostsPerPage`, `ParentID`) VALUES
(4, 30, 0);

-- --------------------------------------------------------

--
-- Table structure for table `BlogArchiveWidget`
--

CREATE TABLE IF NOT EXISTS `BlogArchiveWidget` (
`ID` int(11) NOT NULL,
  `NumberToDisplay` int(11) NOT NULL DEFAULT '0',
  `ArchiveType` enum('Monthly','Yearly') CHARACTER SET utf8 DEFAULT 'Monthly',
  `BlogID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `BlogCategoriesWidget`
--

CREATE TABLE IF NOT EXISTS `BlogCategoriesWidget` (
`ID` int(11) NOT NULL,
  `BlogID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `BlogCategoriesWidget`
--

INSERT INTO `BlogCategoriesWidget` (`ID`, `BlogID`) VALUES
(4, 4);

-- --------------------------------------------------------

--
-- Table structure for table `BlogCategory`
--

CREATE TABLE IF NOT EXISTS `BlogCategory` (
`ID` int(11) NOT NULL,
  `ClassName` enum('BlogCategory') CHARACTER SET utf8 DEFAULT 'BlogCategory',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `Title` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `SortOrder` int(11) NOT NULL DEFAULT '0',
  `PageID` int(11) NOT NULL DEFAULT '0',
  `URLSegment` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `BlogID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `BlogCategory`
--

INSERT INTO `BlogCategory` (`ID`, `ClassName`, `Created`, `LastEdited`, `Title`, `SortOrder`, `PageID`, `URLSegment`, `BlogID`) VALUES
(1, 'BlogCategory', '2015-03-18 20:57:27', '2015-03-18 20:57:27', 'Blog category #1', 0, 0, 'blog-category-1', 4),
(2, 'BlogCategory', '2015-03-18 20:57:38', '2015-03-18 20:57:38', 'Blog category #2', 0, 0, 'blog-category-2', 4),
(3, 'BlogCategory', '2015-03-18 20:57:54', '2015-03-18 20:57:54', 'Blog category #3', 0, 0, 'blog-category-3', 4);

-- --------------------------------------------------------

--
-- Table structure for table `BlogCategory_Entries`
--

CREATE TABLE IF NOT EXISTS `BlogCategory_Entries` (
`ID` int(11) NOT NULL,
  `BlogCategoryID` int(11) NOT NULL DEFAULT '0',
  `BlogEntryID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `BlogEntry`
--

CREATE TABLE IF NOT EXISTS `BlogEntry` (
`ID` int(11) NOT NULL,
  `Date` datetime DEFAULT NULL,
  `Author` mediumtext CHARACTER SET utf8,
  `Tags` mediumtext CHARACTER SET utf8,
  `Hits` int(11) NOT NULL DEFAULT '0',
  `Featured` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `VideoURL` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `AuthorID` int(11) NOT NULL DEFAULT '0',
  `ThumbnailID` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `BlogEntry`
--

INSERT INTO `BlogEntry` (`ID`, `Date`, `Author`, `Tags`, `Hits`, `Featured`, `VideoURL`, `AuthorID`, `ThumbnailID`) VALUES
(5, '2015-01-26 04:46:26', NULL, 'silverstripe, blog', 0, 0, NULL, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `BlogEntryWidget`
--

CREATE TABLE IF NOT EXISTS `BlogEntryWidget` (
`ID` int(11) NOT NULL,
  `Limit` int(11) NOT NULL DEFAULT '0',
  `SortBy` enum('newest','popular','random') CHARACTER SET utf8 DEFAULT 'newest',
  `Featured` tinyint(1) unsigned NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `BlogEntryWidget`
--

INSERT INTO `BlogEntryWidget` (`ID`, `Limit`, `SortBy`, `Featured`) VALUES
(5, 6, 'popular', 0);

-- --------------------------------------------------------

--
-- Table structure for table `BlogEntry_Live`
--

CREATE TABLE IF NOT EXISTS `BlogEntry_Live` (
`ID` int(11) NOT NULL,
  `Date` datetime DEFAULT NULL,
  `Author` mediumtext CHARACTER SET utf8,
  `Tags` mediumtext CHARACTER SET utf8,
  `Hits` int(11) NOT NULL DEFAULT '0',
  `Featured` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `VideoURL` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `AuthorID` int(11) NOT NULL DEFAULT '0',
  `ThumbnailID` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `BlogEntry_Live`
--

INSERT INTO `BlogEntry_Live` (`ID`, `Date`, `Author`, `Tags`, `Hits`, `Featured`, `VideoURL`, `AuthorID`, `ThumbnailID`) VALUES
(5, '2015-01-26 04:46:26', NULL, 'silverstripe, blog', 0, 0, NULL, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `BlogEntry_versions`
--

CREATE TABLE IF NOT EXISTS `BlogEntry_versions` (
`ID` int(11) NOT NULL,
  `RecordID` int(11) NOT NULL DEFAULT '0',
  `Version` int(11) NOT NULL DEFAULT '0',
  `Date` datetime DEFAULT NULL,
  `Author` mediumtext CHARACTER SET utf8,
  `Tags` mediumtext CHARACTER SET utf8,
  `Hits` int(11) NOT NULL DEFAULT '0',
  `Featured` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `VideoURL` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `AuthorID` int(11) NOT NULL DEFAULT '0',
  `ThumbnailID` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `BlogHolder`
--

CREATE TABLE IF NOT EXISTS `BlogHolder` (
`ID` int(11) NOT NULL,
  `AllowCustomAuthors` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ShowFullEntry` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `OwnerID` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `BlogHolder`
--

INSERT INTO `BlogHolder` (`ID`, `AllowCustomAuthors`, `ShowFullEntry`, `OwnerID`) VALUES
(4, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `BlogHolder_Live`
--

CREATE TABLE IF NOT EXISTS `BlogHolder_Live` (
`ID` int(11) NOT NULL,
  `AllowCustomAuthors` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ShowFullEntry` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `OwnerID` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `BlogHolder_Live`
--

INSERT INTO `BlogHolder_Live` (`ID`, `AllowCustomAuthors`, `ShowFullEntry`, `OwnerID`) VALUES
(4, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `BlogHolder_versions`
--

CREATE TABLE IF NOT EXISTS `BlogHolder_versions` (
`ID` int(11) NOT NULL,
  `RecordID` int(11) NOT NULL DEFAULT '0',
  `Version` int(11) NOT NULL DEFAULT '0',
  `AllowCustomAuthors` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ShowFullEntry` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `OwnerID` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `BlogPost`
--

CREATE TABLE IF NOT EXISTS `BlogPost` (
`ID` int(11) NOT NULL,
  `PublishDate` datetime DEFAULT NULL,
  `Hits` int(11) NOT NULL DEFAULT '0',
  `Featured` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `VideoURL` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `FeaturedImageID` int(11) NOT NULL DEFAULT '0',
  `AuthorNames` varchar(1024) CHARACTER SET utf8 DEFAULT NULL,
  `Summary` mediumtext CHARACTER SET utf8
) ENGINE=MyISAM AUTO_INCREMENT=30 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `BlogPost`
--

INSERT INTO `BlogPost` (`ID`, `PublishDate`, `Hits`, `Featured`, `VideoURL`, `FeaturedImageID`, `AuthorNames`, `Summary`) VALUES
(5, '2015-01-26 04:46:26', 0, 0, NULL, 0, 'Bill Gates, Steve Jobs', NULL),
(29, '2015-03-18 20:26:57', 0, 0, NULL, 39, 'Tom, Jerry', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `BlogPost_Authors`
--

CREATE TABLE IF NOT EXISTS `BlogPost_Authors` (
`ID` int(11) NOT NULL,
  `BlogPostID` int(11) NOT NULL DEFAULT '0',
  `MemberID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `BlogPost_Authors`
--

INSERT INTO `BlogPost_Authors` (`ID`, `BlogPostID`, `MemberID`) VALUES
(1, 5, 1),
(2, 29, 1);

-- --------------------------------------------------------

--
-- Table structure for table `BlogPost_Categories`
--

CREATE TABLE IF NOT EXISTS `BlogPost_Categories` (
`ID` int(11) NOT NULL,
  `BlogPostID` int(11) NOT NULL DEFAULT '0',
  `BlogCategoryID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `BlogPost_Categories`
--

INSERT INTO `BlogPost_Categories` (`ID`, `BlogPostID`, `BlogCategoryID`) VALUES
(1, 29, 1),
(2, 29, 2),
(3, 29, 3);

-- --------------------------------------------------------

--
-- Table structure for table `BlogPost_Live`
--

CREATE TABLE IF NOT EXISTS `BlogPost_Live` (
`ID` int(11) NOT NULL,
  `PublishDate` datetime DEFAULT NULL,
  `Hits` int(11) NOT NULL DEFAULT '0',
  `Featured` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `VideoURL` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `FeaturedImageID` int(11) NOT NULL DEFAULT '0',
  `AuthorNames` varchar(1024) CHARACTER SET utf8 DEFAULT NULL,
  `Summary` mediumtext CHARACTER SET utf8
) ENGINE=MyISAM AUTO_INCREMENT=30 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `BlogPost_Live`
--

INSERT INTO `BlogPost_Live` (`ID`, `PublishDate`, `Hits`, `Featured`, `VideoURL`, `FeaturedImageID`, `AuthorNames`, `Summary`) VALUES
(5, '2015-01-26 04:46:26', 0, 0, NULL, 0, 'Bill Gates, Steve Jobs', NULL),
(29, '2015-03-18 20:26:57', 0, 0, NULL, 39, 'Tom, Jerry', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `BlogPost_Tags`
--

CREATE TABLE IF NOT EXISTS `BlogPost_Tags` (
`ID` int(11) NOT NULL,
  `BlogPostID` int(11) NOT NULL DEFAULT '0',
  `BlogTagID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `BlogPost_Tags`
--

INSERT INTO `BlogPost_Tags` (`ID`, `BlogPostID`, `BlogTagID`) VALUES
(1, 5, 1),
(2, 5, 2),
(3, 29, 1),
(4, 29, 2);

-- --------------------------------------------------------

--
-- Table structure for table `BlogPost_versions`
--

CREATE TABLE IF NOT EXISTS `BlogPost_versions` (
`ID` int(11) NOT NULL,
  `RecordID` int(11) NOT NULL DEFAULT '0',
  `Version` int(11) NOT NULL DEFAULT '0',
  `PublishDate` datetime DEFAULT NULL,
  `Hits` int(11) NOT NULL DEFAULT '0',
  `Featured` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `VideoURL` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `FeaturedImageID` int(11) NOT NULL DEFAULT '0',
  `AuthorNames` varchar(1024) CHARACTER SET utf8 DEFAULT NULL,
  `Summary` mediumtext CHARACTER SET utf8
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `BlogPost_versions`
--

INSERT INTO `BlogPost_versions` (`ID`, `RecordID`, `Version`, `PublishDate`, `Hits`, `Featured`, `VideoURL`, `FeaturedImageID`, `AuthorNames`, `Summary`) VALUES
(1, 5, 3, '2015-01-26 04:46:26', 0, 0, NULL, 0, NULL, NULL),
(2, 5, 4, '2015-01-26 04:46:26', 0, 0, NULL, 0, NULL, NULL),
(3, 5, 5, '2015-01-26 04:46:26', 0, 0, NULL, 0, 'Bill Gates, Steve Jobs', NULL),
(4, 29, 1, '2015-03-18 20:25:32', 0, 0, NULL, 0, NULL, NULL),
(5, 29, 2, '2015-03-18 20:25:32', 0, 0, NULL, 39, NULL, NULL),
(6, 29, 3, '2015-03-18 20:26:57', 0, 0, NULL, 39, NULL, NULL),
(7, 29, 4, '2015-03-18 20:26:57', 0, 0, NULL, 39, 'Tom, Jerry', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `BlogRecentPostsWidget`
--

CREATE TABLE IF NOT EXISTS `BlogRecentPostsWidget` (
`ID` int(11) NOT NULL,
  `NumberOfPosts` int(11) NOT NULL DEFAULT '0',
  `BlogID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `BlogTag`
--

CREATE TABLE IF NOT EXISTS `BlogTag` (
`ID` int(11) NOT NULL,
  `ClassName` enum('BlogTag') CHARACTER SET utf8 DEFAULT 'BlogTag',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `Title` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `URLSegment` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `BlogID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `BlogTag`
--

INSERT INTO `BlogTag` (`ID`, `ClassName`, `Created`, `LastEdited`, `Title`, `URLSegment`, `BlogID`) VALUES
(1, 'BlogTag', '2015-03-13 16:39:41', '2015-03-13 16:39:41', 'silverstripe', 'silverstripe', 4),
(2, 'BlogTag', '2015-03-13 16:39:41', '2015-03-13 16:39:41', 'blog', 'blog', 4);

-- --------------------------------------------------------

--
-- Table structure for table `BlogTagsWidget`
--

CREATE TABLE IF NOT EXISTS `BlogTagsWidget` (
`ID` int(11) NOT NULL,
  `BlogID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `BlogTree`
--

CREATE TABLE IF NOT EXISTS `BlogTree` (
`ID` int(11) NOT NULL,
  `Name` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `LandingPageFreshness` varchar(50) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `BlogTree`
--

INSERT INTO `BlogTree` (`ID`, `Name`, `LandingPageFreshness`) VALUES
(4, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `BlogTree_Live`
--

CREATE TABLE IF NOT EXISTS `BlogTree_Live` (
`ID` int(11) NOT NULL,
  `Name` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `LandingPageFreshness` varchar(50) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `BlogTree_Live`
--

INSERT INTO `BlogTree_Live` (`ID`, `Name`, `LandingPageFreshness`) VALUES
(4, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `BlogTree_versions`
--

CREATE TABLE IF NOT EXISTS `BlogTree_versions` (
`ID` int(11) NOT NULL,
  `RecordID` int(11) NOT NULL DEFAULT '0',
  `Version` int(11) NOT NULL DEFAULT '0',
  `Name` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `LandingPageFreshness` varchar(50) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Blog_Contributors`
--

CREATE TABLE IF NOT EXISTS `Blog_Contributors` (
`ID` int(11) NOT NULL,
  `BlogID` int(11) NOT NULL DEFAULT '0',
  `MemberID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Blog_Editors`
--

CREATE TABLE IF NOT EXISTS `Blog_Editors` (
`ID` int(11) NOT NULL,
  `BlogID` int(11) NOT NULL DEFAULT '0',
  `MemberID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Blog_Live`
--

CREATE TABLE IF NOT EXISTS `Blog_Live` (
`ID` int(11) NOT NULL,
  `PostsPerPage` int(11) NOT NULL DEFAULT '0',
  `ParentID` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Blog_Live`
--

INSERT INTO `Blog_Live` (`ID`, `PostsPerPage`, `ParentID`) VALUES
(4, 30, 0);

-- --------------------------------------------------------

--
-- Table structure for table `Blog_versions`
--

CREATE TABLE IF NOT EXISTS `Blog_versions` (
`ID` int(11) NOT NULL,
  `RecordID` int(11) NOT NULL DEFAULT '0',
  `Version` int(11) NOT NULL DEFAULT '0',
  `PostsPerPage` int(11) NOT NULL DEFAULT '0',
  `ParentID` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Blog_versions`
--

INSERT INTO `Blog_versions` (`ID`, `RecordID`, `Version`, `PostsPerPage`, `ParentID`) VALUES
(2, 4, 3, 0, 0),
(3, 4, 4, 0, 0),
(4, 4, 5, 1, 0),
(5, 4, 6, 30, 0);

-- --------------------------------------------------------

--
-- Table structure for table `Blog_Writers`
--

CREATE TABLE IF NOT EXISTS `Blog_Writers` (
`ID` int(11) NOT NULL,
  `BlogID` int(11) NOT NULL DEFAULT '0',
  `MemberID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Box`
--

CREATE TABLE IF NOT EXISTS `Box` (
`ID` int(11) NOT NULL,
  `ClassName` enum('Box') CHARACTER SET utf8 DEFAULT 'Box',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `Title` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `HTMLClass` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Content` mediumtext CHARACTER SET utf8,
  `Link` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `LinkBehaviour` int(11) NOT NULL DEFAULT '0',
  `SortOrder` int(11) NOT NULL DEFAULT '0',
  `CategoryID` int(11) NOT NULL DEFAULT '0',
  `LinkedPageID` int(11) NOT NULL DEFAULT '0',
  `PageID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Box`
--

INSERT INTO `Box` (`ID`, `ClassName`, `Created`, `LastEdited`, `Title`, `HTMLClass`, `Content`, `Link`, `LinkBehaviour`, `SortOrder`, `CategoryID`, `LinkedPageID`, `PageID`) VALUES
(1, 'Box', '2015-01-28 18:32:01', '2015-01-28 18:46:18', 'Built With Bootstrap 3', 'fa fa-gears', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam id ipsum varius, tincidunt odio nec, placerat enim. ', 'http://getbootstrap.com/', 3, 1, 0, 8, 1),
(2, 'Box', '2015-01-28 18:33:57', '2015-01-28 18:33:57', 'Responsive Design', 'fa fa-arrows-alt', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam id ipsum varius, tincidunt odio nec, placerat enim. ', NULL, 0, 2, 0, 0, 1),
(3, 'Box', '2015-01-28 18:34:23', '2015-01-28 18:34:23', 'Easy to Customize', 'fa fa-refresh', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam id ipsum varius, tincidunt odio nec, placerat enim. ', NULL, 0, 3, 0, 0, 1),
(4, 'Box', '2015-01-28 18:34:52', '2015-01-28 18:37:17', 'Member Profiles', 'fa fa-user', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam id ipsum varius, tincidunt odio nec, placerat enim. ', NULL, 0, 4, 0, 0, 1),
(5, 'Box', '2015-01-28 18:35:20', '2015-01-28 18:35:20', '24/7 Support', 'fa fa-envelope-o', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam id ipsum varius, tincidunt odio nec, placerat enim. ', NULL, 0, 5, 0, 0, 1),
(6, 'Box', '2015-01-28 18:36:05', '2015-01-28 18:36:05', 'Isotope Gallery', 'fa fa-picture-o', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam id ipsum varius, tincidunt odio nec, placerat enim. ', NULL, 0, 6, 0, 0, 1),
(7, 'Box', '2015-03-17 18:14:28', '2015-03-17 18:25:03', ' Built With Bootstrap 3', 'fa fa-gears', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam id ipsum varius, tincidunt odio nec, placerat enim. ', 'http://getbootstrap.com/', 3, 7, 0, 0, 20),
(8, 'Box', '2015-03-17 18:15:28', '2015-03-17 18:15:28', ' Responsive Design', 'fa fa-arrows-alt', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam id ipsum varius, tincidunt odio nec, placerat enim. ', NULL, 0, 8, 0, 0, 20),
(9, 'Box', '2015-03-17 18:16:02', '2015-03-17 18:16:02', 'Easy to Customize', 'fa fa-refresh', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam id ipsum varius, tincidunt odio nec, placerat enim. ', NULL, 0, 9, 0, 0, 20),
(10, 'Box', '2015-03-17 18:17:01', '2015-03-17 18:17:01', '15+ Templates Included', 'fa fa-plus', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam id ipsum varius, tincidunt odio nec, placerat enim. ', NULL, 0, 10, 0, 0, 20),
(11, 'Box', '2015-03-17 18:17:25', '2015-03-17 18:17:25', '24/7 Support', 'fa fa-envelope-o', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam id ipsum varius, tincidunt odio nec, placerat enim. ', NULL, 0, 11, 0, 0, 20),
(12, 'Box', '2015-03-17 18:17:51', '2015-03-17 18:17:51', ' Isotope Gallery', 'fa fa-picture-o', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam id ipsum varius, tincidunt odio nec, placerat enim. ', NULL, 0, 12, 0, 0, 20);

-- --------------------------------------------------------

--
-- Table structure for table `Comment`
--

CREATE TABLE IF NOT EXISTS `Comment` (
`ID` int(11) NOT NULL,
  `ClassName` enum('Comment') CHARACTER SET utf8 DEFAULT 'Comment',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `Name` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `Comment` mediumtext CHARACTER SET utf8,
  `Email` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `URL` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `BaseClass` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `Moderated` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `IsSpam` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ParentID` int(11) NOT NULL DEFAULT '0',
  `AllowHtml` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `AuthorID` int(11) NOT NULL DEFAULT '0',
  `SecretToken` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Depth` int(11) NOT NULL DEFAULT '0',
  `ParentCommentID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Comment`
--

INSERT INTO `Comment` (`ID`, `ClassName`, `Created`, `LastEdited`, `Name`, `Comment`, `Email`, `URL`, `BaseClass`, `Moderated`, `IsSpam`, `ParentID`, `AllowHtml`, `AuthorID`, `SecretToken`, `Depth`, `ParentCommentID`) VALUES
(1, 'Comment', '2015-03-17 17:06:25', '2015-05-11 21:35:28', 'Hattori Suzuki', 'Nulla non convallis urna, lacinia mollis massa. Nam consequat tristique felis a egestas.', 'hatinhx@gmail.com', 'Google.com', 'SiteTree', 1, 0, 22, 0, 0, '1c5c1df9b582c27a0ed5ff173497374a25865c2c5396edd6a1b8caccb7a96e9c', 1, 0),
(2, 'Comment', '2015-03-18 21:52:11', '2015-05-11 21:11:56', 'Default Admin', 'Hello world', 'admin@themestripe.com', NULL, 'SiteTree', 1, 0, 29, 0, 1, '63cfaca175412a23560044cc8293afc898aaf908bfe42a96334c6d70b8798676', 1, 0),
(3, 'Comment', '2015-03-18 21:53:41', '2015-05-11 21:11:56', 'Default Admin', 'Suspendisse id elit felis, non condimentum mauris. Nullam ullamcorper volutpat urna vel feugiat.', 'admin@themestripe.com', NULL, 'SiteTree', 1, 0, 29, 0, 1, '8e529ce628af849bff1f68c3228c9bca7e11ca528eb19cc6c8be98b88158badf', 1, 0),
(4, 'Comment', '2015-03-18 22:14:51', '2015-05-11 21:11:56', 'Hattori', 'Quisque mollis, odio sed fringilla rutrum, elit ipsum adipiscing turpis, sit amet mollis purus neque sed nibh. Donec vitae arcu lorem. Suspendisse id elit felis, non condimentum mauris. Nullam ullamcorper volutpat urna vel feugiat.', 'hattori@suzukicorp.com', 'http://micro.soft', 'SiteTree', 1, 0, 29, 0, 0, '0cf099db32675fb9fe7eee822265940d46ffc05bd644de674b7bb4fe6b178753', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `ContactAttribute`
--

CREATE TABLE IF NOT EXISTS `ContactAttribute` (
`ID` int(11) NOT NULL,
  `ClassName` enum('ContactAttribute') CHARACTER SET utf8 DEFAULT 'ContactAttribute',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `Title` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Value` mediumtext CHARACTER SET utf8,
  `HTMLClass` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `PageID` int(11) NOT NULL DEFAULT '0',
  `SortOrder` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ContactAttribute`
--

INSERT INTO `ContactAttribute` (`ID`, `ClassName`, `Created`, `LastEdited`, `Title`, `Value`, `HTMLClass`, `PageID`, `SortOrder`) VALUES
(1, 'ContactAttribute', '2015-03-14 12:09:17', '2015-03-14 12:10:08', 'Hello', 'world', 'btn-abc', 3, 2),
(2, 'ContactAttribute', '2015-03-14 12:10:08', '2015-03-14 12:10:08', 'adasda', 'defdefe', 'efesrwer', 3, 1);

-- --------------------------------------------------------

--
-- Table structure for table `ContactPage`
--

CREATE TABLE IF NOT EXISTS `ContactPage` (
`ID` int(11) NOT NULL,
  `EmbedMapURL` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Attributes` mediumtext CHARACTER SET utf8,
  `OnCompleteHeading` varchar(255) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ContactPage`
--

INSERT INTO `ContactPage` (`ID`, `EmbedMapURL`, `Attributes`, `OnCompleteHeading`) VALUES
(3, 'http://goo.gl/EkQmZy', '{"scenario":"contact_attribute","enable":true,"heading":"Contact Info","items":{"xluy58":{"Label":"Address:","Value":"San Francisco, CA 94101 <br/> 1987 Lincoln Street","IconClass":"fa fa-map-marker"},"uqw9nl":{"Label":"Telephone:","Value":"+123456789","IconClass":"fa fa-phone"},"4eu9wo":{"Label":"Fax:","Value":"+123456789","IconClass":"fa fa-fax"},"fbvduh":{"Label":"Twitter:","Value":"https://www.twitter.com/example","IconClass":"fa fa-twitter"}}}', 'Thank you');

-- --------------------------------------------------------

--
-- Table structure for table `ContactPage_Live`
--

CREATE TABLE IF NOT EXISTS `ContactPage_Live` (
`ID` int(11) NOT NULL,
  `EmbedMapURL` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Attributes` mediumtext CHARACTER SET utf8,
  `OnCompleteHeading` varchar(255) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ContactPage_Live`
--

INSERT INTO `ContactPage_Live` (`ID`, `EmbedMapURL`, `Attributes`, `OnCompleteHeading`) VALUES
(3, 'http://goo.gl/EkQmZy', '{"scenario":"contact_attribute","enable":true,"heading":"Contact Info","items":{"xluy58":{"Label":"Address:","Value":"San Francisco, CA 94101 <br/> 1987 Lincoln Street","IconClass":"fa fa-map-marker"},"uqw9nl":{"Label":"Telephone:","Value":"+123456789","IconClass":"fa fa-phone"},"4eu9wo":{"Label":"Fax:","Value":"+123456789","IconClass":"fa fa-fax"},"fbvduh":{"Label":"Twitter:","Value":"https://www.twitter.com/example","IconClass":"fa fa-twitter"}}}', 'Thank you');

-- --------------------------------------------------------

--
-- Table structure for table `ContactPage_versions`
--

CREATE TABLE IF NOT EXISTS `ContactPage_versions` (
`ID` int(11) NOT NULL,
  `RecordID` int(11) NOT NULL DEFAULT '0',
  `Version` int(11) NOT NULL DEFAULT '0',
  `EmbedMapURL` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Attributes` mediumtext CHARACTER SET utf8,
  `OnCompleteHeading` varchar(255) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ContactPage_versions`
--

INSERT INTO `ContactPage_versions` (`ID`, `RecordID`, `Version`, `EmbedMapURL`, `Attributes`, `OnCompleteHeading`) VALUES
(6, 3, 10, NULL, '{"scenario":"contact_attribute","enable":true,"heading":"Contact Info","items":{"xluy58":{"Label":"Address:","Value":"San Francisco, CA 94101 <br/> 1987 Lincoln Street","IconClass":"fa fa-map-marker"},"uqw9nl":{"Label":"Telephone:","Value":"+123456789","IconClass":"fa fa-phone"},"4eu9wo":{"Label":"Fax:","Value":"+123456789","IconClass":"fa fa-fax"},"fbvduh":{"Label":"Twitter:","Value":"https://www.twitter.com/example","IconClass":"fa fa-twitter"}}}', 'Thank you'),
(7, 3, 11, 'http://goo.gl/EkQmZy', '{"scenario":"contact_attribute","enable":true,"heading":"Contact Info","items":{"xluy58":{"Label":"Address:","Value":"San Francisco, CA 94101 <br/> 1987 Lincoln Street","IconClass":"fa fa-map-marker"},"uqw9nl":{"Label":"Telephone:","Value":"+123456789","IconClass":"fa fa-phone"},"4eu9wo":{"Label":"Fax:","Value":"+123456789","IconClass":"fa fa-fax"},"fbvduh":{"Label":"Twitter:","Value":"https://www.twitter.com/example","IconClass":"fa fa-twitter"}}}', 'Thank you'),
(8, 3, 12, 'http://goo.gl/EkQmZy', '{"scenario":"contact_attribute","enable":true,"heading":"Contact Info","items":{"xluy58":{"Label":"Address:","Value":"San Francisco, CA 94101 <br/> 1987 Lincoln Street","IconClass":"fa fa-map-marker"},"uqw9nl":{"Label":"Telephone:","Value":"+123456789","IconClass":"fa fa-phone"},"4eu9wo":{"Label":"Fax:","Value":"+123456789","IconClass":"fa fa-fax"},"fbvduh":{"Label":"Twitter:","Value":"https://www.twitter.com/example","IconClass":"fa fa-twitter"}}}', 'Thank you');

-- --------------------------------------------------------

--
-- Table structure for table `EditableFormField`
--

CREATE TABLE IF NOT EXISTS `EditableFormField` (
`ID` int(11) NOT NULL,
  `ClassName` enum('EditableFormField','EditableSpamProtectionField','EditableCheckbox','EditableCountryDropdownField','EditableDateField','EditableEmailField','EditableFileField','EditableFormHeading','EditableLiteralField','EditableMemberListField','EditableMultipleOptionField','EditableCheckboxGroupField','EditableDropdown','EditableRadioField','EditableNumericField','EditableTextField') CHARACTER SET utf8 DEFAULT 'EditableFormField',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `Name` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `Title` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Default` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `Sort` int(11) NOT NULL DEFAULT '0',
  `Required` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `CustomErrorMessage` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `CustomRules` mediumtext CHARACTER SET utf8,
  `CustomSettings` mediumtext CHARACTER SET utf8,
  `CustomParameter` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `Version` int(11) NOT NULL DEFAULT '0',
  `ParentID` int(11) NOT NULL DEFAULT '0',
  `CustomName` varchar(60) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `EditableFormField`
--

INSERT INTO `EditableFormField` (`ID`, `ClassName`, `Created`, `LastEdited`, `Name`, `Title`, `Default`, `Sort`, `Required`, `CustomErrorMessage`, `CustomRules`, `CustomSettings`, `CustomParameter`, `Version`, `ParentID`, `CustomName`) VALUES
(1, 'EditableTextField', '2015-03-14 17:44:31', '2015-03-16 02:23:25', 'EditableTextField1', 'Full Name', NULL, 1, 1, NULL, 'a:0:{}', 'a:6:{s:10:"ExtraClass";s:0:"";s:10:"RightTitle";s:0:"";s:9:"MinLength";s:0:"";s:9:"MaxLength";s:0:"";s:4:"Rows";s:1:"1";s:10:"ShowOnLoad";s:4:"Show";}', NULL, 7, 3, NULL),
(2, 'EditableEmailField', '2015-03-14 17:44:46', '2015-03-16 02:23:26', 'EditableEmailField2', 'Email', NULL, 2, 1, NULL, 'a:0:{}', 'a:3:{s:10:"ExtraClass";s:0:"";s:10:"RightTitle";s:0:"";s:10:"ShowOnLoad";s:4:"Show";}', NULL, 7, 3, NULL),
(3, 'EditableTextField', '2015-03-14 17:45:04', '2015-03-16 02:23:26', 'EditableTextField3', 'Message', NULL, 3, 1, NULL, 'a:0:{}', 'a:6:{s:10:"ExtraClass";s:0:"";s:10:"RightTitle";s:0:"";s:9:"MinLength";s:0:"";s:9:"MaxLength";s:0:"";s:4:"Rows";s:1:"6";s:10:"ShowOnLoad";s:4:"Show";}', NULL, 7, 3, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `EditableFormField_Live`
--

CREATE TABLE IF NOT EXISTS `EditableFormField_Live` (
`ID` int(11) NOT NULL,
  `ClassName` enum('EditableFormField','EditableSpamProtectionField','EditableCheckbox','EditableCountryDropdownField','EditableDateField','EditableEmailField','EditableFileField','EditableFormHeading','EditableLiteralField','EditableMemberListField','EditableMultipleOptionField','EditableCheckboxGroupField','EditableDropdown','EditableRadioField','EditableNumericField','EditableTextField') CHARACTER SET utf8 DEFAULT 'EditableFormField',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `Name` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `Title` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Default` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `Sort` int(11) NOT NULL DEFAULT '0',
  `Required` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `CustomErrorMessage` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `CustomRules` mediumtext CHARACTER SET utf8,
  `CustomSettings` mediumtext CHARACTER SET utf8,
  `CustomParameter` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `Version` int(11) NOT NULL DEFAULT '0',
  `ParentID` int(11) NOT NULL DEFAULT '0',
  `CustomName` varchar(60) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `EditableFormField_Live`
--

INSERT INTO `EditableFormField_Live` (`ID`, `ClassName`, `Created`, `LastEdited`, `Name`, `Title`, `Default`, `Sort`, `Required`, `CustomErrorMessage`, `CustomRules`, `CustomSettings`, `CustomParameter`, `Version`, `ParentID`, `CustomName`) VALUES
(1, 'EditableTextField', '2015-03-14 17:44:31', '2015-03-16 02:23:26', 'EditableTextField1', 'Full Name', NULL, 1, 1, NULL, 'a:0:{}', 'a:6:{s:10:"ExtraClass";s:0:"";s:10:"RightTitle";s:0:"";s:9:"MinLength";s:0:"";s:9:"MaxLength";s:0:"";s:4:"Rows";s:1:"1";s:10:"ShowOnLoad";s:4:"Show";}', NULL, 7, 3, NULL),
(2, 'EditableEmailField', '2015-03-14 17:44:46', '2015-03-16 02:23:26', 'EditableEmailField2', 'Email', NULL, 2, 1, NULL, 'a:0:{}', 'a:3:{s:10:"ExtraClass";s:0:"";s:10:"RightTitle";s:0:"";s:10:"ShowOnLoad";s:4:"Show";}', NULL, 7, 3, NULL),
(3, 'EditableTextField', '2015-03-14 17:45:04', '2015-03-16 02:23:26', 'EditableTextField3', 'Message', NULL, 3, 1, NULL, 'a:0:{}', 'a:6:{s:10:"ExtraClass";s:0:"";s:10:"RightTitle";s:0:"";s:9:"MinLength";s:0:"";s:9:"MaxLength";s:0:"";s:4:"Rows";s:1:"6";s:10:"ShowOnLoad";s:4:"Show";}', NULL, 7, 3, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `EditableFormField_versions`
--

CREATE TABLE IF NOT EXISTS `EditableFormField_versions` (
`ID` int(11) NOT NULL,
  `RecordID` int(11) NOT NULL DEFAULT '0',
  `Version` int(11) NOT NULL DEFAULT '0',
  `WasPublished` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `AuthorID` int(11) NOT NULL DEFAULT '0',
  `PublisherID` int(11) NOT NULL DEFAULT '0',
  `ClassName` enum('EditableFormField','EditableSpamProtectionField','EditableCheckbox','EditableCountryDropdownField','EditableDateField','EditableEmailField','EditableFileField','EditableFormHeading','EditableLiteralField','EditableMemberListField','EditableMultipleOptionField','EditableCheckboxGroupField','EditableDropdown','EditableRadioField','EditableNumericField','EditableTextField') CHARACTER SET utf8 DEFAULT 'EditableFormField',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `Name` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `Title` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Default` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `Sort` int(11) NOT NULL DEFAULT '0',
  `Required` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `CustomErrorMessage` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `CustomRules` mediumtext CHARACTER SET utf8,
  `CustomSettings` mediumtext CHARACTER SET utf8,
  `CustomParameter` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `ParentID` int(11) NOT NULL DEFAULT '0',
  `CustomName` varchar(60) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `EditableFormField_versions`
--

INSERT INTO `EditableFormField_versions` (`ID`, `RecordID`, `Version`, `WasPublished`, `AuthorID`, `PublisherID`, `ClassName`, `Created`, `LastEdited`, `Name`, `Title`, `Default`, `Sort`, `Required`, `CustomErrorMessage`, `CustomRules`, `CustomSettings`, `CustomParameter`, `ParentID`, `CustomName`) VALUES
(1, 1, 1, 0, 1, 0, 'EditableTextField', '2015-03-14 17:44:31', '2015-03-14 17:44:31', 'EditableTextField0', NULL, NULL, 1, 0, NULL, NULL, NULL, NULL, 3, NULL),
(2, 2, 1, 0, 1, 0, 'EditableEmailField', '2015-03-14 17:44:46', '2015-03-14 17:44:46', 'EditableEmailField0', NULL, NULL, 2, 0, NULL, NULL, NULL, NULL, 3, NULL),
(3, 3, 1, 0, 1, 0, 'EditableTextField', '2015-03-14 17:45:04', '2015-03-14 17:45:04', 'EditableTextField0', NULL, NULL, 3, 0, NULL, NULL, NULL, NULL, 3, NULL),
(4, 1, 2, 1, 1, 1, 'EditableTextField', '2015-03-14 17:44:31', '2015-03-14 17:45:25', 'EditableTextField1', 'Full name', NULL, 1, 1, NULL, 'a:0:{}', 'a:6:{s:10:"ExtraClass";s:0:"";s:10:"RightTitle";s:0:"";s:9:"MinLength";s:0:"";s:9:"MaxLength";s:0:"";s:4:"Rows";s:1:"1";s:10:"ShowOnLoad";s:4:"Show";}', NULL, 3, NULL),
(5, 2, 2, 1, 1, 1, 'EditableEmailField', '2015-03-14 17:44:46', '2015-03-14 17:45:25', 'EditableEmailField2', 'Email', NULL, 2, 1, NULL, 'a:0:{}', 'a:3:{s:10:"ExtraClass";s:0:"";s:10:"RightTitle";s:0:"";s:10:"ShowOnLoad";s:4:"Show";}', NULL, 3, NULL),
(6, 3, 2, 1, 1, 1, 'EditableTextField', '2015-03-14 17:45:04', '2015-03-14 17:45:25', 'EditableTextField3', 'Message', NULL, 3, 1, NULL, 'a:0:{}', 'a:6:{s:10:"ExtraClass";s:0:"";s:10:"RightTitle";s:0:"";s:9:"MinLength";s:0:"";s:9:"MaxLength";s:0:"";s:4:"Rows";s:1:"1";s:10:"ShowOnLoad";s:4:"Show";}', NULL, 3, NULL),
(7, 1, 3, 1, 1, 1, 'EditableTextField', '2015-03-14 17:44:31', '2015-03-14 17:45:35', 'EditableTextField1', 'Full name', NULL, 1, 1, NULL, 'a:0:{}', 'a:6:{s:10:"ExtraClass";s:0:"";s:10:"RightTitle";s:0:"";s:9:"MinLength";s:0:"";s:9:"MaxLength";s:0:"";s:4:"Rows";s:1:"1";s:10:"ShowOnLoad";s:4:"Show";}', NULL, 3, NULL),
(8, 2, 3, 1, 1, 1, 'EditableEmailField', '2015-03-14 17:44:46', '2015-03-14 17:45:35', 'EditableEmailField2', 'Email', NULL, 2, 1, NULL, 'a:0:{}', 'a:3:{s:10:"ExtraClass";s:0:"";s:10:"RightTitle";s:0:"";s:10:"ShowOnLoad";s:4:"Show";}', NULL, 3, NULL),
(9, 3, 3, 1, 1, 1, 'EditableTextField', '2015-03-14 17:45:04', '2015-03-14 17:45:35', 'EditableTextField3', 'Message', NULL, 3, 1, NULL, 'a:0:{}', 'a:6:{s:10:"ExtraClass";s:0:"";s:10:"RightTitle";s:0:"";s:9:"MinLength";s:0:"";s:9:"MaxLength";s:0:"";s:4:"Rows";s:1:"6";s:10:"ShowOnLoad";s:4:"Show";}', NULL, 3, NULL),
(10, 1, 4, 1, 1, 1, 'EditableTextField', '2015-03-14 17:44:31', '2015-03-14 17:46:49', 'EditableTextField1', 'Full name', NULL, 1, 1, NULL, 'a:0:{}', 'a:6:{s:10:"ExtraClass";s:0:"";s:10:"RightTitle";s:0:"";s:9:"MinLength";s:0:"";s:9:"MaxLength";s:0:"";s:4:"Rows";s:1:"1";s:10:"ShowOnLoad";s:4:"Show";}', NULL, 3, NULL),
(11, 2, 4, 1, 1, 1, 'EditableEmailField', '2015-03-14 17:44:46', '2015-03-14 17:46:49', 'EditableEmailField2', 'Email', NULL, 2, 1, NULL, 'a:0:{}', 'a:3:{s:10:"ExtraClass";s:0:"";s:10:"RightTitle";s:0:"";s:10:"ShowOnLoad";s:4:"Show";}', NULL, 3, NULL),
(12, 3, 4, 1, 1, 1, 'EditableTextField', '2015-03-14 17:45:04', '2015-03-14 17:46:49', 'EditableTextField3', 'Message', NULL, 3, 1, NULL, 'a:0:{}', 'a:6:{s:10:"ExtraClass";s:0:"";s:10:"RightTitle";s:0:"";s:9:"MinLength";s:0:"";s:9:"MaxLength";s:0:"";s:4:"Rows";s:1:"6";s:10:"ShowOnLoad";s:4:"Show";}', NULL, 3, NULL),
(13, 1, 5, 1, 1, 1, 'EditableTextField', '2015-03-14 17:44:31', '2015-03-15 05:17:29', 'EditableTextField1', 'Full Name', NULL, 1, 1, NULL, 'a:0:{}', 'a:6:{s:10:"ExtraClass";s:0:"";s:10:"RightTitle";s:0:"";s:9:"MinLength";s:0:"";s:9:"MaxLength";s:0:"";s:4:"Rows";s:1:"1";s:10:"ShowOnLoad";s:4:"Show";}', NULL, 3, NULL),
(14, 2, 5, 1, 1, 1, 'EditableEmailField', '2015-03-14 17:44:46', '2015-03-15 05:17:29', 'EditableEmailField2', 'Email', NULL, 2, 1, NULL, 'a:0:{}', 'a:3:{s:10:"ExtraClass";s:0:"";s:10:"RightTitle";s:0:"";s:10:"ShowOnLoad";s:4:"Show";}', NULL, 3, NULL),
(15, 3, 5, 1, 1, 1, 'EditableTextField', '2015-03-14 17:45:04', '2015-03-15 05:17:29', 'EditableTextField3', 'Message', NULL, 3, 1, NULL, 'a:0:{}', 'a:6:{s:10:"ExtraClass";s:0:"";s:10:"RightTitle";s:0:"";s:9:"MinLength";s:0:"";s:9:"MaxLength";s:0:"";s:4:"Rows";s:1:"6";s:10:"ShowOnLoad";s:4:"Show";}', NULL, 3, NULL),
(16, 1, 6, 1, 1, 1, 'EditableTextField', '2015-03-14 17:44:31', '2015-03-15 05:31:48', 'EditableTextField1', 'Full Name', NULL, 1, 1, NULL, 'a:0:{}', 'a:6:{s:10:"ExtraClass";s:0:"";s:10:"RightTitle";s:0:"";s:9:"MinLength";s:0:"";s:9:"MaxLength";s:0:"";s:4:"Rows";s:1:"1";s:10:"ShowOnLoad";s:4:"Show";}', NULL, 3, NULL),
(17, 2, 6, 1, 1, 1, 'EditableEmailField', '2015-03-14 17:44:46', '2015-03-15 05:31:48', 'EditableEmailField2', 'Email', NULL, 2, 1, NULL, 'a:0:{}', 'a:3:{s:10:"ExtraClass";s:0:"";s:10:"RightTitle";s:0:"";s:10:"ShowOnLoad";s:4:"Show";}', NULL, 3, NULL),
(18, 3, 6, 1, 1, 1, 'EditableTextField', '2015-03-14 17:45:04', '2015-03-15 05:31:48', 'EditableTextField3', 'Message', NULL, 3, 1, NULL, 'a:0:{}', 'a:6:{s:10:"ExtraClass";s:0:"";s:10:"RightTitle";s:0:"";s:9:"MinLength";s:0:"";s:9:"MaxLength";s:0:"";s:4:"Rows";s:1:"6";s:10:"ShowOnLoad";s:4:"Show";}', NULL, 3, NULL),
(19, 1, 7, 1, 1, 1, 'EditableTextField', '2015-03-14 17:44:31', '2015-03-16 02:23:25', 'EditableTextField1', 'Full Name', NULL, 1, 1, NULL, 'a:0:{}', 'a:6:{s:10:"ExtraClass";s:0:"";s:10:"RightTitle";s:0:"";s:9:"MinLength";s:0:"";s:9:"MaxLength";s:0:"";s:4:"Rows";s:1:"1";s:10:"ShowOnLoad";s:4:"Show";}', NULL, 3, NULL),
(20, 2, 7, 1, 1, 1, 'EditableEmailField', '2015-03-14 17:44:46', '2015-03-16 02:23:26', 'EditableEmailField2', 'Email', NULL, 2, 1, NULL, 'a:0:{}', 'a:3:{s:10:"ExtraClass";s:0:"";s:10:"RightTitle";s:0:"";s:10:"ShowOnLoad";s:4:"Show";}', NULL, 3, NULL),
(21, 3, 7, 1, 1, 1, 'EditableTextField', '2015-03-14 17:45:04', '2015-03-16 02:23:26', 'EditableTextField3', 'Message', NULL, 3, 1, NULL, 'a:0:{}', 'a:6:{s:10:"ExtraClass";s:0:"";s:10:"RightTitle";s:0:"";s:9:"MinLength";s:0:"";s:9:"MaxLength";s:0:"";s:4:"Rows";s:1:"6";s:10:"ShowOnLoad";s:4:"Show";}', NULL, 3, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `EditableOption`
--

CREATE TABLE IF NOT EXISTS `EditableOption` (
`ID` int(11) NOT NULL,
  `ClassName` enum('EditableOption') CHARACTER SET utf8 DEFAULT 'EditableOption',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `Name` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Title` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Default` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `Sort` int(11) NOT NULL DEFAULT '0',
  `Version` int(11) NOT NULL DEFAULT '0',
  `ParentID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `EditableOption_Live`
--

CREATE TABLE IF NOT EXISTS `EditableOption_Live` (
`ID` int(11) NOT NULL,
  `ClassName` enum('EditableOption') CHARACTER SET utf8 DEFAULT 'EditableOption',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `Name` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Title` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Default` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `Sort` int(11) NOT NULL DEFAULT '0',
  `Version` int(11) NOT NULL DEFAULT '0',
  `ParentID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `EditableOption_versions`
--

CREATE TABLE IF NOT EXISTS `EditableOption_versions` (
`ID` int(11) NOT NULL,
  `RecordID` int(11) NOT NULL DEFAULT '0',
  `Version` int(11) NOT NULL DEFAULT '0',
  `WasPublished` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `AuthorID` int(11) NOT NULL DEFAULT '0',
  `PublisherID` int(11) NOT NULL DEFAULT '0',
  `ClassName` enum('EditableOption') CHARACTER SET utf8 DEFAULT 'EditableOption',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `Name` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Title` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Default` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `Sort` int(11) NOT NULL DEFAULT '0',
  `ParentID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ErrorPage`
--

CREATE TABLE IF NOT EXISTS `ErrorPage` (
`ID` int(11) NOT NULL,
  `ErrorCode` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ErrorPage`
--

INSERT INTO `ErrorPage` (`ID`, `ErrorCode`) VALUES
(6, 404),
(7, 500);

-- --------------------------------------------------------

--
-- Table structure for table `ErrorPage_Live`
--

CREATE TABLE IF NOT EXISTS `ErrorPage_Live` (
`ID` int(11) NOT NULL,
  `ErrorCode` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ErrorPage_Live`
--

INSERT INTO `ErrorPage_Live` (`ID`, `ErrorCode`) VALUES
(6, 404),
(7, 500);

-- --------------------------------------------------------

--
-- Table structure for table `ErrorPage_versions`
--

CREATE TABLE IF NOT EXISTS `ErrorPage_versions` (
`ID` int(11) NOT NULL,
  `RecordID` int(11) NOT NULL DEFAULT '0',
  `Version` int(11) NOT NULL DEFAULT '0',
  `ErrorCode` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `File`
--

CREATE TABLE IF NOT EXISTS `File` (
`ID` int(11) NOT NULL,
  `ClassName` enum('File','Folder','Image','Image_Cached','PageImage') CHARACTER SET utf8 DEFAULT 'File',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `Name` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Title` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Filename` mediumtext CHARACTER SET utf8,
  `Content` mediumtext CHARACTER SET utf8,
  `ShowInSearch` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `ParentID` int(11) NOT NULL DEFAULT '0',
  `OwnerID` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=45 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `File`
--

INSERT INTO `File` (`ID`, `ClassName`, `Created`, `LastEdited`, `Name`, `Title`, `Filename`, `Content`, `ShowInSearch`, `ParentID`, `OwnerID`) VALUES
(1, 'Folder', '2015-01-26 10:46:27', '2015-01-26 10:46:27', 'Uploads', 'Uploads', 'assets/Uploads/', NULL, 1, 0, 0),
(2, 'Image', '2015-01-26 10:46:27', '2015-01-26 10:46:27', 'SilverStripeLogo.png', 'SilverStripeLogo.png', 'assets/Uploads/SilverStripeLogo.png', NULL, 1, 1, 0),
(3, 'File', '2015-01-26 10:46:27', '2015-01-26 10:46:27', 'error-404.html', 'error-404.html', 'assets/error-404.html', NULL, 1, 0, 0),
(4, 'File', '2015-01-26 10:46:27', '2015-01-26 10:46:27', 'error-500.html', 'error-500.html', 'assets/error-500.html', NULL, 1, 0, 0),
(5, 'Folder', '2015-01-28 20:10:43', '2015-01-28 20:10:43', 'Pages', 'Pages', 'assets/Uploads/Pages/', NULL, 1, 1, 1),
(6, 'Folder', '2015-01-28 20:10:43', '2015-01-28 20:10:43', '10', '10', 'assets/Uploads/Pages/10/', NULL, 1, 5, 1),
(7, 'PageImage', '2015-01-28 20:10:45', '2015-01-28 20:10:53', 'general-1.jpg', 'general 1', 'assets/Uploads/Pages/10/general-1.jpg', NULL, 1, 6, 1),
(8, 'PageImage', '2015-01-28 20:10:45', '2015-01-28 20:10:53', 'general-2.jpg', 'general 2', 'assets/Uploads/Pages/10/general-2.jpg', NULL, 1, 6, 1),
(9, 'PageImage', '2015-01-28 20:10:46', '2015-01-28 20:10:53', 'general-3.jpg', 'general 3', 'assets/Uploads/Pages/10/general-3.jpg', NULL, 1, 6, 1),
(10, 'Folder', '2015-01-29 04:43:20', '2015-01-29 04:43:20', '11', '11', 'assets/Uploads/Pages/11/', NULL, 1, 5, 1),
(11, 'PageImage', '2015-01-29 04:43:26', '2015-01-29 04:43:30', 'general-4.jpg', 'general 4', 'assets/Uploads/Pages/11/general-4.jpg', NULL, 1, 10, 1),
(12, 'Folder', '2015-01-29 04:49:37', '2015-01-29 04:49:37', '12', '12', 'assets/Uploads/Pages/12/', NULL, 1, 5, 1),
(13, 'PageImage', '2015-01-29 04:49:39', '2015-01-29 04:49:45', 'nature-0003.jpg', 'nature 0003', 'assets/Uploads/Pages/12/nature-0003.jpg', NULL, 1, 12, 1),
(14, 'PageImage', '2015-01-29 04:49:40', '2015-01-29 04:49:45', 'nature-0001.jpg', 'nature 0001', 'assets/Uploads/Pages/12/nature-0001.jpg', NULL, 1, 12, 1),
(15, 'PageImage', '2015-01-29 04:49:40', '2015-01-29 04:49:45', 'nature-0002.jpg', 'nature 0002', 'assets/Uploads/Pages/12/nature-0002.jpg', NULL, 1, 12, 1),
(16, 'Folder', '2015-01-29 04:53:18', '2015-01-29 04:53:18', '13', '13', 'assets/Uploads/Pages/13/', NULL, 1, 5, 1),
(17, 'PageImage', '2015-01-29 04:53:20', '2015-01-29 04:53:24', 'nature-0091.jpg', 'nature 0091', 'assets/Uploads/Pages/13/nature-0091.jpg', NULL, 1, 16, 1),
(18, 'Folder', '2015-01-29 04:56:49', '2015-01-29 04:56:49', '14', '14', 'assets/Uploads/Pages/14/', NULL, 1, 5, 1),
(19, 'PageImage', '2015-01-29 04:56:51', '2015-01-29 04:56:53', 'nature-0033.jpg', 'nature 0033', 'assets/Uploads/Pages/14/nature-0033.jpg', NULL, 1, 18, 1),
(20, 'Folder', '2015-01-29 04:58:00', '2015-01-29 04:58:00', '15', '15', 'assets/Uploads/Pages/15/', NULL, 1, 5, 1),
(21, 'PageImage', '2015-01-29 04:58:02', '2015-01-29 04:58:06', 'nature-0001.jpg', 'nature 0001', 'assets/Uploads/Pages/15/nature-0001.jpg', NULL, 1, 20, 1),
(22, 'PageImage', '2015-01-29 04:58:03', '2015-01-29 04:58:06', 'nature-0033.jpg', 'nature 0033', 'assets/Uploads/Pages/15/nature-0033.jpg', NULL, 1, 20, 1),
(23, 'PageImage', '2015-01-29 04:58:03', '2015-01-29 04:58:06', 'nature-0091.jpg', 'nature 0091', 'assets/Uploads/Pages/15/nature-0091.jpg', NULL, 1, 20, 1),
(24, 'Folder', '2015-02-10 11:34:04', '2015-02-10 11:34:04', '17', '17', 'assets/Uploads/Pages/17/', NULL, 1, 5, 1),
(25, 'PageImage', '2015-02-10 18:44:54', '2015-02-10 18:45:26', 'general-4.jpg', 'general 4', 'assets/Uploads/Pages/17/general-4.jpg', NULL, 1, 24, 1),
(26, 'Folder', '2015-03-02 04:55:45', '2015-03-02 04:55:45', 'Persons', 'Persons', 'assets/Uploads/Persons/', NULL, 1, 1, 1),
(27, 'Image', '2015-03-02 04:55:47', '2015-03-02 04:55:47', 'photo-4.jpg', 'photo 4', 'assets/Uploads/Persons/photo-4.jpg', NULL, 1, 26, 1),
(28, 'Image', '2015-03-02 04:57:10', '2015-03-02 04:57:10', 'photo-6.jpg', 'photo 6', 'assets/Uploads/Persons/photo-6.jpg', NULL, 1, 26, 1),
(29, 'Image', '2015-03-02 04:58:41', '2015-03-02 04:58:41', 'photo-5.jpg', 'photo 5', 'assets/Uploads/Persons/photo-5.jpg', NULL, 1, 26, 1),
(30, 'Folder', '2015-03-02 05:01:42', '2015-03-02 05:01:42', 'Clients', 'Clients', 'assets/Uploads/Clients/', NULL, 1, 1, 1),
(31, 'Folder', '2015-03-02 05:01:42', '2015-03-02 05:01:42', 'Authors', 'Authors', 'assets/Uploads/Clients/Authors/', NULL, 1, 30, 1),
(32, 'Image', '2015-03-02 05:01:44', '2015-03-02 05:01:44', 'photo-1.jpg', 'photo 1', 'assets/Uploads/Clients/Authors/photo-1.jpg', NULL, 1, 31, 1),
(33, 'Image', '2015-03-02 05:02:44', '2015-03-02 05:02:44', 'photo-2.jpg', 'photo 2', 'assets/Uploads/Clients/Authors/photo-2.jpg', NULL, 1, 31, 1),
(34, 'Folder', '2015-03-08 17:17:02', '2015-03-08 17:17:02', 'Banners', 'Banners', 'assets/Uploads/Pages/Banners/', NULL, 1, 5, 1),
(35, 'Image', '2015-03-08 17:17:04', '2015-03-08 17:17:04', 'item-1.png', 'item 1', 'assets/Uploads/Pages/Banners/item-1.png', NULL, 1, 34, 1),
(36, 'Image', '2015-03-08 17:18:44', '2015-03-08 17:18:44', 'item-2.png', 'item 2', 'assets/Uploads/Pages/Banners/item-2.png', NULL, 1, 34, 1),
(37, 'Image', '2015-03-08 17:20:13', '2015-03-08 17:20:13', 'item-3.png', 'item 3', 'assets/Uploads/Pages/Banners/item-3.png', NULL, 1, 34, 1),
(38, 'Folder', '2015-03-18 20:26:40', '2015-03-18 20:26:40', '29', '29', 'assets/Uploads/Pages/29/', NULL, 1, 5, 1),
(39, 'Image', '2015-03-18 20:26:42', '2015-03-18 20:26:42', 'nature-0044.jpg', 'nature 0044', 'assets/Uploads/Pages/29/nature-0044.jpg', NULL, 1, 38, 1),
(40, 'PageImage', '2015-03-18 20:26:47', '2015-03-18 20:26:57', 'nature-0091.jpg', 'nature 0091', 'assets/Uploads/Pages/29/nature-0091.jpg', NULL, 1, 38, 1),
(41, 'PageImage', '2015-03-18 20:26:48', '2015-03-18 20:26:57', 'nature-0001.jpg', 'nature 0001', 'assets/Uploads/Pages/29/nature-0001.jpg', NULL, 1, 38, 1),
(42, 'PageImage', '2015-03-18 20:26:49', '2015-03-18 20:26:57', 'nature-0033.jpg', 'nature 0033', 'assets/Uploads/Pages/29/nature-0033.jpg', NULL, 1, 38, 1),
(43, 'Folder', '2015-03-18 22:27:03', '2015-03-18 22:27:03', 'Members', 'Members', 'assets/Uploads/Members/', NULL, 1, 1, 1),
(44, 'Image', '2015-03-18 22:30:02', '2015-03-18 22:30:02', 'photo-3.jpg', 'photo 3', 'assets/Uploads/Members/photo-3.jpg', NULL, 1, 43, 1);

-- --------------------------------------------------------

--
-- Table structure for table `Group`
--

CREATE TABLE IF NOT EXISTS `Group` (
`ID` int(11) NOT NULL,
  `ClassName` enum('Group') CHARACTER SET utf8 DEFAULT 'Group',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `Title` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Description` mediumtext CHARACTER SET utf8,
  `Code` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Locked` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `Sort` int(11) NOT NULL DEFAULT '0',
  `HtmlEditorConfig` mediumtext CHARACTER SET utf8,
  `ParentID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Group`
--

INSERT INTO `Group` (`ID`, `ClassName`, `Created`, `LastEdited`, `Title`, `Description`, `Code`, `Locked`, `Sort`, `HtmlEditorConfig`, `ParentID`) VALUES
(1, 'Group', '2015-01-26 04:46:25', '2015-01-26 04:46:25', 'Content Authors', NULL, 'content-authors', 0, 1, NULL, 0),
(2, 'Group', '2015-01-26 04:46:25', '2015-01-26 04:46:25', 'Administrators', NULL, 'administrators', 0, 0, NULL, 0),
(3, 'Group', '2015-03-18 20:59:22', '2015-03-18 20:59:22', 'Blog users', NULL, 'blog-users', 0, 0, NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `Group_Members`
--

CREATE TABLE IF NOT EXISTS `Group_Members` (
`ID` int(11) NOT NULL,
  `GroupID` int(11) NOT NULL DEFAULT '0',
  `MemberID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Group_Members`
--

INSERT INTO `Group_Members` (`ID`, `GroupID`, `MemberID`) VALUES
(1, 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `Group_Roles`
--

CREATE TABLE IF NOT EXISTS `Group_Roles` (
`ID` int(11) NOT NULL,
  `GroupID` int(11) NOT NULL DEFAULT '0',
  `PermissionRoleID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `HelpArticle`
--

CREATE TABLE IF NOT EXISTS `HelpArticle` (
`ID` int(11) NOT NULL,
  `Featured` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ShortDescription` mediumtext CHARACTER SET utf8
) ENGINE=MyISAM AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `HelpArticle`
--

INSERT INTO `HelpArticle` (`ID`, `Featured`, `ShortDescription`) VALUES
(22, 1, 'Nam eu lobortis nulla. Pellentesque consectetur augue neque, ut porttitor massa tincidunt egestas. Fusce diam tellus, convallis rutrum faucibus porta, venenatis non velit. Nulla non convallis urna, lacinia mollis massa. Nam consequat tristique felis a egestas.'),
(23, 1, NULL),
(24, 1, NULL),
(25, 1, NULL),
(26, 0, NULL),
(27, 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `HelpArticle_Live`
--

CREATE TABLE IF NOT EXISTS `HelpArticle_Live` (
`ID` int(11) NOT NULL,
  `Featured` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ShortDescription` mediumtext CHARACTER SET utf8
) ENGINE=MyISAM AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `HelpArticle_Live`
--

INSERT INTO `HelpArticle_Live` (`ID`, `Featured`, `ShortDescription`) VALUES
(22, 1, 'Nam eu lobortis nulla. Pellentesque consectetur augue neque, ut porttitor massa tincidunt egestas. Fusce diam tellus, convallis rutrum faucibus porta, venenatis non velit. Nulla non convallis urna, lacinia mollis massa. Nam consequat tristique felis a egestas.'),
(23, 1, NULL),
(24, 1, NULL),
(25, 1, NULL),
(26, 0, NULL),
(27, 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `HelpArticle_versions`
--

CREATE TABLE IF NOT EXISTS `HelpArticle_versions` (
`ID` int(11) NOT NULL,
  `RecordID` int(11) NOT NULL DEFAULT '0',
  `Version` int(11) NOT NULL DEFAULT '0',
  `Featured` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ShortDescription` mediumtext CHARACTER SET utf8
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `HelpArticle_versions`
--

INSERT INTO `HelpArticle_versions` (`ID`, `RecordID`, `Version`, `Featured`, `ShortDescription`) VALUES
(1, 22, 1, 0, NULL),
(3, 23, 1, 0, NULL),
(4, 23, 2, 1, NULL),
(5, 24, 1, 0, NULL),
(6, 24, 2, 1, NULL),
(7, 25, 1, 0, NULL),
(8, 25, 2, 0, NULL),
(9, 25, 3, 1, NULL),
(10, 26, 1, 0, NULL),
(11, 26, 2, 0, NULL),
(12, 27, 1, 0, NULL),
(13, 27, 2, 0, NULL),
(14, 22, 3, 1, 'Nam eu lobortis nulla. Pellentesque consectetur augue neque, ut porttitor massa tincidunt egestas. Fusce diam tellus, convallis rutrum faucibus porta, venenatis non velit. Nulla non convallis urna, lacinia mollis massa. Nam consequat tristique felis a egestas.'),
(15, 22, 4, 1, 'Nam eu lobortis nulla. Pellentesque consectetur augue neque, ut porttitor massa tincidunt egestas. Fusce diam tellus, convallis rutrum faucibus porta, venenatis non velit. Nulla non convallis urna, lacinia mollis massa. Nam consequat tristique felis a egestas.'),
(16, 22, 5, 1, 'Nam eu lobortis nulla. Pellentesque consectetur augue neque, ut porttitor massa tincidunt egestas. Fusce diam tellus, convallis rutrum faucibus porta, venenatis non velit. Nulla non convallis urna, lacinia mollis massa. Nam consequat tristique felis a egestas.');

-- --------------------------------------------------------

--
-- Table structure for table `HelpCategory`
--

CREATE TABLE IF NOT EXISTS `HelpCategory` (
`ID` int(11) NOT NULL,
  `ClassName` enum('HelpCategory') CHARACTER SET utf8 DEFAULT 'HelpCategory',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `Title` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `SortOrder` int(11) NOT NULL DEFAULT '0',
  `PageID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `HelpCategory`
--

INSERT INTO `HelpCategory` (`ID`, `ClassName`, `Created`, `LastEdited`, `Title`, `SortOrder`, `PageID`) VALUES
(1, 'HelpCategory', '2015-03-16 19:24:40', '2015-03-16 19:24:40', 'General Questions', 1, 21),
(2, 'HelpCategory', '2015-03-16 19:24:50', '2015-03-16 19:24:50', 'Technical Issues', 2, 21);

-- --------------------------------------------------------

--
-- Table structure for table `HelpCategory_HelpArticles`
--

CREATE TABLE IF NOT EXISTS `HelpCategory_HelpArticles` (
`ID` int(11) NOT NULL,
  `HelpCategoryID` int(11) NOT NULL DEFAULT '0',
  `HelpArticleID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `HelpCategory_HelpArticles`
--

INSERT INTO `HelpCategory_HelpArticles` (`ID`, `HelpCategoryID`, `HelpArticleID`) VALUES
(1, 1, 22),
(2, 2, 22),
(3, 1, 23),
(4, 1, 24),
(5, 2, 24),
(7, 2, 25),
(8, 2, 26),
(9, 2, 27);

-- --------------------------------------------------------

--
-- Table structure for table `HelpPage`
--

CREATE TABLE IF NOT EXISTS `HelpPage` (
`ID` int(11) NOT NULL,
  `ParentID` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `HelpPage`
--

INSERT INTO `HelpPage` (`ID`, `ParentID`) VALUES
(21, 8);

-- --------------------------------------------------------

--
-- Table structure for table `HelpPage_Live`
--

CREATE TABLE IF NOT EXISTS `HelpPage_Live` (
`ID` int(11) NOT NULL,
  `ParentID` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `HelpPage_Live`
--

INSERT INTO `HelpPage_Live` (`ID`, `ParentID`) VALUES
(21, 8);

-- --------------------------------------------------------

--
-- Table structure for table `HelpPage_versions`
--

CREATE TABLE IF NOT EXISTS `HelpPage_versions` (
`ID` int(11) NOT NULL,
  `RecordID` int(11) NOT NULL DEFAULT '0',
  `Version` int(11) NOT NULL DEFAULT '0',
  `ParentID` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `HelpPage_versions`
--

INSERT INTO `HelpPage_versions` (`ID`, `RecordID`, `Version`, `ParentID`) VALUES
(1, 21, 1, 8),
(2, 21, 2, 8),
(3, 21, 3, 8);

-- --------------------------------------------------------

--
-- Table structure for table `HomePage`
--

CREATE TABLE IF NOT EXISTS `HomePage` (
`ID` int(11) NOT NULL,
  `BoxHeading` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `BoxEnable` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `PortfolioEnable` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `PortfolioCount` int(11) NOT NULL DEFAULT '0',
  `PortfolioFeatured` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `PortfolioHeading` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `PortfolioPageID` int(11) NOT NULL DEFAULT '0',
  `TimelineCount` int(11) NOT NULL DEFAULT '0',
  `TimelineHeading` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `TestimonialEnable` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `TeamEnable` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `TeamHeading` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `TestimonialHeading` varchar(50) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `HomePage`
--

INSERT INTO `HomePage` (`ID`, `BoxHeading`, `BoxEnable`, `PortfolioEnable`, `PortfolioCount`, `PortfolioFeatured`, `PortfolioHeading`, `PortfolioPageID`, `TimelineCount`, `TimelineHeading`, `TestimonialEnable`, `TeamEnable`, `TeamHeading`, `TestimonialHeading`) VALUES
(1, 'Key Features', 1, 0, 5, 0, 'Recent Works', 0, 9, 'Timeline', 1, 1, 'Meet Our Team', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `HomePage_Live`
--

CREATE TABLE IF NOT EXISTS `HomePage_Live` (
`ID` int(11) NOT NULL,
  `BoxHeading` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `BoxEnable` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `PortfolioEnable` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `PortfolioCount` int(11) NOT NULL DEFAULT '0',
  `PortfolioFeatured` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `PortfolioHeading` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `PortfolioPageID` int(11) NOT NULL DEFAULT '0',
  `TimelineCount` int(11) NOT NULL DEFAULT '0',
  `TimelineHeading` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `TestimonialEnable` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `TeamEnable` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `TeamHeading` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `TestimonialHeading` varchar(50) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `HomePage_Live`
--

INSERT INTO `HomePage_Live` (`ID`, `BoxHeading`, `BoxEnable`, `PortfolioEnable`, `PortfolioCount`, `PortfolioFeatured`, `PortfolioHeading`, `PortfolioPageID`, `TimelineCount`, `TimelineHeading`, `TestimonialEnable`, `TeamEnable`, `TeamHeading`, `TestimonialHeading`) VALUES
(1, 'Key Features', 1, 0, 5, 0, 'Recent Works', 0, 9, 'Timeline', 1, 1, 'Meet Our Team', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `HomePage_Testimonials`
--

CREATE TABLE IF NOT EXISTS `HomePage_Testimonials` (
`ID` int(11) NOT NULL,
  `HomePageID` int(11) NOT NULL DEFAULT '0',
  `TestimonialID` int(11) NOT NULL DEFAULT '0',
  `SortOrder` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `HomePage_Testimonials`
--

INSERT INTO `HomePage_Testimonials` (`ID`, `HomePageID`, `TestimonialID`, `SortOrder`) VALUES
(1, 1, 4, 1),
(2, 1, 3, 2),
(3, 1, 1, 3);

-- --------------------------------------------------------

--
-- Table structure for table `HomePage_versions`
--

CREATE TABLE IF NOT EXISTS `HomePage_versions` (
`ID` int(11) NOT NULL,
  `RecordID` int(11) NOT NULL DEFAULT '0',
  `Version` int(11) NOT NULL DEFAULT '0',
  `BoxHeading` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `BoxEnable` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `PortfolioEnable` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `PortfolioCount` int(11) NOT NULL DEFAULT '0',
  `PortfolioFeatured` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `PortfolioHeading` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `PortfolioPageID` int(11) NOT NULL DEFAULT '0',
  `TimelineCount` int(11) NOT NULL DEFAULT '0',
  `TimelineHeading` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `TestimonialEnable` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `TeamEnable` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `TeamHeading` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `TestimonialHeading` varchar(50) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `HomePage_versions`
--

INSERT INTO `HomePage_versions` (`ID`, `RecordID`, `Version`, `BoxHeading`, `BoxEnable`, `PortfolioEnable`, `PortfolioCount`, `PortfolioFeatured`, `PortfolioHeading`, `PortfolioPageID`, `TimelineCount`, `TimelineHeading`, `TestimonialEnable`, `TeamEnable`, `TeamHeading`, `TestimonialHeading`) VALUES
(23, 1, 25, 'Key Features', 1, 0, 5, 0, 'Recent Works', 0, 9, 'Timeline', 1, 1, 'Meet Our Team', NULL),
(21, 1, 23, 'Key Features', 1, 0, 5, 0, 'Recent Works', 0, 9, 'Timeline', 1, 1, 'Meet Our Team', NULL),
(22, 1, 24, 'Key Features', 1, 0, 5, 0, 'Recent Works', 0, 9, 'Timeline', 1, 1, 'Meet Our Team', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `Image`
--

CREATE TABLE IF NOT EXISTS `Image` (
`ID` int(11) NOT NULL,
  `FocusX` double DEFAULT NULL,
  `FocusY` double DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=45 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Image`
--

INSERT INTO `Image` (`ID`, `FocusX`, `FocusY`) VALUES
(7, 0, 0),
(8, 0, 0),
(9, 0, 0),
(11, 0, 0),
(13, 0, 0),
(14, 0, 0),
(15, 0, 0),
(17, 0, 0),
(19, 0, 0),
(21, 0, 0),
(22, 0, 0),
(23, 0, 0),
(25, 0, 0),
(27, 0, 0),
(28, 0, 0),
(29, 0, 0),
(32, 0, 0),
(33, 0, 0),
(35, 0, 0),
(36, 0, 0),
(37, 0, 0),
(39, 0, 0),
(40, 0, 0),
(41, 0, 0),
(42, 0, 0),
(44, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `LoginAttempt`
--

CREATE TABLE IF NOT EXISTS `LoginAttempt` (
`ID` int(11) NOT NULL,
  `ClassName` enum('LoginAttempt') CHARACTER SET utf8 DEFAULT 'LoginAttempt',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `Email` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Status` enum('Success','Failure') CHARACTER SET utf8 DEFAULT 'Success',
  `IP` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `MemberID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Member`
--

CREATE TABLE IF NOT EXISTS `Member` (
`ID` int(11) NOT NULL,
  `ClassName` enum('Member') CHARACTER SET utf8 DEFAULT 'Member',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `FirstName` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `Surname` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `Email` varchar(254) CHARACTER SET utf8 DEFAULT NULL,
  `TempIDHash` varchar(160) CHARACTER SET utf8 DEFAULT NULL,
  `TempIDExpired` datetime DEFAULT NULL,
  `Password` varchar(160) CHARACTER SET utf8 DEFAULT NULL,
  `RememberLoginToken` varchar(160) CHARACTER SET utf8 DEFAULT NULL,
  `NumVisit` int(11) NOT NULL DEFAULT '0',
  `LastVisited` datetime DEFAULT NULL,
  `AutoLoginHash` varchar(160) CHARACTER SET utf8 DEFAULT NULL,
  `AutoLoginExpired` datetime DEFAULT NULL,
  `PasswordEncryption` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `Salt` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `PasswordExpiry` date DEFAULT NULL,
  `LockedOutUntil` datetime DEFAULT NULL,
  `Locale` varchar(6) CHARACTER SET utf8 DEFAULT NULL,
  `FailedLoginCount` int(11) NOT NULL DEFAULT '0',
  `DateFormat` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `TimeFormat` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `Biography` mediumtext CHARACTER SET utf8,
  `PhotoID` int(11) NOT NULL DEFAULT '0',
  `URLSegment` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `BlogProfileSummary` mediumtext CHARACTER SET utf8,
  `BlogProfileImageID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Member`
--

INSERT INTO `Member` (`ID`, `ClassName`, `Created`, `LastEdited`, `FirstName`, `Surname`, `Email`, `TempIDHash`, `TempIDExpired`, `Password`, `RememberLoginToken`, `NumVisit`, `LastVisited`, `AutoLoginHash`, `AutoLoginExpired`, `PasswordEncryption`, `Salt`, `PasswordExpiry`, `LockedOutUntil`, `Locale`, `FailedLoginCount`, `DateFormat`, `TimeFormat`, `Biography`, `PhotoID`, `URLSegment`, `BlogProfileSummary`, `BlogProfileImageID`) VALUES
(1, 'Member', '2015-01-26 04:46:27', '2015-06-29 18:59:52', 'Default Admin', NULL, 'admin@themestripe.com', '17e9a5322e4ddb8631458be3ad5dbf7e92400b28', '2015-07-02 18:59:45', '$2y$10$50301048597b38a8abca6u3Ur8F19nrZ4Su3n9k0kQyQJJMmo8dxO', NULL, 8, '2015-06-29 23:59:52', NULL, NULL, 'blowfish', '10$50301048597b38a8abca66', NULL, NULL, 'en_US', 0, 'MMM d, y', 'h:mm:ss a', NULL, 44, 'default-admin', NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `MemberPassword`
--

CREATE TABLE IF NOT EXISTS `MemberPassword` (
`ID` int(11) NOT NULL,
  `ClassName` enum('MemberPassword') CHARACTER SET utf8 DEFAULT 'MemberPassword',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `Password` varchar(160) CHARACTER SET utf8 DEFAULT NULL,
  `Salt` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `PasswordEncryption` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `MemberID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `MemberPassword`
--

INSERT INTO `MemberPassword` (`ID`, `ClassName`, `Created`, `LastEdited`, `Password`, `Salt`, `PasswordEncryption`, `MemberID`) VALUES
(1, 'MemberPassword', '2015-01-26 04:46:27', '2015-01-26 04:46:27', '$2y$10$50301048597b38a8abca6u3Ur8F19nrZ4Su3n9k0kQyQJJMmo8dxO', '10$50301048597b38a8abca66', 'blowfish', 1);

-- --------------------------------------------------------

--
-- Table structure for table `Page`
--

CREATE TABLE IF NOT EXISTS `Page` (
`ID` int(11) NOT NULL,
  `InheritSideBar` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `PageLayout` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `SideBarID` int(11) NOT NULL DEFAULT '0',
  `PageHeading` varchar(255) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=30 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Page`
--

INSERT INTO `Page` (`ID`, `InheritSideBar`, `PageLayout`, `SideBarID`, `PageHeading`) VALUES
(8, 1, NULL, 0, NULL),
(9, 1, NULL, 0, NULL),
(1, 1, NULL, 0, NULL),
(10, 1, NULL, 0, NULL),
(11, 1, NULL, 2, NULL),
(12, 1, NULL, 4, NULL),
(13, 1, NULL, 6, NULL),
(14, 1, NULL, 8, NULL),
(15, 1, NULL, 10, NULL),
(16, 1, NULL, 0, NULL),
(17, 1, NULL, 0, NULL),
(18, 1, NULL, 12, NULL),
(19, 1, NULL, 14, NULL),
(2, 1, NULL, 0, 'About Simline'),
(20, 1, NULL, 0, 'Our Services'),
(3, 1, NULL, 0, NULL),
(5, 0, NULL, 16, NULL),
(21, 1, NULL, 0, NULL),
(22, 1, NULL, 0, NULL),
(23, 1, NULL, 0, NULL),
(24, 1, NULL, 0, NULL),
(25, 1, NULL, 0, NULL),
(26, 1, NULL, 0, NULL),
(27, 1, NULL, 0, NULL),
(28, 1, NULL, 0, NULL),
(29, 1, NULL, 17, NULL),
(4, 0, NULL, 18, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `PageImage`
--

CREATE TABLE IF NOT EXISTS `PageImage` (
`ID` int(11) NOT NULL,
  `PageID` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=43 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `PageImage`
--

INSERT INTO `PageImage` (`ID`, `PageID`) VALUES
(7, 10),
(8, 10),
(9, 10),
(11, 11),
(13, 12),
(14, 12),
(15, 12),
(17, 13),
(19, 14),
(21, 15),
(22, 15),
(23, 15),
(25, 17),
(40, 29),
(41, 29),
(42, 29);

-- --------------------------------------------------------

--
-- Table structure for table `Page_Live`
--

CREATE TABLE IF NOT EXISTS `Page_Live` (
`ID` int(11) NOT NULL,
  `InheritSideBar` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `PageLayout` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `SideBarID` int(11) NOT NULL DEFAULT '0',
  `PageHeading` varchar(255) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=30 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Page_Live`
--

INSERT INTO `Page_Live` (`ID`, `InheritSideBar`, `PageLayout`, `SideBarID`, `PageHeading`) VALUES
(8, 1, NULL, 0, NULL),
(2, 1, NULL, 0, 'About Simline'),
(3, 1, NULL, 0, NULL),
(9, 1, NULL, 0, NULL),
(1, 1, NULL, 0, NULL),
(10, 1, NULL, 0, NULL),
(11, 1, NULL, 2, NULL),
(12, 1, NULL, 4, NULL),
(13, 1, NULL, 6, NULL),
(14, 1, NULL, 8, NULL),
(15, 1, NULL, 10, NULL),
(16, 1, NULL, 0, NULL),
(17, 1, NULL, 0, NULL),
(18, 1, NULL, 12, NULL),
(19, 1, NULL, 14, NULL),
(4, 0, NULL, 18, NULL),
(20, 1, NULL, 0, 'Our Services'),
(5, 0, NULL, 16, NULL),
(21, 1, NULL, 0, NULL),
(22, 1, NULL, 0, NULL),
(23, 1, NULL, 0, NULL),
(24, 1, NULL, 0, NULL),
(25, 1, NULL, 0, NULL),
(26, 1, NULL, 0, NULL),
(27, 1, NULL, 0, NULL),
(28, 1, NULL, 0, NULL),
(29, 1, NULL, 17, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `Page_versions`
--

CREATE TABLE IF NOT EXISTS `Page_versions` (
`ID` int(11) NOT NULL,
  `RecordID` int(11) NOT NULL DEFAULT '0',
  `Version` int(11) NOT NULL DEFAULT '0',
  `InheritSideBar` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `PageLayout` varchar(30) CHARACTER SET utf8 DEFAULT NULL,
  `SideBarID` int(11) NOT NULL DEFAULT '0',
  `PageHeading` varchar(255) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=171 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Page_versions`
--

INSERT INTO `Page_versions` (`ID`, `RecordID`, `Version`, `InheritSideBar`, `PageLayout`, `SideBarID`, `PageHeading`) VALUES
(1, 8, 1, 1, NULL, 0, NULL),
(2, 8, 2, 1, NULL, 0, NULL),
(3, 8, 3, 1, NULL, 0, NULL),
(4, 2, 2, 0, NULL, 0, NULL),
(5, 2, 3, 0, NULL, 0, NULL),
(6, 2, 4, 0, NULL, 0, NULL),
(7, 3, 2, 0, NULL, 0, NULL),
(8, 3, 3, 0, NULL, 0, NULL),
(9, 3, 4, 0, NULL, 0, NULL),
(10, 9, 1, 1, NULL, 0, NULL),
(11, 9, 2, 1, NULL, 0, NULL),
(12, 9, 3, 1, NULL, 0, NULL),
(104, 2, 36, 1, NULL, 0, 'About Simline'),
(42, 18, 1, 1, NULL, 12, NULL),
(158, 9, 8, 1, NULL, 0, NULL),
(159, 12, 3, 1, NULL, 4, NULL),
(17, 10, 1, 1, NULL, 0, NULL),
(22, 10, 6, 1, NULL, 0, NULL),
(23, 10, 7, 1, NULL, 0, NULL),
(169, 11, 5, 1, NULL, 2, NULL),
(28, 12, 2, 1, NULL, 4, NULL),
(161, 29, 1, 1, NULL, 0, NULL),
(26, 13, 1, 1, NULL, 6, NULL),
(27, 10, 8, 1, NULL, 0, NULL),
(170, 29, 4, 1, NULL, 17, NULL),
(30, 14, 1, 1, NULL, 8, NULL),
(31, 15, 1, 1, NULL, 10, NULL),
(32, 16, 1, 1, NULL, 0, NULL),
(33, 16, 2, 1, NULL, 0, NULL),
(34, 17, 1, 1, NULL, 0, NULL),
(52, 17, 10, 1, NULL, 0, NULL),
(53, 2, 5, 0, NULL, 0, NULL),
(47, 17, 8, 1, NULL, 0, NULL),
(48, 18, 2, 1, NULL, 12, NULL),
(77, 1, 25, 1, NULL, 0, NULL),
(43, 19, 1, 1, NULL, 14, NULL),
(75, 1, 23, 1, NULL, 0, NULL),
(49, 19, 2, 1, NULL, 14, NULL),
(50, 18, 3, 1, NULL, 12, NULL),
(51, 17, 9, 1, NULL, 0, NULL),
(54, 2, 6, 0, NULL, 0, NULL),
(84, 4, 3, 0, NULL, 0, NULL),
(106, 2, 38, 1, NULL, 0, 'About Simline'),
(57, 2, 9, 1, NULL, 0, 'About Simline'),
(58, 2, 10, 1, NULL, 0, 'About Simline'),
(107, 20, 1, 1, NULL, 0, NULL),
(76, 1, 24, 1, NULL, 0, NULL),
(167, 11, 3, 1, NULL, 2, NULL),
(105, 2, 37, 1, NULL, 0, 'About Simline'),
(117, 20, 11, 1, NULL, 0, 'Our Services'),
(118, 5, 3, 0, NULL, 0, NULL),
(115, 20, 9, 1, NULL, 0, 'Company Introduction'),
(116, 20, 10, 1, NULL, 0, 'Company Introduction'),
(126, 3, 10, 1, NULL, 0, NULL),
(127, 3, 11, 1, NULL, 0, NULL),
(123, 5, 4, 0, NULL, 16, NULL),
(124, 5, 5, 0, NULL, 16, NULL),
(129, 21, 1, 1, NULL, 0, NULL),
(128, 3, 12, 1, NULL, 0, NULL),
(130, 21, 2, 1, NULL, 0, NULL),
(131, 22, 1, 1, NULL, 0, NULL),
(147, 20, 12, 1, NULL, 0, 'Our Services'),
(133, 23, 1, 1, NULL, 0, NULL),
(134, 23, 2, 1, NULL, 0, NULL),
(135, 24, 1, 1, NULL, 0, NULL),
(136, 24, 2, 1, NULL, 0, NULL),
(137, 25, 1, 1, NULL, 0, NULL),
(138, 25, 2, 1, NULL, 0, NULL),
(139, 25, 3, 1, NULL, 0, NULL),
(140, 26, 1, 1, NULL, 0, NULL),
(141, 26, 2, 1, NULL, 0, NULL),
(142, 27, 1, 1, NULL, 0, NULL),
(143, 27, 2, 1, NULL, 0, NULL),
(144, 22, 3, 1, NULL, 0, NULL),
(145, 22, 4, 1, NULL, 0, NULL),
(146, 22, 5, 1, NULL, 0, NULL),
(148, 20, 13, 1, NULL, 0, 'Our Services'),
(149, 21, 3, 1, NULL, 0, NULL),
(150, 20, 14, 1, NULL, 0, 'Our Services'),
(151, 16, 3, 1, NULL, 0, NULL),
(152, 19, 3, 1, NULL, 14, NULL),
(153, 16, 4, 1, NULL, 0, NULL),
(154, 28, 1, 1, NULL, 0, NULL),
(155, 28, 2, 1, NULL, 0, NULL),
(156, 9, 6, 1, NULL, 0, NULL),
(157, 9, 7, 1, NULL, 0, NULL),
(160, 12, 4, 1, NULL, 4, NULL),
(162, 29, 2, 1, NULL, 17, NULL),
(163, 29, 3, 1, NULL, 17, NULL),
(164, 4, 4, 0, NULL, 18, NULL),
(165, 4, 5, 0, NULL, 18, NULL),
(166, 4, 6, 0, NULL, 18, NULL),
(168, 11, 4, 1, NULL, 2, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `Permission`
--

CREATE TABLE IF NOT EXISTS `Permission` (
`ID` int(11) NOT NULL,
  `ClassName` enum('Permission') CHARACTER SET utf8 DEFAULT 'Permission',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `Code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `Arg` int(11) NOT NULL DEFAULT '0',
  `Type` int(11) NOT NULL DEFAULT '1',
  `GroupID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Permission`
--

INSERT INTO `Permission` (`ID`, `ClassName`, `Created`, `LastEdited`, `Code`, `Arg`, `Type`, `GroupID`) VALUES
(1, 'Permission', '2015-01-26 04:46:25', '2015-01-26 04:46:25', 'CMS_ACCESS_CMSMain', 0, 1, 1),
(2, 'Permission', '2015-01-26 04:46:25', '2015-01-26 04:46:25', 'CMS_ACCESS_AssetAdmin', 0, 1, 1),
(3, 'Permission', '2015-01-26 04:46:25', '2015-01-26 04:46:25', 'CMS_ACCESS_ReportAdmin', 0, 1, 1),
(4, 'Permission', '2015-01-26 04:46:25', '2015-01-26 04:46:25', 'SITETREE_REORGANISE', 0, 1, 1),
(5, 'Permission', '2015-01-26 04:46:25', '2015-01-26 04:46:25', 'ADMIN', 0, 1, 2),
(6, 'Permission', '2015-03-18 20:59:22', '2015-03-18 20:59:22', 'CMS_ACCESS_CMSMain', 0, 1, 3);

-- --------------------------------------------------------

--
-- Table structure for table `PermissionRole`
--

CREATE TABLE IF NOT EXISTS `PermissionRole` (
`ID` int(11) NOT NULL,
  `ClassName` enum('PermissionRole') CHARACTER SET utf8 DEFAULT 'PermissionRole',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `Title` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `OnlyAdminCanApply` tinyint(1) unsigned NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `PermissionRoleCode`
--

CREATE TABLE IF NOT EXISTS `PermissionRoleCode` (
`ID` int(11) NOT NULL,
  `ClassName` enum('PermissionRoleCode') CHARACTER SET utf8 DEFAULT 'PermissionRoleCode',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `Code` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `RoleID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `PortfolioCategory`
--

CREATE TABLE IF NOT EXISTS `PortfolioCategory` (
`ID` int(11) NOT NULL,
  `ClassName` enum('PortfolioCategory') CHARACTER SET utf8 DEFAULT 'PortfolioCategory',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `Title` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `SortOrder` int(11) NOT NULL DEFAULT '0',
  `PageID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `PortfolioCategory`
--

INSERT INTO `PortfolioCategory` (`ID`, `ClassName`, `Created`, `LastEdited`, `Title`, `SortOrder`, `PageID`) VALUES
(1, 'PortfolioCategory', '2015-01-28 19:26:58', '2015-01-28 19:26:58', 'Category #1', 1, 9),
(2, 'PortfolioCategory', '2015-01-28 19:27:09', '2015-01-28 19:27:09', 'Category #2', 2, 9),
(3, 'PortfolioCategory', '2015-01-28 19:27:19', '2015-01-28 19:27:19', 'Category #3', 3, 9);

-- --------------------------------------------------------

--
-- Table structure for table `PortfolioCategory_PortfolioItems`
--

CREATE TABLE IF NOT EXISTS `PortfolioCategory_PortfolioItems` (
`ID` int(11) NOT NULL,
  `PortfolioCategoryID` int(11) NOT NULL DEFAULT '0',
  `PortfolioItemID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `PortfolioCategory_PortfolioItems`
--

INSERT INTO `PortfolioCategory_PortfolioItems` (`ID`, `PortfolioCategoryID`, `PortfolioItemID`) VALUES
(1, 1, 10),
(2, 2, 10),
(3, 3, 10),
(4, 1, 11),
(8, 2, 12),
(9, 3, 12),
(12, 3, 13),
(13, 3, 14),
(14, 1, 14),
(15, 2, 14),
(16, 1, 15),
(18, 3, 15);

-- --------------------------------------------------------

--
-- Table structure for table `PortfolioItem`
--

CREATE TABLE IF NOT EXISTS `PortfolioItem` (
`ID` int(11) NOT NULL,
  `ShortDescription` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Date` datetime DEFAULT NULL,
  `Featured` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `Attributes` mediumtext CHARACTER SET utf8
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `PortfolioItem`
--

INSERT INTO `PortfolioItem` (`ID`, `ShortDescription`, `Date`, `Featured`, `Attributes`) VALUES
(10, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus.', '2015-01-01 00:00:00', 1, '{"scenario":"portfolio_attribute","enable":true,"heading":"Details","items":{"zknzaa":{"Name":"Client name","Value":"Google INC"},"w2m3pg":{"Name":"Client site","Value":"www.google.com"},"ejs2kp":{"Name":"Another attribute","Value":"Hello, i am the value of the custom attribute."}}}'),
(11, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus.', '2015-01-01 00:00:00', 1, '{"scenario":"portfolio_attribute","enable":true,"heading":"Details","items":{"zknzaa":{"Name":"Client name","Value":"Google INC"},"w2m3pg":{"Name":"Client site","Value":"www.google.com"},"ejs2kp":{"Name":"Another attribute","Value":"Hello, i am the value of the custom attribute."},"a53fc7":{"Name":"Hello","Value":"World"}}}'),
(12, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis.', '2015-01-01 00:00:00', 1, '{"scenario":"portfolio_attribute","enable":true,"heading":"Details","items":{"zknzaa":{"Name":"Client name","Value":"Google INC"},"w2m3pg":{"Name":"Client site","Value":"www.google.com"},"ejs2kp":{"Name":"Another attribute","Value":"Hello, i am the value of the custom attribute."}}}'),
(13, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus.', '2015-01-01 00:00:00', 0, '{"scenario":"portfolio_attribute","enable":true,"heading":"Details","items":{"zknzaa":{"Name":"Client name","Value":"Google INC"},"w2m3pg":{"Name":"Client site","Value":"www.google.com"},"ejs2kp":{"Name":"Another attribute","Value":"Hello, i am the value of the custom attribute."}}}'),
(14, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus.', '2015-01-01 00:00:00', 0, '{"scenario":"portfolio_attribute","enable":true,"heading":"Details","items":{"zknzaa":{"Name":"Client name","Value":"Google INC"},"w2m3pg":{"Name":"Client site","Value":"www.google.com"},"ejs2kp":{"Name":"Another attribute","Value":"Hello, i am the value of the custom attribute."}}}'),
(15, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus.', '2015-01-01 00:00:00', 0, '{"scenario":"portfolio_attribute","enable":true,"heading":"Details","items":{"zknzaa":{"Name":"Client name","Value":"Google INC"},"w2m3pg":{"Name":"Client site","Value":"www.google.com"},"ejs2kp":{"Name":"Another attribute","Value":"Hello, i am the value of the custom attribute."}}}');

-- --------------------------------------------------------

--
-- Table structure for table `PortfolioItem_Live`
--

CREATE TABLE IF NOT EXISTS `PortfolioItem_Live` (
`ID` int(11) NOT NULL,
  `ShortDescription` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Date` datetime DEFAULT NULL,
  `Featured` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `Attributes` mediumtext CHARACTER SET utf8
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `PortfolioItem_Live`
--

INSERT INTO `PortfolioItem_Live` (`ID`, `ShortDescription`, `Date`, `Featured`, `Attributes`) VALUES
(10, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus.', '2015-01-01 00:00:00', 1, '{"scenario":"portfolio_attribute","enable":true,"heading":"Details","items":{"zknzaa":{"Name":"Client name","Value":"Google INC"},"w2m3pg":{"Name":"Client site","Value":"www.google.com"},"ejs2kp":{"Name":"Another attribute","Value":"Hello, i am the value of the custom attribute."}}}'),
(11, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus.', '2015-01-01 00:00:00', 1, '{"scenario":"portfolio_attribute","enable":true,"heading":"Details","items":{"zknzaa":{"Name":"Client name","Value":"Google INC"},"w2m3pg":{"Name":"Client site","Value":"www.google.com"},"ejs2kp":{"Name":"Another attribute","Value":"Hello, i am the value of the custom attribute."},"a53fc7":{"Name":"Hello","Value":"World"}}}'),
(12, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis.', '2015-01-01 00:00:00', 1, '{"scenario":"portfolio_attribute","enable":true,"heading":"Details","items":{"zknzaa":{"Name":"Client name","Value":"Google INC"},"w2m3pg":{"Name":"Client site","Value":"www.google.com"},"ejs2kp":{"Name":"Another attribute","Value":"Hello, i am the value of the custom attribute."}}}'),
(13, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus.', '2015-01-01 00:00:00', 0, '{"scenario":"portfolio_attribute","enable":true,"heading":"Details","items":{"zknzaa":{"Name":"Client name","Value":"Google INC"},"w2m3pg":{"Name":"Client site","Value":"www.google.com"},"ejs2kp":{"Name":"Another attribute","Value":"Hello, i am the value of the custom attribute."}}}'),
(14, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus.', '2015-01-01 00:00:00', 0, '{"scenario":"portfolio_attribute","enable":true,"heading":"Details","items":{"zknzaa":{"Name":"Client name","Value":"Google INC"},"w2m3pg":{"Name":"Client site","Value":"www.google.com"},"ejs2kp":{"Name":"Another attribute","Value":"Hello, i am the value of the custom attribute."}}}'),
(15, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus.', '2015-01-01 00:00:00', 0, '{"scenario":"portfolio_attribute","enable":true,"heading":"Details","items":{"zknzaa":{"Name":"Client name","Value":"Google INC"},"w2m3pg":{"Name":"Client site","Value":"www.google.com"},"ejs2kp":{"Name":"Another attribute","Value":"Hello, i am the value of the custom attribute."}}}');

-- --------------------------------------------------------

--
-- Table structure for table `PortfolioItem_RelatedItems`
--

CREATE TABLE IF NOT EXISTS `PortfolioItem_RelatedItems` (
`ID` int(11) NOT NULL,
  `PortfolioItemID` int(11) NOT NULL DEFAULT '0',
  `ChildID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `PortfolioItem_RelatedItems`
--

INSERT INTO `PortfolioItem_RelatedItems` (`ID`, `PortfolioItemID`, `ChildID`) VALUES
(1, 11, 10),
(2, 10, 11),
(3, 12, 11),
(4, 12, 10),
(5, 13, 11),
(6, 13, 10),
(7, 13, 12),
(8, 14, 10),
(11, 15, 10),
(12, 15, 14);

-- --------------------------------------------------------

--
-- Table structure for table `PortfolioItem_Testimonials`
--

CREATE TABLE IF NOT EXISTS `PortfolioItem_Testimonials` (
`ID` int(11) NOT NULL,
  `PortfolioItemID` int(11) NOT NULL DEFAULT '0',
  `TestimonialID` int(11) NOT NULL DEFAULT '0',
  `SortOrder` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `PortfolioItem_Testimonials`
--

INSERT INTO `PortfolioItem_Testimonials` (`ID`, `PortfolioItemID`, `TestimonialID`, `SortOrder`) VALUES
(1, 12, 1, 1),
(2, 12, 4, 2);

-- --------------------------------------------------------

--
-- Table structure for table `PortfolioItem_versions`
--

CREATE TABLE IF NOT EXISTS `PortfolioItem_versions` (
`ID` int(11) NOT NULL,
  `RecordID` int(11) NOT NULL DEFAULT '0',
  `Version` int(11) NOT NULL DEFAULT '0',
  `ShortDescription` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Date` datetime DEFAULT NULL,
  `Featured` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `Attributes` mediumtext CHARACTER SET utf8
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `PortfolioItem_versions`
--

INSERT INTO `PortfolioItem_versions` (`ID`, `RecordID`, `Version`, `ShortDescription`, `Date`, `Featured`, `Attributes`) VALUES
(1, 10, 1, NULL, NULL, 0, NULL),
(6, 10, 6, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus.', '2015-01-01 00:00:00', 1, '{"scenario":"portfolio_attribute","enable":true,"heading":"Details","items":{"ejs2kp":{"Name":"Another properties","Value":"Hello world."},"zknzaa":{"Name":"Client name","Value":"Google INC"},"w2m3pg":{"Name":"Client site","Value":"www.google.com"}}}'),
(7, 10, 7, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus.', '2015-01-01 00:00:00', 1, '{"scenario":"portfolio_attribute","enable":true,"heading":"Details","items":{"zknzaa":{"Name":"Client name","Value":"Google INC"},"w2m3pg":{"Name":"Client site","Value":"www.google.com"},"ejs2kp":{"Name":"Another properties","Value":"Hello world."}}}'),
(20, 11, 5, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus.', '2015-01-01 00:00:00', 1, '{"scenario":"portfolio_attribute","enable":true,"heading":"Details","items":{"zknzaa":{"Name":"Client name","Value":"Google INC"},"w2m3pg":{"Name":"Client site","Value":"www.google.com"},"ejs2kp":{"Name":"Another attribute","Value":"Hello, i am the value of the custom attribute."},"a53fc7":{"Name":"Hello","Value":"World"}}}'),
(12, 12, 2, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis.', '2015-01-01 00:00:00', 1, '{"scenario":"portfolio_attribute","enable":true,"heading":"Details","items":{"zknzaa":{"Name":"Client name","Value":"Google INC"},"w2m3pg":{"Name":"Client site","Value":"www.google.com"},"ejs2kp":{"Name":"Another attribute","Value":"Hello, i am the value of the custom attribute."}}}'),
(18, 11, 3, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus.', '2015-01-01 00:00:00', 1, '{"scenario":"portfolio_attribute","enable":true,"heading":"Details","items":{"zknzaa":{"Name":"Client name","Value":"Google INC"},"w2m3pg":{"Name":"Client site","Value":"www.google.com"},"ejs2kp":{"Name":"Another attribute","Value":"Hello, i am the value of the custom attribute."},"a53fc7":{"Name":"Hello","Value":"World"}}}'),
(10, 13, 1, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus.', '2015-01-01 00:00:00', 0, '{"scenario":"portfolio_attribute","enable":true,"heading":"Details","items":{"zknzaa":{"Name":"Client name","Value":"Google INC"},"w2m3pg":{"Name":"Client site","Value":"www.google.com"},"ejs2kp":{"Name":"Another attribute","Value":"Hello, i am the value of the custom attribute."}}}'),
(11, 10, 8, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus.', '2015-01-01 00:00:00', 1, '{"scenario":"portfolio_attribute","enable":true,"heading":"Details","items":{"zknzaa":{"Name":"Client name","Value":"Google INC"},"w2m3pg":{"Name":"Client site","Value":"www.google.com"},"ejs2kp":{"Name":"Another attribute","Value":"Hello, i am the value of the custom attribute."}}}'),
(14, 14, 1, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus.', '2015-01-01 00:00:00', 0, '{"scenario":"portfolio_attribute","enable":true,"heading":"Details","items":{"zknzaa":{"Name":"Client name","Value":"Google INC"},"w2m3pg":{"Name":"Client site","Value":"www.google.com"},"ejs2kp":{"Name":"Another attribute","Value":"Hello, i am the value of the custom attribute."}}}'),
(15, 15, 1, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus.', '2015-01-01 00:00:00', 0, '{"scenario":"portfolio_attribute","enable":true,"heading":"Details","items":{"zknzaa":{"Name":"Client name","Value":"Google INC"},"w2m3pg":{"Name":"Client site","Value":"www.google.com"},"ejs2kp":{"Name":"Another attribute","Value":"Hello, i am the value of the custom attribute."}}}'),
(16, 12, 3, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis.', '2015-01-01 00:00:00', 1, '{"scenario":"portfolio_attribute","enable":true,"heading":"Details","items":{"zknzaa":{"Name":"Client name","Value":"Google INC"},"w2m3pg":{"Name":"Client site","Value":"www.google.com"},"ejs2kp":{"Name":"Another attribute","Value":"Hello, i am the value of the custom attribute."}}}'),
(17, 12, 4, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis.', '2015-01-01 00:00:00', 1, '{"scenario":"portfolio_attribute","enable":true,"heading":"Details","items":{"zknzaa":{"Name":"Client name","Value":"Google INC"},"w2m3pg":{"Name":"Client site","Value":"www.google.com"},"ejs2kp":{"Name":"Another attribute","Value":"Hello, i am the value of the custom attribute."}}}'),
(19, 11, 4, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus.', '2015-01-01 00:00:00', 1, '{"scenario":"portfolio_attribute","enable":false,"heading":"Details","items":{"zknzaa":{"Name":"Client name","Value":"Google INC"},"w2m3pg":{"Name":"Client site","Value":"www.google.com"},"ejs2kp":{"Name":"Another attribute","Value":"Hello, i am the value of the custom attribute."},"a53fc7":{"Name":"Hello","Value":"World"}}}');

-- --------------------------------------------------------

--
-- Table structure for table `PortfolioPage`
--

CREATE TABLE IF NOT EXISTS `PortfolioPage` (
`ID` int(11) NOT NULL,
  `ParentID` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `PortfolioPage_Live`
--

CREATE TABLE IF NOT EXISTS `PortfolioPage_Live` (
`ID` int(11) NOT NULL,
  `ParentID` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `PortfolioPage_Live`
--

INSERT INTO `PortfolioPage_Live` (`ID`, `ParentID`) VALUES
(9, 0);

-- --------------------------------------------------------

--
-- Table structure for table `PortfolioPage_versions`
--

CREATE TABLE IF NOT EXISTS `PortfolioPage_versions` (
`ID` int(11) NOT NULL,
  `RecordID` int(11) NOT NULL DEFAULT '0',
  `Version` int(11) NOT NULL DEFAULT '0',
  `ParentID` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `PortfolioPage_versions`
--

INSERT INTO `PortfolioPage_versions` (`ID`, `RecordID`, `Version`, `ParentID`) VALUES
(1, 9, 6, 0),
(2, 9, 7, 0),
(3, 9, 8, 0);

-- --------------------------------------------------------

--
-- Table structure for table `RedirectorPage`
--

CREATE TABLE IF NOT EXISTS `RedirectorPage` (
`ID` int(11) NOT NULL,
  `RedirectionType` enum('Internal','External') CHARACTER SET utf8 DEFAULT 'Internal',
  `ExternalURL` varchar(2083) CHARACTER SET utf8 DEFAULT NULL,
  `LinkToID` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `RedirectorPage`
--

INSERT INTO `RedirectorPage` (`ID`, `RedirectionType`, `ExternalURL`, `LinkToID`) VALUES
(28, 'Internal', NULL, 6);

-- --------------------------------------------------------

--
-- Table structure for table `RedirectorPage_Live`
--

CREATE TABLE IF NOT EXISTS `RedirectorPage_Live` (
`ID` int(11) NOT NULL,
  `RedirectionType` enum('Internal','External') CHARACTER SET utf8 DEFAULT 'Internal',
  `ExternalURL` varchar(2083) CHARACTER SET utf8 DEFAULT NULL,
  `LinkToID` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `RedirectorPage_Live`
--

INSERT INTO `RedirectorPage_Live` (`ID`, `RedirectionType`, `ExternalURL`, `LinkToID`) VALUES
(28, 'Internal', NULL, 6);

-- --------------------------------------------------------

--
-- Table structure for table `RedirectorPage_versions`
--

CREATE TABLE IF NOT EXISTS `RedirectorPage_versions` (
`ID` int(11) NOT NULL,
  `RecordID` int(11) NOT NULL DEFAULT '0',
  `Version` int(11) NOT NULL DEFAULT '0',
  `RedirectionType` enum('Internal','External') CHARACTER SET utf8 DEFAULT 'Internal',
  `ExternalURL` varchar(2083) CHARACTER SET utf8 DEFAULT NULL,
  `LinkToID` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `RedirectorPage_versions`
--

INSERT INTO `RedirectorPage_versions` (`ID`, `RecordID`, `Version`, `RedirectionType`, `ExternalURL`, `LinkToID`) VALUES
(1, 28, 1, 'Internal', NULL, 0),
(2, 28, 2, 'Internal', NULL, 6);

-- --------------------------------------------------------

--
-- Table structure for table `RSSWidget`
--

CREATE TABLE IF NOT EXISTS `RSSWidget` (
`ID` int(11) NOT NULL,
  `RSSTitle` mediumtext CHARACTER SET utf8,
  `RssUrl` mediumtext CHARACTER SET utf8,
  `NumberToShow` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `SiteConfig`
--

CREATE TABLE IF NOT EXISTS `SiteConfig` (
`ID` int(11) NOT NULL,
  `ClassName` enum('SiteConfig') CHARACTER SET utf8 DEFAULT 'SiteConfig',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `Title` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Tagline` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Theme` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `CanViewType` enum('Anyone','LoggedInUsers','OnlyTheseUsers') CHARACTER SET utf8 DEFAULT 'Anyone',
  `CanEditType` enum('LoggedInUsers','OnlyTheseUsers') CHARACTER SET utf8 DEFAULT 'LoggedInUsers',
  `CanCreateTopLevelType` enum('LoggedInUsers','OnlyTheseUsers') CHARACTER SET utf8 DEFAULT 'LoggedInUsers',
  `CopyrightText` mediumtext CHARACTER SET utf8,
  `SocialFB` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `SocialTW` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `SocialLI` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `FooterWidgetID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `SiteConfig`
--

INSERT INTO `SiteConfig` (`ID`, `ClassName`, `Created`, `LastEdited`, `Title`, `Tagline`, `Theme`, `CanViewType`, `CanEditType`, `CanCreateTopLevelType`, `CopyrightText`, `SocialFB`, `SocialTW`, `SocialLI`, `FooterWidgetID`) VALUES
(1, 'SiteConfig', '2015-01-26 04:46:25', '2015-03-06 21:17:29', 'SimLine', 'Permium Boostrap Template', NULL, 'Anyone', 'LoggedInUsers', 'LoggedInUsers', '<p>Copyright 2014 by SimLine - All Rights Reserved.</p>', 'https://facebook.com', 'https://twitter.com', 'https://linkedin.com', 15);

-- --------------------------------------------------------

--
-- Table structure for table `SiteConfig_CreateTopLevelGroups`
--

CREATE TABLE IF NOT EXISTS `SiteConfig_CreateTopLevelGroups` (
`ID` int(11) NOT NULL,
  `SiteConfigID` int(11) NOT NULL DEFAULT '0',
  `GroupID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `SiteConfig_EditorGroups`
--

CREATE TABLE IF NOT EXISTS `SiteConfig_EditorGroups` (
`ID` int(11) NOT NULL,
  `SiteConfigID` int(11) NOT NULL DEFAULT '0',
  `GroupID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `SiteConfig_ViewerGroups`
--

CREATE TABLE IF NOT EXISTS `SiteConfig_ViewerGroups` (
`ID` int(11) NOT NULL,
  `SiteConfigID` int(11) NOT NULL DEFAULT '0',
  `GroupID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `SiteTree`
--

CREATE TABLE IF NOT EXISTS `SiteTree` (
`ID` int(11) NOT NULL,
  `ClassName` enum('SiteTree','Page','Blog','BlogPost','BlogEntry','ErrorPage','RedirectorPage','VirtualPage','UserDefinedForm','ContactPage','AboutPage','HelpArticle','HelpPage','HomePage','PortfolioItem','PortfolioPage','ServicePage','TimelineItem','TimelinePage','BlogTree','BlogHolder') CHARACTER SET utf8 DEFAULT 'SiteTree',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `URLSegment` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Title` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `MenuTitle` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `Content` mediumtext CHARACTER SET utf8,
  `MetaDescription` mediumtext CHARACTER SET utf8,
  `ExtraMeta` mediumtext CHARACTER SET utf8,
  `ShowInMenus` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ShowInSearch` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `Sort` int(11) NOT NULL DEFAULT '0',
  `HasBrokenFile` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `HasBrokenLink` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ReportClass` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `CanViewType` enum('Anyone','LoggedInUsers','OnlyTheseUsers','Inherit') CHARACTER SET utf8 DEFAULT 'Inherit',
  `CanEditType` enum('LoggedInUsers','OnlyTheseUsers','Inherit') CHARACTER SET utf8 DEFAULT 'Inherit',
  `ProvideComments` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `Version` int(11) NOT NULL DEFAULT '0',
  `ParentID` int(11) NOT NULL DEFAULT '0',
  `ModerationRequired` enum('None','Required','NonMembersOnly') CHARACTER SET utf8 DEFAULT 'None',
  `CommentsRequireLogin` tinyint(1) unsigned NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=30 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `SiteTree`
--

INSERT INTO `SiteTree` (`ID`, `ClassName`, `Created`, `LastEdited`, `URLSegment`, `Title`, `MenuTitle`, `Content`, `MetaDescription`, `ExtraMeta`, `ShowInMenus`, `ShowInSearch`, `Sort`, `HasBrokenFile`, `HasBrokenLink`, `ReportClass`, `CanViewType`, `CanEditType`, `ProvideComments`, `Version`, `ParentID`, `ModerationRequired`, `CommentsRequireLogin`) VALUES
(1, 'HomePage', '2015-01-26 04:46:25', '2015-03-06 18:48:57', 'home', 'Home', NULL, '<p class="lead" style="text-align: center;">Look No Further. Get It Now.</p>\n<p>[button,iconClass="fa fa-download",wrapperClass="well",classes="btn btn-grand btn-block btn-blue",link="https://google.com",newWindow="true",noFollow="true",location="left"]Download[/button]</p>', NULL, NULL, 1, 1, 1, 0, 0, NULL, 'Inherit', 'Inherit', 0, 25, 0, 'None', 0),
(2, 'AboutPage', '2015-01-26 04:46:26', '2015-03-12 20:35:53', 'about-us', 'About Us', NULL, '<p class="lead" style="text-align: center;"><span style="color: #ec7263;">Oneline is a modern fully responsive HTML5 template perfect for your web &amp; mobile apps.</span></p>\n<p class="text-center">Sed at porta tellus. Sed sit amet ipsum non dolor tincidunt vestibulum eget et urna. In et placerat eros. Curabitur tristique lacinia tortor ut ornare. Proin vehicula rhoncus fermentum. Integer scelerisque aliquam turpis. Quisque pellentesque, sem vel molestie posuere, orci sapien interdum mauris, eget condimentum purus arcu ut augue.</p>\n<p class="text-center"> </p>\n<table class="fluid-table col-md-12"><tbody><tr valign="top"><td class="col-md-6">\n<p>[video,id="67449472",service="vimeo",width="480",height="320",location="left"]</p>\n</td>\n<td class="col-md-6">\n<div class="well">This video is fully responsive. It will automatically adjust its size according to the parent block width.</div>\n<ul class="ft-list"><li>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>\n<li>Donec vulputate tellus quis volutpat congue.</li>\n<li>Sed ultrices eros eu euismod semper.</li>\n<li>Integer vulputate mauris in eleifend laoreet.</li>\n<li>Donec vulputate tellus quis volutpat congue.</li>\n<li>Sed ultrices eros eu euismod semper.</li>\n</ul></td>\n</tr></tbody></table>', NULL, NULL, 1, 1, 1, 0, 0, NULL, 'Inherit', 'Inherit', 0, 38, 8, 'None', 0),
(20, 'ServicePage', '2015-03-12 21:25:41', '2015-03-17 18:28:06', 'services', 'Services', NULL, '<table class="fluid-table col-md-12"><tbody><tr valign="top"><td class="col-md-7">\n<h4>Company Introduction</h4>\n<p>Sed at porta tellus. Sed sit amet ipsum non dolor tincidunt vestibulum eget et urna. In et placerat eros. Curabitur tristique lacinia tortor ut ornare. Proin vehicula rhoncus fermentum. Integer scelerisque aliquam turpis. Quisque pellentesque, sem vel molestie posuere, orci sapien interdum mauris, eget condimentum purus arcu ut augue.</p>\n<hr><p>[button,link="contact-us/",classes="btn btn-lg btn-red",location="left"]Contact us[/button]</p>\n</td>\n<td class="col-md-5">\n<h4>Video guide</h4>\n<p>[video,id="67449472",service="vimeo",width="480",height="320",location="left"]</p>\n</td>\n</tr></tbody></table><p> </p>\n<div class="row">\n<div class="col-sm-12">\n<h1 class="title-block">Main Services Provided By Your Company</h1>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent imperdiet pretium elit non lacinia. Integer in consequat metus. Curabitur dapibus velit sed scelerisque fermentum. Proin interdum purus nec pharetra semper.</p>\n</div>\n</div>', NULL, NULL, 1, 1, 4, 0, 0, NULL, 'Inherit', 'Inherit', 0, 14, 8, 'None', 0),
(3, 'ContactPage', '2015-01-26 04:46:26', '2015-03-16 02:23:26', 'contact-us', 'Contact Us', NULL, '<h3 class="title-block second-child">Drop Us A Few Lines</h3>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin congue tellus ut velit mollis condimentum. Nulla egestas neque sed odio varius facilisis. Donec ac metus gravida leo dictum porttitor.</p>\n<hr>', NULL, NULL, 1, 1, 2, 0, 0, NULL, 'Inherit', 'Inherit', 0, 12, 8, 'None', 0),
(4, 'Blog', '2015-01-26 04:46:26', '2015-03-18 21:45:32', 'blog', 'Blog', NULL, NULL, NULL, NULL, 1, 1, 4, 0, 0, NULL, 'Inherit', 'Inherit', 0, 6, 0, 'None', 0),
(5, 'BlogPost', '2015-01-26 04:46:26', '2015-03-14 13:34:12', 'sample-blog-entry', 'SilverStripe blog module successfully installed', NULL, '<p>Congratulations, the SilverStripe blog module has been successfully installed. This blog entry can be safely deleted. You can configure aspects of your blog in <a href="admin">the CMS</a>.</p>', NULL, NULL, 0, 1, 1, 0, 0, NULL, 'Inherit', 'Inherit', 1, 5, 4, 'None', 0),
(6, 'ErrorPage', '2015-01-26 04:46:26', '2015-01-26 04:46:27', 'page-not-found', 'Page not found', NULL, '<p>Sorry, it seems you were trying to access a page that doesn''t exist.</p><p>Please check the spelling of the URL you were trying to access and try again.</p>', NULL, NULL, 0, 0, 5, 0, 0, NULL, 'Inherit', 'Inherit', 0, 1, 0, 'None', 0),
(7, 'ErrorPage', '2015-01-26 04:46:27', '2015-01-26 04:46:27', 'server-error', 'Server error', NULL, '<p>Sorry, there was a problem with handling your request.</p>', NULL, NULL, 0, 0, 6, 0, 0, NULL, 'Inherit', 'Inherit', 0, 1, 0, 'None', 0),
(8, 'Page', '2015-01-27 09:42:21', '2015-01-27 09:43:28', 'pages', 'Pages', NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus. Donec iaculis, est ut adipiscing cursus, lectus turpis tristique massa, faucibus faucibus urna odio nec ante. Integer magna purus, tincidunt ut vestibulum eget, mattis sit amet purus. Donec interdum orci nec felis pulvinar hendrerit. Donec suscipit turpis et libero fermentum non venenatis massa eleifend. Maecenas fringilla consectetur risus vel venenatis. Sed tincidunt tellus sit amet tellus mattis a malesuada dui vulputate. Aenean ut orci metus, vitae bibendum diam. Aliquam sit amet leo sed est convallis blandit vel sed libero. Integer leo nisi, viverra sit amet congue in, suscipit ac orci. Ut ut nulla at nulla posuere rutrum. Etiam cursus ultricies placerat. Praesent eu tellus nec enim pulvinar porta. Maecenas faucibus interdum turpis, sed rhoncus ante luctus vel. Duis ut orci nec metus lobortis commodo. Donec aliquet, leo non vestibulum dictum, ante justo molestie leo, id eleifend diam odio nec tellus. Cras consequat nunc a quam interdum luctus mollis velit viverra.</p>\n<p>Nulla at leo eros, nec porttitor erat. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed venenatis facilisis dolor id pulvinar. Suspendisse tincidunt, arcu vestibulum venenatis blandit, arcu quam scelerisque nibh, nec imperdiet tellus tellus nec mauris. Suspendisse cursus varius velit, vel ultricies tortor fringilla pretium. Pellentesque posuere lobortis vehicula. Proin scelerisque dapibus eros, eget iaculis metus ultrices vel. Morbi malesuada ligula sit amet mauris mollis sed vulputate tellus fringilla. Maecenas at velit sem. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum in arcu quis odio ullamcorper vulputate. Etiam tempor placerat lorem, id rhoncus erat vulputate sed. Pellentesque dapibus sollicitudin ipsum. Aliquam sollicitudin augue sit amet sapien tristique vel tristique nisl auctor. Aliquam porta, dui quis molestie vehicula, sem est luctus felis, id suscipit massa ipsum sed elit. Quisque vehicula nulla nec felis egestas id pellentesque risus condimentum. Nam varius purus quis erat egestas feugiat. Duis a odio eros, a vehicula sapien. Pellentesque ac dolor in velit aliquam gravida.</p>\n<p>Donec ut bibendum risus. Sed nisl turpis, pulvinar ut bibendum non, dignissim quis nibh. Cras interdum dictum dui, at venenatis magna auctor a. In a turpis risus, quis mollis augue. Mauris cursus, metus eu accumsan cursus, arcu sapien posuere elit, in viverra nisi diam non arcu. Maecenas ultricies commodo diam, sit amet mattis sapien accumsan ut. Vivamus a felis in enim porta congue. Cras dui tortor, adipiscing imperdiet tempus eu, adipiscing id tellus. Quisque id varius metus. Suspendisse ac euismod neque. Nullam orci dui, tincidunt nec mollis quis, aliquet nec risus. Pellentesque et neque felis, a ullamcorper lacus. Quisque mollis, odio sed fringilla rutrum, elit ipsum adipiscing turpis, sit amet mollis purus neque sed nibh. Donec vitae arcu lorem. Suspendisse id elit felis, non condimentum mauris. Nullam ullamcorper volutpat urna vel feugiat.</p>', NULL, NULL, 1, 1, 2, 0, 0, NULL, 'Inherit', 'Inherit', 0, 3, 0, 'None', 0),
(9, 'PortfolioPage', '2015-01-27 09:45:10', '2015-03-18 19:00:04', 'portfolio', 'Portfolio', NULL, '<p class="lead" style="text-align: center;"><span style="color: #ec7263;">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris nec velit consequat, pharetra risus et, tempus mi. </span></p>', NULL, NULL, 1, 1, 3, 0, 0, NULL, 'Inherit', 'Inherit', 0, 8, 0, 'None', 0),
(10, 'PortfolioItem', '2015-01-28 20:07:31', '2015-03-16 18:29:08', 'portfolio-item-1', 'Portfolio Item #1', NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus. Donec iaculis, est ut adipiscing cursus, lectus turpis tristique massa, faucibus faucibus urna odio nec ante. Integer magna purus, tincidunt ut vestibulum eget, mattis sit amet purus. Donec interdum orci nec felis pulvinar hendrerit. Donec suscipit turpis et libero fermentum non venenatis massa eleifend. Maecenas fringilla consectetur risus vel venenatis. Sed tincidunt tellus sit amet tellus mattis a malesuada dui vulputate. Aenean ut orci metus, vitae bibendum diam. Aliquam sit amet leo sed est convallis blandit vel sed libero. Integer leo nisi, viverra sit amet congue in, suscipit ac orci. Ut ut nulla at nulla posuere rutrum. Etiam cursus ultricies placerat. Praesent eu tellus nec enim pulvinar porta. Maecenas faucibus interdum turpis, sed rhoncus ante luctus vel. Duis ut orci nec metus lobortis commodo. Donec aliquet, leo non vestibulum dictum, ante justo molestie leo, id eleifend diam odio nec tellus. Cras consequat nunc a quam interdum luctus mollis velit viverra.</p>', NULL, NULL, 1, 1, 2, 0, 0, NULL, 'Inherit', 'Inherit', 0, 8, 9, 'None', 0),
(11, 'PortfolioItem', '2015-01-28 20:07:31', '2015-03-19 09:58:51', 'portfolio-item-2', 'Portfolio Item #2', NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus. Donec iaculis, est ut adipiscing cursus, lectus turpis tristique massa, faucibus faucibus urna odio nec ante. Integer magna purus, tincidunt ut vestibulum eget, mattis sit amet purus. Donec interdum orci nec felis pulvinar hendrerit. Donec suscipit turpis et libero fermentum non venenatis massa eleifend. Maecenas fringilla consectetur risus vel venenatis. Sed tincidunt tellus sit amet tellus mattis a malesuada dui vulputate. Aenean ut orci metus, vitae bibendum diam. Aliquam sit amet leo sed est convallis blandit vel sed libero. Integer leo nisi, viverra sit amet congue in, suscipit ac orci. Ut ut nulla at nulla posuere rutrum. Etiam cursus ultricies placerat. Praesent eu tellus nec enim pulvinar porta. Maecenas faucibus interdum turpis, sed rhoncus ante luctus vel. Duis ut orci nec metus lobortis commodo. Donec aliquet, leo non vestibulum dictum, ante justo molestie leo, id eleifend diam odio nec tellus. Cras consequat nunc a quam interdum luctus mollis velit viverra.</p>', NULL, NULL, 1, 1, 1, 0, 0, NULL, 'Inherit', 'Inherit', 0, 5, 9, 'None', 0),
(12, 'PortfolioItem', '2015-01-28 20:07:31', '2015-03-18 19:26:00', 'portfolio-item-3', 'Portfolio Item #3', NULL, '<p>Integer sodales, lectus et elementum volutpat, ipsum purus tristique dolor, non scelerisque diam sem id neque. Etiam sit amet eros magna. Mauris purus nunc, venenatis vitae erat ac, sagittis consectetur dolor.</p>', NULL, NULL, 1, 1, 3, 0, 0, NULL, 'Inherit', 'Inherit', 0, 4, 9, 'None', 0),
(29, 'BlogPost', '2015-03-18 20:25:32', '2015-03-20 11:05:55', 'lorem-ipsum-dolor-sit-amet-consectetur-adipiscing-elit', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit', NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus. Donec iaculis, est ut adipiscing cursus, lectus turpis tristique massa, faucibus faucibus urna odio nec ante. Integer magna purus, tincidunt ut vestibulum eget, mattis sit amet purus. Donec interdum orci nec felis pulvinar hendrerit. Donec suscipit turpis et libero fermentum non venenatis massa eleifend. Maecenas fringilla consectetur risus vel venenatis. Sed tincidunt tellus sit amet tellus mattis a malesuada dui vulputate. Aenean ut orci metus, vitae bibendum diam. Aliquam sit amet leo sed est convallis blandit vel sed libero. Integer leo nisi, viverra sit amet congue in, suscipit ac orci. Ut ut nulla at nulla posuere rutrum. Etiam cursus ultricies placerat. Praesent eu tellus nec enim pulvinar porta. Maecenas faucibus interdum turpis, sed rhoncus ante luctus vel. Duis ut orci nec metus lobortis commodo. Donec aliquet, leo non vestibulum dictum, ante justo molestie leo, id eleifend diam odio nec tellus. Cras consequat nunc a quam interdum luctus mollis velit viverra.</p>\n<p>Nulla at leo eros, nec porttitor erat. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed venenatis facilisis dolor id pulvinar. Suspendisse tincidunt, arcu vestibulum venenatis blandit, arcu quam scelerisque nibh, nec imperdiet tellus tellus nec mauris. Suspendisse cursus varius velit, vel ultricies tortor fringilla pretium. Pellentesque posuere lobortis vehicula. Proin scelerisque dapibus eros, eget iaculis metus ultrices vel. Morbi malesuada ligula sit amet mauris mollis sed vulputate tellus fringilla. Maecenas at velit sem. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum in arcu quis odio ullamcorper vulputate. Etiam tempor placerat lorem, id rhoncus erat vulputate sed. Pellentesque dapibus sollicitudin ipsum. Aliquam sollicitudin augue sit amet sapien tristique vel tristique nisl auctor. Aliquam porta, dui quis molestie vehicula, sem est luctus felis, id suscipit massa ipsum sed elit. Quisque vehicula nulla nec felis egestas id pellentesque risus condimentum. Nam varius purus quis erat egestas feugiat. Duis a odio eros, a vehicula sapien. Pellentesque ac dolor in velit aliquam gravida.</p>\n<p>Donec ut bibendum risus. Sed nisl turpis, pulvinar ut bibendum non, dignissim quis nibh. Cras interdum dictum dui, at venenatis magna auctor a. In a turpis risus, quis mollis augue. Mauris cursus, metus eu accumsan cursus, arcu sapien posuere elit, in viverra nisi diam non arcu. Maecenas ultricies commodo diam, sit amet mattis sapien accumsan ut. Vivamus a felis in enim porta congue. Cras dui tortor, adipiscing imperdiet tempus eu, adipiscing id tellus. Quisque id varius metus. Suspendisse ac euismod neque. Nullam orci dui, tincidunt nec mollis quis, aliquet nec risus. Pellentesque et neque felis, a ullamcorper lacus. Quisque mollis, odio sed fringilla rutrum, elit ipsum adipiscing turpis, sit amet mollis purus neque sed nibh. Donec vitae arcu lorem. Suspendisse id elit felis, non condimentum mauris. Nullam ullamcorper volutpat urna vel feugiat.</p>', NULL, NULL, 0, 1, 2, 0, 0, NULL, 'Inherit', 'Inherit', 1, 4, 4, 'None', 0),
(13, 'PortfolioItem', '2015-01-28 20:07:31', '2015-03-16 18:29:08', 'portfolio-item-4', 'Portfolio Item #4', NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus. Donec iaculis, est ut adipiscing cursus, lectus turpis tristique massa, faucibus faucibus urna odio nec ante. Integer magna purus, tincidunt ut vestibulum eget, mattis sit amet purus. Donec interdum orci nec felis pulvinar hendrerit. Donec suscipit turpis et libero fermentum non venenatis massa eleifend. Maecenas fringilla consectetur risus vel venenatis. Sed tincidunt tellus sit amet tellus mattis a malesuada dui vulputate. Aenean ut orci metus, vitae bibendum diam. Aliquam sit amet leo sed est convallis blandit vel sed libero. Integer leo nisi, viverra sit amet congue in, suscipit ac orci. Ut ut nulla at nulla posuere rutrum. Etiam cursus ultricies placerat. Praesent eu tellus nec enim pulvinar porta. Maecenas faucibus interdum turpis, sed rhoncus ante luctus vel. Duis ut orci nec metus lobortis commodo. Donec aliquet, leo non vestibulum dictum, ante justo molestie leo, id eleifend diam odio nec tellus. Cras consequat nunc a quam interdum luctus mollis velit viverra.</p>', NULL, NULL, 1, 1, 4, 0, 0, NULL, 'Inherit', 'Inherit', 0, 1, 9, 'None', 0),
(14, 'PortfolioItem', '2015-01-28 20:07:31', '2015-03-16 18:29:08', 'portfolio-item-5', 'Portfolio Item #5', NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus. Donec iaculis, est ut adipiscing cursus, lectus turpis tristique massa, faucibus faucibus urna odio nec ante. Integer magna purus, tincidunt ut vestibulum eget, mattis sit amet purus. Donec interdum orci nec felis pulvinar hendrerit. Donec suscipit turpis et libero fermentum non venenatis massa eleifend. Maecenas fringilla consectetur risus vel venenatis. Sed tincidunt tellus sit amet tellus mattis a malesuada dui vulputate. Aenean ut orci metus, vitae bibendum diam. Aliquam sit amet leo sed est convallis blandit vel sed libero. Integer leo nisi, viverra sit amet congue in, suscipit ac orci. Ut ut nulla at nulla posuere rutrum. Etiam cursus ultricies placerat. Praesent eu tellus nec enim pulvinar porta. Maecenas faucibus interdum turpis, sed rhoncus ante luctus vel. Duis ut orci nec metus lobortis commodo. Donec aliquet, leo non vestibulum dictum, ante justo molestie leo, id eleifend diam odio nec tellus. Cras consequat nunc a quam interdum luctus mollis velit viverra.</p>', NULL, NULL, 1, 1, 5, 0, 0, NULL, 'Inherit', 'Inherit', 0, 1, 9, 'None', 0),
(15, 'PortfolioItem', '2015-01-28 20:07:31', '2015-03-16 18:29:08', 'portfolio-item-6', 'Portfolio Item #6', NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus. Donec iaculis, est ut adipiscing cursus, lectus turpis tristique massa, faucibus faucibus urna odio nec ante. Integer magna purus, tincidunt ut vestibulum eget, mattis sit amet purus. Donec interdum orci nec felis pulvinar hendrerit. Donec suscipit turpis et libero fermentum non venenatis massa eleifend. Maecenas fringilla consectetur risus vel venenatis. Sed tincidunt tellus sit amet tellus mattis a malesuada dui vulputate. Aenean ut orci metus, vitae bibendum diam. Aliquam sit amet leo sed est convallis blandit vel sed libero. Integer leo nisi, viverra sit amet congue in, suscipit ac orci. Ut ut nulla at nulla posuere rutrum. Etiam cursus ultricies placerat. Praesent eu tellus nec enim pulvinar porta. Maecenas faucibus interdum turpis, sed rhoncus ante luctus vel. Duis ut orci nec metus lobortis commodo. Donec aliquet, leo non vestibulum dictum, ante justo molestie leo, id eleifend diam odio nec tellus. Cras consequat nunc a quam interdum luctus mollis velit viverra.</p>', NULL, NULL, 1, 1, 6, 0, 0, NULL, 'Inherit', 'Inherit', 0, 1, 9, 'None', 0),
(16, 'TimelinePage', '2015-02-08 18:05:28', '2015-03-17 19:33:52', 'timeline', 'Timeline', NULL, '<h2 class="title-block text-center">Timeline is a great way to showcase your company history, share news or events</h2>\n<p class="text-center">Donec tincidunt nec mi eu venenatis. Nulla facilisi. Maecenas venenatis condimentum porttitor. Aliquam erat volutpat. In ac mollis odio. Praesent ac mi nisi. Nulla congue mi at porttitor ultrices. Nulla pellentesque placerat elit, sit amet egestas mi consectetur eleifend. Integer molestie ultricies libero ut consectetur. Maecenas consectetur quis elit quis consequat. Sed tincidunt nulla in lorem ullamcorper, ut aliquam odio malesuada.</p>', NULL, NULL, 1, 1, 5, 0, 0, NULL, 'Inherit', 'Inherit', 0, 4, 8, 'None', 0),
(17, 'TimelineItem', '2015-02-08 18:05:54', '2015-02-10 18:45:26', 'event-001', 'Event 001', NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus. Donec iaculis, est ut adipiscing cursus, lectus turpis tristique massa, faucibus faucibus urna odio nec ante. Integer magna purus, tincidunt ut vestibulum eget, mattis sit amet purus. Donec interdum orci nec felis pulvinar hendrerit. Donec suscipit turpis et libero fermentum non venenatis massa eleifend. Maecenas fringilla consectetur risus vel venenatis. Sed tincidunt tellus sit amet tellus mattis a malesuada dui vulputate. Aenean ut orci metus, vitae bibendum diam. Aliquam sit amet leo sed est convallis blandit vel sed libero. Integer leo nisi, viverra sit amet congue in, suscipit ac orci. Ut ut nulla at nulla posuere rutrum. Etiam cursus ultricies placerat. Praesent eu tellus nec enim pulvinar porta. Maecenas faucibus interdum turpis, sed rhoncus ante luctus vel. Duis ut orci nec metus lobortis commodo. Donec aliquet, leo non vestibulum dictum, ante justo molestie leo, id eleifend diam odio nec tellus. Cras consequat nunc a quam interdum luctus mollis velit viverra.</p>\n<p>Nulla at leo eros, nec porttitor erat. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed venenatis facilisis dolor id pulvinar. Suspendisse tincidunt, arcu vestibulum venenatis blandit, arcu quam scelerisque nibh, nec imperdiet tellus tellus nec mauris. Suspendisse cursus varius velit, vel ultricies tortor fringilla pretium. Pellentesque posuere lobortis vehicula. Proin scelerisque dapibus eros, eget iaculis metus ultrices vel. Morbi malesuada ligula sit amet mauris mollis sed vulputate tellus fringilla. Maecenas at velit sem. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum in arcu quis odio ullamcorper vulputate. Etiam tempor placerat lorem, id rhoncus erat vulputate sed. Pellentesque dapibus sollicitudin ipsum. Aliquam sollicitudin augue sit amet sapien tristique vel tristique nisl auctor. Aliquam porta, dui quis molestie vehicula, sem est luctus felis, id suscipit massa ipsum sed elit. Quisque vehicula nulla nec felis egestas id pellentesque risus condimentum. Nam varius purus quis erat egestas feugiat. Duis a odio eros, a vehicula sapien. Pellentesque ac dolor in velit aliquam gravida.</p>\n<p>Donec ut bibendum risus. Sed nisl turpis, pulvinar ut bibendum non, dignissim quis nibh. Cras interdum dictum dui, at venenatis magna auctor a. In a turpis risus, quis mollis augue. Mauris cursus, metus eu accumsan cursus, arcu sapien posuere elit, in viverra nisi diam non arcu. Maecenas ultricies commodo diam, sit amet mattis sapien accumsan ut. Vivamus a felis in enim porta congue. Cras dui tortor, adipiscing imperdiet tempus eu, adipiscing id tellus. Quisque id varius metus. Suspendisse ac euismod neque. Nullam orci dui, tincidunt nec mollis quis, aliquet nec risus. Pellentesque et neque felis, a ullamcorper lacus. Quisque mollis, odio sed fringilla rutrum, elit ipsum adipiscing turpis, sit amet mollis purus neque sed nibh. Donec vitae arcu lorem. Suspendisse id elit felis, non condimentum mauris. Nullam ullamcorper volutpat urna vel feugiat.</p>', NULL, NULL, 1, 1, 1, 0, 0, NULL, 'Inherit', 'Inherit', 0, 10, 16, 'None', 0),
(18, 'TimelineItem', '2015-02-08 18:05:54', '2015-02-10 18:37:41', 'event-2', 'Event 002', NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus. Donec iaculis, est ut adipiscing cursus, lectus turpis tristique massa, faucibus faucibus urna odio nec ante. Integer magna purus, tincidunt ut vestibulum eget, mattis sit amet purus. Donec interdum orci nec felis pulvinar hendrerit. Donec suscipit turpis et libero fermentum non venenatis massa eleifend. Maecenas fringilla consectetur risus vel venenatis. Sed tincidunt tellus sit amet tellus mattis a malesuada dui vulputate. Aenean ut orci metus, vitae bibendum diam. Aliquam sit amet leo sed est convallis blandit vel sed libero. Integer leo nisi, viverra sit amet congue in, suscipit ac orci. Ut ut nulla at nulla posuere rutrum. Etiam cursus ultricies placerat. Praesent eu tellus nec enim pulvinar porta. Maecenas faucibus interdum turpis, sed rhoncus ante luctus vel. Duis ut orci nec metus lobortis commodo. Donec aliquet, leo non vestibulum dictum, ante justo molestie leo, id eleifend diam odio nec tellus. Cras consequat nunc a quam interdum luctus mollis velit viverra.</p>\n<p>Nulla at leo eros, nec porttitor erat. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed venenatis facilisis dolor id pulvinar. Suspendisse tincidunt, arcu vestibulum venenatis blandit, arcu quam scelerisque nibh, nec imperdiet tellus tellus nec mauris. Suspendisse cursus varius velit, vel ultricies tortor fringilla pretium. Pellentesque posuere lobortis vehicula. Proin scelerisque dapibus eros, eget iaculis metus ultrices vel. Morbi malesuada ligula sit amet mauris mollis sed vulputate tellus fringilla. Maecenas at velit sem. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum in arcu quis odio ullamcorper vulputate. Etiam tempor placerat lorem, id rhoncus erat vulputate sed. Pellentesque dapibus sollicitudin ipsum. Aliquam sollicitudin augue sit amet sapien tristique vel tristique nisl auctor. Aliquam porta, dui quis molestie vehicula, sem est luctus felis, id suscipit massa ipsum sed elit. Quisque vehicula nulla nec felis egestas id pellentesque risus condimentum. Nam varius purus quis erat egestas feugiat. Duis a odio eros, a vehicula sapien. Pellentesque ac dolor in velit aliquam gravida.</p>\n<p>Donec ut bibendum risus. Sed nisl turpis, pulvinar ut bibendum non, dignissim quis nibh. Cras interdum dictum dui, at venenatis magna auctor a. In a turpis risus, quis mollis augue. Mauris cursus, metus eu accumsan cursus, arcu sapien posuere elit, in viverra nisi diam non arcu. Maecenas ultricies commodo diam, sit amet mattis sapien accumsan ut. Vivamus a felis in enim porta congue. Cras dui tortor, adipiscing imperdiet tempus eu, adipiscing id tellus. Quisque id varius metus. Suspendisse ac euismod neque. Nullam orci dui, tincidunt nec mollis quis, aliquet nec risus. Pellentesque et neque felis, a ullamcorper lacus. Quisque mollis, odio sed fringilla rutrum, elit ipsum adipiscing turpis, sit amet mollis purus neque sed nibh. Donec vitae arcu lorem. Suspendisse id elit felis, non condimentum mauris. Nullam ullamcorper volutpat urna vel feugiat.</p>', NULL, NULL, 1, 1, 2, 0, 0, NULL, 'Inherit', 'Inherit', 0, 3, 16, 'None', 0),
(19, 'TimelineItem', '2015-02-08 18:05:54', '2015-03-17 19:30:33', 'event-3', 'Event 003', NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus. Donec iaculis, est ut adipiscing cursus, lectus turpis tristique massa, faucibus faucibus urna odio nec ante. Integer magna purus, tincidunt ut vestibulum eget, mattis sit amet purus. Donec interdum orci nec felis pulvinar hendrerit. Donec suscipit turpis et libero fermentum non venenatis massa eleifend. Maecenas fringilla consectetur risus vel venenatis. Sed tincidunt tellus sit amet tellus mattis a malesuada dui vulputate. Aenean ut orci metus, vitae bibendum diam. Aliquam sit amet leo sed est convallis blandit vel sed libero. Integer leo nisi, viverra sit amet congue in, suscipit ac orci. Ut ut nulla at nulla posuere rutrum. Etiam cursus ultricies placerat. Praesent eu tellus nec enim pulvinar porta. Maecenas faucibus interdum turpis, sed rhoncus ante luctus vel. Duis ut orci nec metus lobortis commodo. Donec aliquet, leo non vestibulum dictum, ante justo molestie leo, id eleifend diam odio nec tellus. Cras consequat nunc a quam interdum luctus mollis velit viverra.</p>\n<p>Nulla at leo eros, nec porttitor erat. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed venenatis facilisis dolor id pulvinar. Suspendisse tincidunt, arcu vestibulum venenatis blandit, arcu quam scelerisque nibh, nec imperdiet tellus tellus nec mauris. Suspendisse cursus varius velit, vel ultricies tortor fringilla pretium. Pellentesque posuere lobortis vehicula. Proin scelerisque dapibus eros, eget iaculis metus ultrices vel. Morbi malesuada ligula sit amet mauris mollis sed vulputate tellus fringilla. Maecenas at velit sem. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum in arcu quis odio ullamcorper vulputate. Etiam tempor placerat lorem, id rhoncus erat vulputate sed. Pellentesque dapibus sollicitudin ipsum. Aliquam sollicitudin augue sit amet sapien tristique vel tristique nisl auctor. Aliquam porta, dui quis molestie vehicula, sem est luctus felis, id suscipit massa ipsum sed elit. Quisque vehicula nulla nec felis egestas id pellentesque risus condimentum. Nam varius purus quis erat egestas feugiat. Duis a odio eros, a vehicula sapien. Pellentesque ac dolor in velit aliquam gravida.</p>\n<p>Donec ut bibendum risus. Sed nisl turpis, pulvinar ut bibendum non, dignissim quis nibh. Cras interdum dictum dui, at venenatis magna auctor a. In a turpis risus, quis mollis augue. Mauris cursus, metus eu accumsan cursus, arcu sapien posuere elit, in viverra nisi diam non arcu. Maecenas ultricies commodo diam, sit amet mattis sapien accumsan ut. Vivamus a felis in enim porta congue. Cras dui tortor, adipiscing imperdiet tempus eu, adipiscing id tellus. Quisque id varius metus. Suspendisse ac euismod neque. Nullam orci dui, tincidunt nec mollis quis, aliquet nec risus. Pellentesque et neque felis, a ullamcorper lacus. Quisque mollis, odio sed fringilla rutrum, elit ipsum adipiscing turpis, sit amet mollis purus neque sed nibh. Donec vitae arcu lorem. Suspendisse id elit felis, non condimentum mauris. Nullam ullamcorper volutpat urna vel feugiat.</p>', NULL, NULL, 1, 1, 3, 0, 0, NULL, 'Inherit', 'Inherit', 0, 3, 16, 'None', 0),
(21, 'HelpPage', '2015-03-16 19:24:00', '2015-03-17 18:27:38', 'help-center', 'Help Center', NULL, NULL, NULL, NULL, 1, 1, 3, 0, 0, NULL, 'Inherit', 'Inherit', 0, 3, 8, 'None', 0),
(22, 'HelpArticle', '2015-03-16 19:25:02', '2015-03-17 17:04:45', 'lorem-ipsum-dolor-sit-amet-consectetur-adipiscing-elit-ut-ac-tortor-vitae-lorem-lobortis', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut ac tortor vitae lorem lobortis', NULL, '<p>Donec massa urna, tristique sed lectus quis, suscipit ultricies velit. Curabitur pulvinar rutrum risus eu aliquet. Vestibulum at felis et ipsum lacinia fringilla. Praesent blandit ultricies velit non euismod. Integer fringilla, ipsum eu adipiscing venenatis, nisl nisl fermentum sem, nec suscipit felis arcu in augue. Nunc ac blandit lorem. Maecenas auctor justo odio, at eleifend nulla venenatis quis. Aenean semper, libero ac dictum bibendum, enim augue lacinia neque, quis aliquam lacus nulla sed nisi. Etiam eleifend scelerisque odio sit amet fermentum. Etiam at nunc est. Nam eu lobortis nulla. Pellentesque consectetur augue neque, ut porttitor massa tincidunt egestas. Fusce diam tellus, convallis rutrum faucibus porta, venenatis non velit. Nulla non convallis urna, lacinia mollis massa. Nam consequat tristique felis a egestas.</p>\n<p>Donec massa urna, tristique sed lectus quis, suscipit ultricies velit. Curabitur pulvinar rutrum risus eu aliquet. Vestibulum at felis et ipsum lacinia fringilla. Praesent blandit ultricies velit non euismod. Integer fringilla, ipsum eu adipiscing venenatis, nisl nisl fermentum sem, nec suscipit felis arcu in augue. Nunc ac blandit lorem. Maecenas auctor justo odio, at eleifend nulla venenatis quis. Aenean semper, libero ac dictum bibendum, enim augue lacinia neque, quis aliquam lacus nulla sed nisi. Etiam eleifend scelerisque odio sit amet fermentum. Etiam at nunc est. Nam eu lobortis nulla. Pellentesque consectetur augue neque, ut porttitor massa tincidunt egestas. Fusce diam tellus, convallis rutrum faucibus porta, venenatis non velit. Nulla non convallis urna, lacinia mollis massa. Nam consequat tristique felis a egestas.</p>\n<p>Donec massa urna, tristique sed lectus quis, suscipit ultricies velit. Curabitur pulvinar rutrum risus eu aliquet. Vestibulum at felis et ipsum lacinia fringilla. Praesent blandit ultricies velit non euismod. Integer fringilla, ipsum eu adipiscing venenatis, nisl nisl fermentum sem, nec suscipit felis arcu in augue. Nunc ac blandit lorem. Maecenas auctor justo odio, at eleifend nulla venenatis quis. Aenean semper, libero ac dictum bibendum, enim augue lacinia neque, quis aliquam lacus nulla sed nisi. Etiam eleifend scelerisque odio sit amet fermentum. Etiam at nunc est. Nam eu lobortis nulla. Pellentesque consectetur augue neque, ut porttitor massa tincidunt egestas. Fusce diam tellus, convallis rutrum faucibus porta, venenatis non velit. Nulla non convallis urna, lacinia mollis massa. Nam consequat tristique felis a egestas.</p>\n<p>ThemeStripe.</p>', NULL, NULL, 1, 1, 1, 0, 0, NULL, 'Inherit', 'Inherit', 1, 5, 21, 'None', 0),
(23, 'HelpArticle', '2015-03-16 19:26:59', '2015-03-16 19:27:42', 'ut-ac-tortor-vitae-lorem-lobortis-vulputate-eget-ac-nisi', 'Ut ac tortor vitae lorem lobortis vulputate eget ac nisi', NULL, '<p>Donec massa urna, tristique sed lectus quis, suscipit ultricies velit. Curabitur pulvinar rutrum risus eu aliquet. Vestibulum at felis et ipsum lacinia fringilla. Praesent blandit ultricies velit non euismod. Integer fringilla, ipsum eu adipiscing venenatis, nisl nisl fermentum sem, nec suscipit felis arcu in augue. Nunc ac blandit lorem. Maecenas auctor justo odio, at eleifend nulla venenatis quis. Aenean semper, libero ac dictum bibendum, enim augue lacinia neque, quis aliquam lacus nulla sed nisi. Etiam eleifend scelerisque odio sit amet fermentum. Etiam at nunc est. Nam eu lobortis nulla. Pellentesque consectetur augue neque, ut porttitor massa tincidunt egestas. Fusce diam tellus, convallis rutrum faucibus porta, venenatis non velit. Nulla non convallis urna, lacinia mollis massa. Nam consequat tristique felis a egestas.</p>', NULL, NULL, 1, 1, 2, 0, 0, NULL, 'Inherit', 'Inherit', 0, 2, 21, 'None', 0),
(24, 'HelpArticle', '2015-03-16 19:28:08', '2015-03-16 19:31:51', 'donec-massa-urna-tristique-sed-lectus-quis-suscipit-ultricies-velit', 'Donec massa urna, tristique sed lectus quis, suscipit ultricies velit', NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus. Donec iaculis, est ut adipiscing cursus, lectus turpis tristique massa, faucibus faucibus urna odio nec ante. Integer magna purus, tincidunt ut vestibulum eget, mattis sit amet purus. Donec interdum orci nec felis pulvinar hendrerit. Donec suscipit turpis et libero fermentum non venenatis massa eleifend. Maecenas fringilla consectetur risus vel venenatis. Sed tincidunt tellus sit amet tellus mattis a malesuada dui vulputate. Aenean ut orci metus, vitae bibendum diam. Aliquam sit amet leo sed est convallis blandit vel sed libero. Integer leo nisi, viverra sit amet congue in, suscipit ac orci. Ut ut nulla at nulla posuere rutrum. Etiam cursus ultricies placerat. Praesent eu tellus nec enim pulvinar porta. Maecenas faucibus interdum turpis, sed rhoncus ante luctus vel. Duis ut orci nec metus lobortis commodo. Donec aliquet, leo non vestibulum dictum, ante justo molestie leo, id eleifend diam odio nec tellus. Cras consequat nunc a quam interdum luctus mollis velit viverra.</p>\n<p>Nulla at leo eros, nec porttitor erat. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed venenatis facilisis dolor id pulvinar. Suspendisse tincidunt, arcu vestibulum venenatis blandit, arcu quam scelerisque nibh, nec imperdiet tellus tellus nec mauris. Suspendisse cursus varius velit, vel ultricies tortor fringilla pretium. Pellentesque posuere lobortis vehicula. Proin scelerisque dapibus eros, eget iaculis metus ultrices vel. Morbi malesuada ligula sit amet mauris mollis sed vulputate tellus fringilla. Maecenas at velit sem. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum in arcu quis odio ullamcorper vulputate. Etiam tempor placerat lorem, id rhoncus erat vulputate sed. Pellentesque dapibus sollicitudin ipsum. Aliquam sollicitudin augue sit amet sapien tristique vel tristique nisl auctor. Aliquam porta, dui quis molestie vehicula, sem est luctus felis, id suscipit massa ipsum sed elit. Quisque vehicula nulla nec felis egestas id pellentesque risus condimentum. Nam varius purus quis erat egestas feugiat. Duis a odio eros, a vehicula sapien. Pellentesque ac dolor in velit aliquam gravida.</p>\n<p>Donec ut bibendum risus. Sed nisl turpis, pulvinar ut bibendum non, dignissim quis nibh. Cras interdum dictum dui, at venenatis magna auctor a. In a turpis risus, quis mollis augue. Mauris cursus, metus eu accumsan cursus, arcu sapien posuere elit, in viverra nisi diam non arcu. Maecenas ultricies commodo diam, sit amet mattis sapien accumsan ut. Vivamus a felis in enim porta congue. Cras dui tortor, adipiscing imperdiet tempus eu, adipiscing id tellus. Quisque id varius metus. Suspendisse ac euismod neque. Nullam orci dui, tincidunt nec mollis quis, aliquet nec risus. Pellentesque et neque felis, a ullamcorper lacus. Quisque mollis, odio sed fringilla rutrum, elit ipsum adipiscing turpis, sit amet mollis purus neque sed nibh. Donec vitae arcu lorem. Suspendisse id elit felis, non condimentum mauris. Nullam ullamcorper volutpat urna vel feugiat.</p>', NULL, NULL, 1, 1, 3, 0, 0, NULL, 'Inherit', 'Inherit', 0, 2, 21, 'None', 0),
(25, 'HelpArticle', '2015-03-16 19:32:05', '2015-03-16 19:33:35', 'find-your-computers-ip-address', 'Find your computer''s IP address', NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus. Donec iaculis, est ut adipiscing cursus, lectus turpis tristique massa, faucibus faucibus urna odio nec ante. Integer magna purus, tincidunt ut vestibulum eget, mattis sit amet purus. Donec interdum orci nec felis pulvinar hendrerit. Donec suscipit turpis et libero fermentum non venenatis massa eleifend. Maecenas fringilla consectetur risus vel venenatis. Sed tincidunt tellus sit amet tellus mattis a malesuada dui vulputate. Aenean ut orci metus, vitae bibendum diam. Aliquam sit amet leo sed est convallis blandit vel sed libero. Integer leo nisi, viverra sit amet congue in, suscipit ac orci. Ut ut nulla at nulla posuere rutrum. Etiam cursus ultricies placerat. Praesent eu tellus nec enim pulvinar porta. Maecenas faucibus interdum turpis, sed rhoncus ante luctus vel. Duis ut orci nec metus lobortis commodo. Donec aliquet, leo non vestibulum dictum, ante justo molestie leo, id eleifend diam odio nec tellus. Cras consequat nunc a quam interdum luctus mollis velit viverra.</p>\n<p>Nulla at leo eros, nec porttitor erat. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed venenatis facilisis dolor id pulvinar. Suspendisse tincidunt, arcu vestibulum venenatis blandit, arcu quam scelerisque nibh, nec imperdiet tellus tellus nec mauris. Suspendisse cursus varius velit, vel ultricies tortor fringilla pretium. Pellentesque posuere lobortis vehicula. Proin scelerisque dapibus eros, eget iaculis metus ultrices vel. Morbi malesuada ligula sit amet mauris mollis sed vulputate tellus fringilla. Maecenas at velit sem. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum in arcu quis odio ullamcorper vulputate. Etiam tempor placerat lorem, id rhoncus erat vulputate sed. Pellentesque dapibus sollicitudin ipsum. Aliquam sollicitudin augue sit amet sapien tristique vel tristique nisl auctor. Aliquam porta, dui quis molestie vehicula, sem est luctus felis, id suscipit massa ipsum sed elit. Quisque vehicula nulla nec felis egestas id pellentesque risus condimentum. Nam varius purus quis erat egestas feugiat. Duis a odio eros, a vehicula sapien. Pellentesque ac dolor in velit aliquam gravida.</p>\n<p>Donec ut bibendum risus. Sed nisl turpis, pulvinar ut bibendum non, dignissim quis nibh. Cras interdum dictum dui, at venenatis magna auctor a. In a turpis risus, quis mollis augue. Mauris cursus, metus eu accumsan cursus, arcu sapien posuere elit, in viverra nisi diam non arcu. Maecenas ultricies commodo diam, sit amet mattis sapien accumsan ut. Vivamus a felis in enim porta congue. Cras dui tortor, adipiscing imperdiet tempus eu, adipiscing id tellus. Quisque id varius metus. Suspendisse ac euismod neque. Nullam orci dui, tincidunt nec mollis quis, aliquet nec risus. Pellentesque et neque felis, a ullamcorper lacus. Quisque mollis, odio sed fringilla rutrum, elit ipsum adipiscing turpis, sit amet mollis purus neque sed nibh. Donec vitae arcu lorem. Suspendisse id elit felis, non condimentum mauris. Nullam ullamcorper volutpat urna vel feugiat.</p>', NULL, NULL, 1, 1, 4, 0, 0, NULL, 'Inherit', 'Inherit', 0, 3, 21, 'None', 0),
(26, 'HelpArticle', '2015-03-16 19:34:21', '2015-03-16 19:34:33', 'wired-and-wireless-network-problems', 'Wired and wireless network problems', NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus. Donec iaculis, est ut adipiscing cursus, lectus turpis tristique massa, faucibus faucibus urna odio nec ante. Integer magna purus, tincidunt ut vestibulum eget, mattis sit amet purus. Donec interdum orci nec felis pulvinar hendrerit. Donec suscipit turpis et libero fermentum non venenatis massa eleifend. Maecenas fringilla consectetur risus vel venenatis. Sed tincidunt tellus sit amet tellus mattis a malesuada dui vulputate. Aenean ut orci metus, vitae bibendum diam. Aliquam sit amet leo sed est convallis blandit vel sed libero. Integer leo nisi, viverra sit amet congue in, suscipit ac orci. Ut ut nulla at nulla posuere rutrum. Etiam cursus ultricies placerat. Praesent eu tellus nec enim pulvinar porta. Maecenas faucibus interdum turpis, sed rhoncus ante luctus vel. Duis ut orci nec metus lobortis commodo. Donec aliquet, leo non vestibulum dictum, ante justo molestie leo, id eleifend diam odio nec tellus. Cras consequat nunc a quam interdum luctus mollis velit viverra.</p>\n<p>Nulla at leo eros, nec porttitor erat. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed venenatis facilisis dolor id pulvinar. Suspendisse tincidunt, arcu vestibulum venenatis blandit, arcu quam scelerisque nibh, nec imperdiet tellus tellus nec mauris. Suspendisse cursus varius velit, vel ultricies tortor fringilla pretium. Pellentesque posuere lobortis vehicula. Proin scelerisque dapibus eros, eget iaculis metus ultrices vel. Morbi malesuada ligula sit amet mauris mollis sed vulputate tellus fringilla. Maecenas at velit sem. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum in arcu quis odio ullamcorper vulputate. Etiam tempor placerat lorem, id rhoncus erat vulputate sed. Pellentesque dapibus sollicitudin ipsum. Aliquam sollicitudin augue sit amet sapien tristique vel tristique nisl auctor. Aliquam porta, dui quis molestie vehicula, sem est luctus felis, id suscipit massa ipsum sed elit. Quisque vehicula nulla nec felis egestas id pellentesque risus condimentum. Nam varius purus quis erat egestas feugiat. Duis a odio eros, a vehicula sapien. Pellentesque ac dolor in velit aliquam gravida.</p>\n<p>Donec ut bibendum risus. Sed nisl turpis, pulvinar ut bibendum non, dignissim quis nibh. Cras interdum dictum dui, at venenatis magna auctor a. In a turpis risus, quis mollis augue. Mauris cursus, metus eu accumsan cursus, arcu sapien posuere elit, in viverra nisi diam non arcu. Maecenas ultricies commodo diam, sit amet mattis sapien accumsan ut. Vivamus a felis in enim porta congue. Cras dui tortor, adipiscing imperdiet tempus eu, adipiscing id tellus. Quisque id varius metus. Suspendisse ac euismod neque. Nullam orci dui, tincidunt nec mollis quis, aliquet nec risus. Pellentesque et neque felis, a ullamcorper lacus. Quisque mollis, odio sed fringilla rutrum, elit ipsum adipiscing turpis, sit amet mollis purus neque sed nibh. Donec vitae arcu lorem. Suspendisse id elit felis, non condimentum mauris. Nullam ullamcorper volutpat urna vel feugiat.</p>', NULL, NULL, 1, 1, 5, 0, 0, NULL, 'Inherit', 'Inherit', 0, 2, 21, 'None', 0),
(27, 'HelpArticle', '2015-03-16 19:34:41', '2015-03-16 19:35:08', 'setting-up-email', 'Setting up email', NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus. Donec iaculis, est ut adipiscing cursus, lectus turpis tristique massa, faucibus faucibus urna odio nec ante. Integer magna purus, tincidunt ut vestibulum eget, mattis sit amet purus. Donec interdum orci nec felis pulvinar hendrerit. Donec suscipit turpis et libero fermentum non venenatis massa eleifend. Maecenas fringilla consectetur risus vel venenatis. Sed tincidunt tellus sit amet tellus mattis a malesuada dui vulputate. Aenean ut orci metus, vitae bibendum diam. Aliquam sit amet leo sed est convallis blandit vel sed libero. Integer leo nisi, viverra sit amet congue in, suscipit ac orci. Ut ut nulla at nulla posuere rutrum. Etiam cursus ultricies placerat. Praesent eu tellus nec enim pulvinar porta. Maecenas faucibus interdum turpis, sed rhoncus ante luctus vel. Duis ut orci nec metus lobortis commodo. Donec aliquet, leo non vestibulum dictum, ante justo molestie leo, id eleifend diam odio nec tellus. Cras consequat nunc a quam interdum luctus mollis velit viverra.</p>\n<p>Nulla at leo eros, nec porttitor erat. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed venenatis facilisis dolor id pulvinar. Suspendisse tincidunt, arcu vestibulum venenatis blandit, arcu quam scelerisque nibh, nec imperdiet tellus tellus nec mauris. Suspendisse cursus varius velit, vel ultricies tortor fringilla pretium. Pellentesque posuere lobortis vehicula. Proin scelerisque dapibus eros, eget iaculis metus ultrices vel. Morbi malesuada ligula sit amet mauris mollis sed vulputate tellus fringilla. Maecenas at velit sem. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum in arcu quis odio ullamcorper vulputate. Etiam tempor placerat lorem, id rhoncus erat vulputate sed. Pellentesque dapibus sollicitudin ipsum. Aliquam sollicitudin augue sit amet sapien tristique vel tristique nisl auctor. Aliquam porta, dui quis molestie vehicula, sem est luctus felis, id suscipit massa ipsum sed elit. Quisque vehicula nulla nec felis egestas id pellentesque risus condimentum. Nam varius purus quis erat egestas feugiat. Duis a odio eros, a vehicula sapien. Pellentesque ac dolor in velit aliquam gravida.</p>\n<p>Donec ut bibendum risus. Sed nisl turpis, pulvinar ut bibendum non, dignissim quis nibh. Cras interdum dictum dui, at venenatis magna auctor a. In a turpis risus, quis mollis augue. Mauris cursus, metus eu accumsan cursus, arcu sapien posuere elit, in viverra nisi diam non arcu. Maecenas ultricies commodo diam, sit amet mattis sapien accumsan ut. Vivamus a felis in enim porta congue. Cras dui tortor, adipiscing imperdiet tempus eu, adipiscing id tellus. Quisque id varius metus. Suspendisse ac euismod neque. Nullam orci dui, tincidunt nec mollis quis, aliquet nec risus. Pellentesque et neque felis, a ullamcorper lacus. Quisque mollis, odio sed fringilla rutrum, elit ipsum adipiscing turpis, sit amet mollis purus neque sed nibh. Donec vitae arcu lorem. Suspendisse id elit felis, non condimentum mauris. Nullam ullamcorper volutpat urna vel feugiat.</p>', NULL, NULL, 1, 1, 6, 0, 0, NULL, 'Inherit', 'Inherit', 0, 2, 21, 'None', 0),
(28, 'RedirectorPage', '2015-03-17 20:11:10', '2015-03-17 20:11:36', '404-error-page', '404 Error Page', NULL, NULL, NULL, NULL, 1, 1, 6, 0, 0, NULL, 'Inherit', 'Inherit', 0, 2, 8, 'None', 0);

-- --------------------------------------------------------

--
-- Table structure for table `SiteTree_EditorGroups`
--

CREATE TABLE IF NOT EXISTS `SiteTree_EditorGroups` (
`ID` int(11) NOT NULL,
  `SiteTreeID` int(11) NOT NULL DEFAULT '0',
  `GroupID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `SiteTree_ImageTracking`
--

CREATE TABLE IF NOT EXISTS `SiteTree_ImageTracking` (
`ID` int(11) NOT NULL,
  `SiteTreeID` int(11) NOT NULL DEFAULT '0',
  `FileID` int(11) NOT NULL DEFAULT '0',
  `FieldName` varchar(50) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `SiteTree_LinkTracking`
--

CREATE TABLE IF NOT EXISTS `SiteTree_LinkTracking` (
`ID` int(11) NOT NULL,
  `SiteTreeID` int(11) NOT NULL DEFAULT '0',
  `ChildID` int(11) NOT NULL DEFAULT '0',
  `FieldName` varchar(50) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `SiteTree_Live`
--

CREATE TABLE IF NOT EXISTS `SiteTree_Live` (
`ID` int(11) NOT NULL,
  `ClassName` enum('SiteTree','Page','Blog','BlogPost','BlogEntry','ErrorPage','RedirectorPage','VirtualPage','UserDefinedForm','ContactPage','AboutPage','HelpArticle','HelpPage','HomePage','PortfolioItem','PortfolioPage','ServicePage','TimelineItem','TimelinePage','BlogTree','BlogHolder') CHARACTER SET utf8 DEFAULT 'SiteTree',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `URLSegment` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Title` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `MenuTitle` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `Content` mediumtext CHARACTER SET utf8,
  `MetaDescription` mediumtext CHARACTER SET utf8,
  `ExtraMeta` mediumtext CHARACTER SET utf8,
  `ShowInMenus` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ShowInSearch` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `Sort` int(11) NOT NULL DEFAULT '0',
  `HasBrokenFile` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `HasBrokenLink` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ReportClass` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `CanViewType` enum('Anyone','LoggedInUsers','OnlyTheseUsers','Inherit') CHARACTER SET utf8 DEFAULT 'Inherit',
  `CanEditType` enum('LoggedInUsers','OnlyTheseUsers','Inherit') CHARACTER SET utf8 DEFAULT 'Inherit',
  `ProvideComments` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `Version` int(11) NOT NULL DEFAULT '0',
  `ParentID` int(11) NOT NULL DEFAULT '0',
  `ModerationRequired` enum('None','Required','NonMembersOnly') CHARACTER SET utf8 DEFAULT 'None',
  `CommentsRequireLogin` tinyint(1) unsigned NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=30 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `SiteTree_Live`
--

INSERT INTO `SiteTree_Live` (`ID`, `ClassName`, `Created`, `LastEdited`, `URLSegment`, `Title`, `MenuTitle`, `Content`, `MetaDescription`, `ExtraMeta`, `ShowInMenus`, `ShowInSearch`, `Sort`, `HasBrokenFile`, `HasBrokenLink`, `ReportClass`, `CanViewType`, `CanEditType`, `ProvideComments`, `Version`, `ParentID`, `ModerationRequired`, `CommentsRequireLogin`) VALUES
(1, 'HomePage', '2015-01-26 04:46:25', '2015-03-06 18:48:57', 'home', 'Home', NULL, '<p class="lead" style="text-align: center;">Look No Further. Get It Now.</p>\n<p>[button,iconClass="fa fa-download",wrapperClass="well",classes="btn btn-grand btn-block btn-blue",link="https://google.com",newWindow="true",noFollow="true",location="left"]Download[/button]</p>', NULL, NULL, 1, 1, 1, 0, 0, NULL, 'Inherit', 'Inherit', 0, 25, 0, 'None', 0),
(2, 'AboutPage', '2015-01-26 04:46:26', '2015-03-12 20:35:53', 'about-us', 'About Us', NULL, '<p class="lead" style="text-align: center;"><span style="color: #ec7263;">Oneline is a modern fully responsive HTML5 template perfect for your web &amp; mobile apps.</span></p>\n<p class="text-center">Sed at porta tellus. Sed sit amet ipsum non dolor tincidunt vestibulum eget et urna. In et placerat eros. Curabitur tristique lacinia tortor ut ornare. Proin vehicula rhoncus fermentum. Integer scelerisque aliquam turpis. Quisque pellentesque, sem vel molestie posuere, orci sapien interdum mauris, eget condimentum purus arcu ut augue.</p>\n<p class="text-center"> </p>\n<table class="fluid-table col-md-12"><tbody><tr valign="top"><td class="col-md-6">\n<p>[video,id="67449472",service="vimeo",width="480",height="320",location="left"]</p>\n</td>\n<td class="col-md-6">\n<div class="well">This video is fully responsive. It will automatically adjust its size according to the parent block width.</div>\n<ul class="ft-list"><li>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>\n<li>Donec vulputate tellus quis volutpat congue.</li>\n<li>Sed ultrices eros eu euismod semper.</li>\n<li>Integer vulputate mauris in eleifend laoreet.</li>\n<li>Donec vulputate tellus quis volutpat congue.</li>\n<li>Sed ultrices eros eu euismod semper.</li>\n</ul></td>\n</tr></tbody></table>', NULL, NULL, 1, 1, 1, 0, 0, NULL, 'Inherit', 'Inherit', 0, 38, 8, 'None', 0),
(20, 'ServicePage', '2015-03-12 21:25:41', '2015-03-17 18:28:06', 'services', 'Services', NULL, '<table class="fluid-table col-md-12"><tbody><tr valign="top"><td class="col-md-7">\n<h4>Company Introduction</h4>\n<p>Sed at porta tellus. Sed sit amet ipsum non dolor tincidunt vestibulum eget et urna. In et placerat eros. Curabitur tristique lacinia tortor ut ornare. Proin vehicula rhoncus fermentum. Integer scelerisque aliquam turpis. Quisque pellentesque, sem vel molestie posuere, orci sapien interdum mauris, eget condimentum purus arcu ut augue.</p>\n<hr><p>[button,link="contact-us/",classes="btn btn-lg btn-red",location="left"]Contact us[/button]</p>\n</td>\n<td class="col-md-5">\n<h4>Video guide</h4>\n<p>[video,id="67449472",service="vimeo",width="480",height="320",location="left"]</p>\n</td>\n</tr></tbody></table><p> </p>\n<div class="row">\n<div class="col-sm-12">\n<h1 class="title-block">Main Services Provided By Your Company</h1>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent imperdiet pretium elit non lacinia. Integer in consequat metus. Curabitur dapibus velit sed scelerisque fermentum. Proin interdum purus nec pharetra semper.</p>\n</div>\n</div>', NULL, NULL, 1, 1, 4, 0, 0, NULL, 'Inherit', 'Inherit', 0, 14, 8, 'None', 0),
(3, 'ContactPage', '2015-01-26 04:46:26', '2015-03-16 02:23:26', 'contact-us', 'Contact Us', NULL, '<h3 class="title-block second-child">Drop Us A Few Lines</h3>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin congue tellus ut velit mollis condimentum. Nulla egestas neque sed odio varius facilisis. Donec ac metus gravida leo dictum porttitor.</p>\n<hr>', NULL, NULL, 1, 1, 2, 0, 0, NULL, 'Inherit', 'Inherit', 0, 12, 8, 'None', 0),
(4, 'Blog', '2015-01-26 04:46:26', '2015-03-18 21:45:32', 'blog', 'Blog', NULL, NULL, NULL, NULL, 1, 1, 4, 0, 0, NULL, 'Inherit', 'Inherit', 0, 6, 0, 'None', 0),
(5, 'BlogPost', '2015-01-26 04:46:26', '2015-03-14 13:34:12', 'sample-blog-entry', 'SilverStripe blog module successfully installed', NULL, '<p>Congratulations, the SilverStripe blog module has been successfully installed. This blog entry can be safely deleted. You can configure aspects of your blog in <a href="admin">the CMS</a>.</p>', NULL, NULL, 0, 1, 1, 0, 0, NULL, 'Inherit', 'Inherit', 1, 5, 4, 'None', 0),
(6, 'ErrorPage', '2015-01-26 04:46:26', '2015-01-26 04:50:23', 'page-not-found', 'Page not found', NULL, '<p>Sorry, it seems you were trying to access a page that doesn''t exist.</p><p>Please check the spelling of the URL you were trying to access and try again.</p>', NULL, NULL, 0, 0, 5, 0, 0, NULL, 'Inherit', 'Inherit', 0, 1, 0, 'None', 0),
(7, 'ErrorPage', '2015-01-26 04:46:27', '2015-01-26 04:46:27', 'server-error', 'Server error', NULL, '<p>Sorry, there was a problem with handling your request.</p>', NULL, NULL, 0, 0, 6, 0, 0, NULL, 'Inherit', 'Inherit', 0, 1, 0, 'None', 0),
(8, 'Page', '2015-01-27 09:42:21', '2015-01-27 09:43:28', 'pages', 'Pages', NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus. Donec iaculis, est ut adipiscing cursus, lectus turpis tristique massa, faucibus faucibus urna odio nec ante. Integer magna purus, tincidunt ut vestibulum eget, mattis sit amet purus. Donec interdum orci nec felis pulvinar hendrerit. Donec suscipit turpis et libero fermentum non venenatis massa eleifend. Maecenas fringilla consectetur risus vel venenatis. Sed tincidunt tellus sit amet tellus mattis a malesuada dui vulputate. Aenean ut orci metus, vitae bibendum diam. Aliquam sit amet leo sed est convallis blandit vel sed libero. Integer leo nisi, viverra sit amet congue in, suscipit ac orci. Ut ut nulla at nulla posuere rutrum. Etiam cursus ultricies placerat. Praesent eu tellus nec enim pulvinar porta. Maecenas faucibus interdum turpis, sed rhoncus ante luctus vel. Duis ut orci nec metus lobortis commodo. Donec aliquet, leo non vestibulum dictum, ante justo molestie leo, id eleifend diam odio nec tellus. Cras consequat nunc a quam interdum luctus mollis velit viverra.</p>\n<p>Nulla at leo eros, nec porttitor erat. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed venenatis facilisis dolor id pulvinar. Suspendisse tincidunt, arcu vestibulum venenatis blandit, arcu quam scelerisque nibh, nec imperdiet tellus tellus nec mauris. Suspendisse cursus varius velit, vel ultricies tortor fringilla pretium. Pellentesque posuere lobortis vehicula. Proin scelerisque dapibus eros, eget iaculis metus ultrices vel. Morbi malesuada ligula sit amet mauris mollis sed vulputate tellus fringilla. Maecenas at velit sem. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum in arcu quis odio ullamcorper vulputate. Etiam tempor placerat lorem, id rhoncus erat vulputate sed. Pellentesque dapibus sollicitudin ipsum. Aliquam sollicitudin augue sit amet sapien tristique vel tristique nisl auctor. Aliquam porta, dui quis molestie vehicula, sem est luctus felis, id suscipit massa ipsum sed elit. Quisque vehicula nulla nec felis egestas id pellentesque risus condimentum. Nam varius purus quis erat egestas feugiat. Duis a odio eros, a vehicula sapien. Pellentesque ac dolor in velit aliquam gravida.</p>\n<p>Donec ut bibendum risus. Sed nisl turpis, pulvinar ut bibendum non, dignissim quis nibh. Cras interdum dictum dui, at venenatis magna auctor a. In a turpis risus, quis mollis augue. Mauris cursus, metus eu accumsan cursus, arcu sapien posuere elit, in viverra nisi diam non arcu. Maecenas ultricies commodo diam, sit amet mattis sapien accumsan ut. Vivamus a felis in enim porta congue. Cras dui tortor, adipiscing imperdiet tempus eu, adipiscing id tellus. Quisque id varius metus. Suspendisse ac euismod neque. Nullam orci dui, tincidunt nec mollis quis, aliquet nec risus. Pellentesque et neque felis, a ullamcorper lacus. Quisque mollis, odio sed fringilla rutrum, elit ipsum adipiscing turpis, sit amet mollis purus neque sed nibh. Donec vitae arcu lorem. Suspendisse id elit felis, non condimentum mauris. Nullam ullamcorper volutpat urna vel feugiat.</p>', NULL, NULL, 1, 1, 2, 0, 0, NULL, 'Inherit', 'Inherit', 0, 3, 0, 'None', 0),
(9, 'PortfolioPage', '2015-01-27 09:45:10', '2015-03-18 19:00:04', 'portfolio', 'Portfolio', NULL, '<p class="lead" style="text-align: center;"><span style="color: #ec7263;">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris nec velit consequat, pharetra risus et, tempus mi. </span></p>', NULL, NULL, 1, 1, 3, 0, 0, NULL, 'Inherit', 'Inherit', 0, 8, 0, 'None', 0),
(10, 'PortfolioItem', '2015-01-28 20:07:31', '2015-01-29 04:54:01', 'portfolio-item-1', 'Portfolio Item #1', NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus. Donec iaculis, est ut adipiscing cursus, lectus turpis tristique massa, faucibus faucibus urna odio nec ante. Integer magna purus, tincidunt ut vestibulum eget, mattis sit amet purus. Donec interdum orci nec felis pulvinar hendrerit. Donec suscipit turpis et libero fermentum non venenatis massa eleifend. Maecenas fringilla consectetur risus vel venenatis. Sed tincidunt tellus sit amet tellus mattis a malesuada dui vulputate. Aenean ut orci metus, vitae bibendum diam. Aliquam sit amet leo sed est convallis blandit vel sed libero. Integer leo nisi, viverra sit amet congue in, suscipit ac orci. Ut ut nulla at nulla posuere rutrum. Etiam cursus ultricies placerat. Praesent eu tellus nec enim pulvinar porta. Maecenas faucibus interdum turpis, sed rhoncus ante luctus vel. Duis ut orci nec metus lobortis commodo. Donec aliquet, leo non vestibulum dictum, ante justo molestie leo, id eleifend diam odio nec tellus. Cras consequat nunc a quam interdum luctus mollis velit viverra.</p>', NULL, NULL, 1, 1, 2, 0, 0, NULL, 'Inherit', 'Inherit', 0, 8, 9, 'None', 0),
(11, 'PortfolioItem', '2015-01-28 20:07:31', '2015-03-19 09:58:51', 'portfolio-item-2', 'Portfolio Item #2', NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus. Donec iaculis, est ut adipiscing cursus, lectus turpis tristique massa, faucibus faucibus urna odio nec ante. Integer magna purus, tincidunt ut vestibulum eget, mattis sit amet purus. Donec interdum orci nec felis pulvinar hendrerit. Donec suscipit turpis et libero fermentum non venenatis massa eleifend. Maecenas fringilla consectetur risus vel venenatis. Sed tincidunt tellus sit amet tellus mattis a malesuada dui vulputate. Aenean ut orci metus, vitae bibendum diam. Aliquam sit amet leo sed est convallis blandit vel sed libero. Integer leo nisi, viverra sit amet congue in, suscipit ac orci. Ut ut nulla at nulla posuere rutrum. Etiam cursus ultricies placerat. Praesent eu tellus nec enim pulvinar porta. Maecenas faucibus interdum turpis, sed rhoncus ante luctus vel. Duis ut orci nec metus lobortis commodo. Donec aliquet, leo non vestibulum dictum, ante justo molestie leo, id eleifend diam odio nec tellus. Cras consequat nunc a quam interdum luctus mollis velit viverra.</p>', NULL, NULL, 1, 1, 1, 0, 0, NULL, 'Inherit', 'Inherit', 0, 5, 9, 'None', 0),
(12, 'PortfolioItem', '2015-01-28 20:07:31', '2015-03-18 19:26:00', 'portfolio-item-3', 'Portfolio Item #3', NULL, '<p>Integer sodales, lectus et elementum volutpat, ipsum purus tristique dolor, non scelerisque diam sem id neque. Etiam sit amet eros magna. Mauris purus nunc, venenatis vitae erat ac, sagittis consectetur dolor.</p>', NULL, NULL, 1, 1, 3, 0, 0, NULL, 'Inherit', 'Inherit', 0, 4, 9, 'None', 0),
(29, 'BlogPost', '2015-03-18 20:25:32', '2015-03-20 11:05:55', 'lorem-ipsum-dolor-sit-amet-consectetur-adipiscing-elit', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit', NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus. Donec iaculis, est ut adipiscing cursus, lectus turpis tristique massa, faucibus faucibus urna odio nec ante. Integer magna purus, tincidunt ut vestibulum eget, mattis sit amet purus. Donec interdum orci nec felis pulvinar hendrerit. Donec suscipit turpis et libero fermentum non venenatis massa eleifend. Maecenas fringilla consectetur risus vel venenatis. Sed tincidunt tellus sit amet tellus mattis a malesuada dui vulputate. Aenean ut orci metus, vitae bibendum diam. Aliquam sit amet leo sed est convallis blandit vel sed libero. Integer leo nisi, viverra sit amet congue in, suscipit ac orci. Ut ut nulla at nulla posuere rutrum. Etiam cursus ultricies placerat. Praesent eu tellus nec enim pulvinar porta. Maecenas faucibus interdum turpis, sed rhoncus ante luctus vel. Duis ut orci nec metus lobortis commodo. Donec aliquet, leo non vestibulum dictum, ante justo molestie leo, id eleifend diam odio nec tellus. Cras consequat nunc a quam interdum luctus mollis velit viverra.</p>\n<p>Nulla at leo eros, nec porttitor erat. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed venenatis facilisis dolor id pulvinar. Suspendisse tincidunt, arcu vestibulum venenatis blandit, arcu quam scelerisque nibh, nec imperdiet tellus tellus nec mauris. Suspendisse cursus varius velit, vel ultricies tortor fringilla pretium. Pellentesque posuere lobortis vehicula. Proin scelerisque dapibus eros, eget iaculis metus ultrices vel. Morbi malesuada ligula sit amet mauris mollis sed vulputate tellus fringilla. Maecenas at velit sem. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum in arcu quis odio ullamcorper vulputate. Etiam tempor placerat lorem, id rhoncus erat vulputate sed. Pellentesque dapibus sollicitudin ipsum. Aliquam sollicitudin augue sit amet sapien tristique vel tristique nisl auctor. Aliquam porta, dui quis molestie vehicula, sem est luctus felis, id suscipit massa ipsum sed elit. Quisque vehicula nulla nec felis egestas id pellentesque risus condimentum. Nam varius purus quis erat egestas feugiat. Duis a odio eros, a vehicula sapien. Pellentesque ac dolor in velit aliquam gravida.</p>\n<p>Donec ut bibendum risus. Sed nisl turpis, pulvinar ut bibendum non, dignissim quis nibh. Cras interdum dictum dui, at venenatis magna auctor a. In a turpis risus, quis mollis augue. Mauris cursus, metus eu accumsan cursus, arcu sapien posuere elit, in viverra nisi diam non arcu. Maecenas ultricies commodo diam, sit amet mattis sapien accumsan ut. Vivamus a felis in enim porta congue. Cras dui tortor, adipiscing imperdiet tempus eu, adipiscing id tellus. Quisque id varius metus. Suspendisse ac euismod neque. Nullam orci dui, tincidunt nec mollis quis, aliquet nec risus. Pellentesque et neque felis, a ullamcorper lacus. Quisque mollis, odio sed fringilla rutrum, elit ipsum adipiscing turpis, sit amet mollis purus neque sed nibh. Donec vitae arcu lorem. Suspendisse id elit felis, non condimentum mauris. Nullam ullamcorper volutpat urna vel feugiat.</p>', NULL, NULL, 0, 1, 2, 0, 0, NULL, 'Inherit', 'Inherit', 1, 4, 4, 'None', 0),
(13, 'PortfolioItem', '2015-01-28 20:07:31', '2015-01-29 04:53:24', 'portfolio-item-4', 'Portfolio Item #4', NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus. Donec iaculis, est ut adipiscing cursus, lectus turpis tristique massa, faucibus faucibus urna odio nec ante. Integer magna purus, tincidunt ut vestibulum eget, mattis sit amet purus. Donec interdum orci nec felis pulvinar hendrerit. Donec suscipit turpis et libero fermentum non venenatis massa eleifend. Maecenas fringilla consectetur risus vel venenatis. Sed tincidunt tellus sit amet tellus mattis a malesuada dui vulputate. Aenean ut orci metus, vitae bibendum diam. Aliquam sit amet leo sed est convallis blandit vel sed libero. Integer leo nisi, viverra sit amet congue in, suscipit ac orci. Ut ut nulla at nulla posuere rutrum. Etiam cursus ultricies placerat. Praesent eu tellus nec enim pulvinar porta. Maecenas faucibus interdum turpis, sed rhoncus ante luctus vel. Duis ut orci nec metus lobortis commodo. Donec aliquet, leo non vestibulum dictum, ante justo molestie leo, id eleifend diam odio nec tellus. Cras consequat nunc a quam interdum luctus mollis velit viverra.</p>', NULL, NULL, 1, 1, 4, 0, 0, NULL, 'Inherit', 'Inherit', 0, 1, 9, 'None', 0),
(14, 'PortfolioItem', '2015-01-28 20:07:31', '2015-01-29 04:56:54', 'portfolio-item-5', 'Portfolio Item #5', NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus. Donec iaculis, est ut adipiscing cursus, lectus turpis tristique massa, faucibus faucibus urna odio nec ante. Integer magna purus, tincidunt ut vestibulum eget, mattis sit amet purus. Donec interdum orci nec felis pulvinar hendrerit. Donec suscipit turpis et libero fermentum non venenatis massa eleifend. Maecenas fringilla consectetur risus vel venenatis. Sed tincidunt tellus sit amet tellus mattis a malesuada dui vulputate. Aenean ut orci metus, vitae bibendum diam. Aliquam sit amet leo sed est convallis blandit vel sed libero. Integer leo nisi, viverra sit amet congue in, suscipit ac orci. Ut ut nulla at nulla posuere rutrum. Etiam cursus ultricies placerat. Praesent eu tellus nec enim pulvinar porta. Maecenas faucibus interdum turpis, sed rhoncus ante luctus vel. Duis ut orci nec metus lobortis commodo. Donec aliquet, leo non vestibulum dictum, ante justo molestie leo, id eleifend diam odio nec tellus. Cras consequat nunc a quam interdum luctus mollis velit viverra.</p>', NULL, NULL, 1, 1, 5, 0, 0, NULL, 'Inherit', 'Inherit', 0, 1, 9, 'None', 0),
(15, 'PortfolioItem', '2015-01-28 20:07:31', '2015-01-29 04:58:06', 'portfolio-item-6', 'Portfolio Item #6', NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus. Donec iaculis, est ut adipiscing cursus, lectus turpis tristique massa, faucibus faucibus urna odio nec ante. Integer magna purus, tincidunt ut vestibulum eget, mattis sit amet purus. Donec interdum orci nec felis pulvinar hendrerit. Donec suscipit turpis et libero fermentum non venenatis massa eleifend. Maecenas fringilla consectetur risus vel venenatis. Sed tincidunt tellus sit amet tellus mattis a malesuada dui vulputate. Aenean ut orci metus, vitae bibendum diam. Aliquam sit amet leo sed est convallis blandit vel sed libero. Integer leo nisi, viverra sit amet congue in, suscipit ac orci. Ut ut nulla at nulla posuere rutrum. Etiam cursus ultricies placerat. Praesent eu tellus nec enim pulvinar porta. Maecenas faucibus interdum turpis, sed rhoncus ante luctus vel. Duis ut orci nec metus lobortis commodo. Donec aliquet, leo non vestibulum dictum, ante justo molestie leo, id eleifend diam odio nec tellus. Cras consequat nunc a quam interdum luctus mollis velit viverra.</p>', NULL, NULL, 1, 1, 6, 0, 0, NULL, 'Inherit', 'Inherit', 0, 1, 9, 'None', 0),
(16, 'TimelinePage', '2015-02-08 18:05:28', '2015-03-17 19:33:52', 'timeline', 'Timeline', NULL, '<h2 class="title-block text-center">Timeline is a great way to showcase your company history, share news or events</h2>\n<p class="text-center">Donec tincidunt nec mi eu venenatis. Nulla facilisi. Maecenas venenatis condimentum porttitor. Aliquam erat volutpat. In ac mollis odio. Praesent ac mi nisi. Nulla congue mi at porttitor ultrices. Nulla pellentesque placerat elit, sit amet egestas mi consectetur eleifend. Integer molestie ultricies libero ut consectetur. Maecenas consectetur quis elit quis consequat. Sed tincidunt nulla in lorem ullamcorper, ut aliquam odio malesuada.</p>', NULL, NULL, 1, 1, 5, 0, 0, NULL, 'Inherit', 'Inherit', 0, 4, 8, 'None', 0),
(17, 'TimelineItem', '2015-02-08 18:05:54', '2015-02-10 18:45:26', 'event-001', 'Event 001', NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus. Donec iaculis, est ut adipiscing cursus, lectus turpis tristique massa, faucibus faucibus urna odio nec ante. Integer magna purus, tincidunt ut vestibulum eget, mattis sit amet purus. Donec interdum orci nec felis pulvinar hendrerit. Donec suscipit turpis et libero fermentum non venenatis massa eleifend. Maecenas fringilla consectetur risus vel venenatis. Sed tincidunt tellus sit amet tellus mattis a malesuada dui vulputate. Aenean ut orci metus, vitae bibendum diam. Aliquam sit amet leo sed est convallis blandit vel sed libero. Integer leo nisi, viverra sit amet congue in, suscipit ac orci. Ut ut nulla at nulla posuere rutrum. Etiam cursus ultricies placerat. Praesent eu tellus nec enim pulvinar porta. Maecenas faucibus interdum turpis, sed rhoncus ante luctus vel. Duis ut orci nec metus lobortis commodo. Donec aliquet, leo non vestibulum dictum, ante justo molestie leo, id eleifend diam odio nec tellus. Cras consequat nunc a quam interdum luctus mollis velit viverra.</p>\n<p>Nulla at leo eros, nec porttitor erat. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed venenatis facilisis dolor id pulvinar. Suspendisse tincidunt, arcu vestibulum venenatis blandit, arcu quam scelerisque nibh, nec imperdiet tellus tellus nec mauris. Suspendisse cursus varius velit, vel ultricies tortor fringilla pretium. Pellentesque posuere lobortis vehicula. Proin scelerisque dapibus eros, eget iaculis metus ultrices vel. Morbi malesuada ligula sit amet mauris mollis sed vulputate tellus fringilla. Maecenas at velit sem. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum in arcu quis odio ullamcorper vulputate. Etiam tempor placerat lorem, id rhoncus erat vulputate sed. Pellentesque dapibus sollicitudin ipsum. Aliquam sollicitudin augue sit amet sapien tristique vel tristique nisl auctor. Aliquam porta, dui quis molestie vehicula, sem est luctus felis, id suscipit massa ipsum sed elit. Quisque vehicula nulla nec felis egestas id pellentesque risus condimentum. Nam varius purus quis erat egestas feugiat. Duis a odio eros, a vehicula sapien. Pellentesque ac dolor in velit aliquam gravida.</p>\n<p>Donec ut bibendum risus. Sed nisl turpis, pulvinar ut bibendum non, dignissim quis nibh. Cras interdum dictum dui, at venenatis magna auctor a. In a turpis risus, quis mollis augue. Mauris cursus, metus eu accumsan cursus, arcu sapien posuere elit, in viverra nisi diam non arcu. Maecenas ultricies commodo diam, sit amet mattis sapien accumsan ut. Vivamus a felis in enim porta congue. Cras dui tortor, adipiscing imperdiet tempus eu, adipiscing id tellus. Quisque id varius metus. Suspendisse ac euismod neque. Nullam orci dui, tincidunt nec mollis quis, aliquet nec risus. Pellentesque et neque felis, a ullamcorper lacus. Quisque mollis, odio sed fringilla rutrum, elit ipsum adipiscing turpis, sit amet mollis purus neque sed nibh. Donec vitae arcu lorem. Suspendisse id elit felis, non condimentum mauris. Nullam ullamcorper volutpat urna vel feugiat.</p>', NULL, NULL, 1, 1, 1, 0, 0, NULL, 'Inherit', 'Inherit', 0, 10, 16, 'None', 0),
(18, 'TimelineItem', '2015-02-08 18:05:54', '2015-02-10 18:37:41', 'event-2', 'Event 002', NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus. Donec iaculis, est ut adipiscing cursus, lectus turpis tristique massa, faucibus faucibus urna odio nec ante. Integer magna purus, tincidunt ut vestibulum eget, mattis sit amet purus. Donec interdum orci nec felis pulvinar hendrerit. Donec suscipit turpis et libero fermentum non venenatis massa eleifend. Maecenas fringilla consectetur risus vel venenatis. Sed tincidunt tellus sit amet tellus mattis a malesuada dui vulputate. Aenean ut orci metus, vitae bibendum diam. Aliquam sit amet leo sed est convallis blandit vel sed libero. Integer leo nisi, viverra sit amet congue in, suscipit ac orci. Ut ut nulla at nulla posuere rutrum. Etiam cursus ultricies placerat. Praesent eu tellus nec enim pulvinar porta. Maecenas faucibus interdum turpis, sed rhoncus ante luctus vel. Duis ut orci nec metus lobortis commodo. Donec aliquet, leo non vestibulum dictum, ante justo molestie leo, id eleifend diam odio nec tellus. Cras consequat nunc a quam interdum luctus mollis velit viverra.</p>\n<p>Nulla at leo eros, nec porttitor erat. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed venenatis facilisis dolor id pulvinar. Suspendisse tincidunt, arcu vestibulum venenatis blandit, arcu quam scelerisque nibh, nec imperdiet tellus tellus nec mauris. Suspendisse cursus varius velit, vel ultricies tortor fringilla pretium. Pellentesque posuere lobortis vehicula. Proin scelerisque dapibus eros, eget iaculis metus ultrices vel. Morbi malesuada ligula sit amet mauris mollis sed vulputate tellus fringilla. Maecenas at velit sem. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum in arcu quis odio ullamcorper vulputate. Etiam tempor placerat lorem, id rhoncus erat vulputate sed. Pellentesque dapibus sollicitudin ipsum. Aliquam sollicitudin augue sit amet sapien tristique vel tristique nisl auctor. Aliquam porta, dui quis molestie vehicula, sem est luctus felis, id suscipit massa ipsum sed elit. Quisque vehicula nulla nec felis egestas id pellentesque risus condimentum. Nam varius purus quis erat egestas feugiat. Duis a odio eros, a vehicula sapien. Pellentesque ac dolor in velit aliquam gravida.</p>\n<p>Donec ut bibendum risus. Sed nisl turpis, pulvinar ut bibendum non, dignissim quis nibh. Cras interdum dictum dui, at venenatis magna auctor a. In a turpis risus, quis mollis augue. Mauris cursus, metus eu accumsan cursus, arcu sapien posuere elit, in viverra nisi diam non arcu. Maecenas ultricies commodo diam, sit amet mattis sapien accumsan ut. Vivamus a felis in enim porta congue. Cras dui tortor, adipiscing imperdiet tempus eu, adipiscing id tellus. Quisque id varius metus. Suspendisse ac euismod neque. Nullam orci dui, tincidunt nec mollis quis, aliquet nec risus. Pellentesque et neque felis, a ullamcorper lacus. Quisque mollis, odio sed fringilla rutrum, elit ipsum adipiscing turpis, sit amet mollis purus neque sed nibh. Donec vitae arcu lorem. Suspendisse id elit felis, non condimentum mauris. Nullam ullamcorper volutpat urna vel feugiat.</p>', NULL, NULL, 1, 1, 2, 0, 0, NULL, 'Inherit', 'Inherit', 0, 3, 16, 'None', 0),
(19, 'TimelineItem', '2015-02-08 18:05:54', '2015-03-17 19:30:33', 'event-3', 'Event 003', NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus. Donec iaculis, est ut adipiscing cursus, lectus turpis tristique massa, faucibus faucibus urna odio nec ante. Integer magna purus, tincidunt ut vestibulum eget, mattis sit amet purus. Donec interdum orci nec felis pulvinar hendrerit. Donec suscipit turpis et libero fermentum non venenatis massa eleifend. Maecenas fringilla consectetur risus vel venenatis. Sed tincidunt tellus sit amet tellus mattis a malesuada dui vulputate. Aenean ut orci metus, vitae bibendum diam. Aliquam sit amet leo sed est convallis blandit vel sed libero. Integer leo nisi, viverra sit amet congue in, suscipit ac orci. Ut ut nulla at nulla posuere rutrum. Etiam cursus ultricies placerat. Praesent eu tellus nec enim pulvinar porta. Maecenas faucibus interdum turpis, sed rhoncus ante luctus vel. Duis ut orci nec metus lobortis commodo. Donec aliquet, leo non vestibulum dictum, ante justo molestie leo, id eleifend diam odio nec tellus. Cras consequat nunc a quam interdum luctus mollis velit viverra.</p>\n<p>Nulla at leo eros, nec porttitor erat. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed venenatis facilisis dolor id pulvinar. Suspendisse tincidunt, arcu vestibulum venenatis blandit, arcu quam scelerisque nibh, nec imperdiet tellus tellus nec mauris. Suspendisse cursus varius velit, vel ultricies tortor fringilla pretium. Pellentesque posuere lobortis vehicula. Proin scelerisque dapibus eros, eget iaculis metus ultrices vel. Morbi malesuada ligula sit amet mauris mollis sed vulputate tellus fringilla. Maecenas at velit sem. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum in arcu quis odio ullamcorper vulputate. Etiam tempor placerat lorem, id rhoncus erat vulputate sed. Pellentesque dapibus sollicitudin ipsum. Aliquam sollicitudin augue sit amet sapien tristique vel tristique nisl auctor. Aliquam porta, dui quis molestie vehicula, sem est luctus felis, id suscipit massa ipsum sed elit. Quisque vehicula nulla nec felis egestas id pellentesque risus condimentum. Nam varius purus quis erat egestas feugiat. Duis a odio eros, a vehicula sapien. Pellentesque ac dolor in velit aliquam gravida.</p>\n<p>Donec ut bibendum risus. Sed nisl turpis, pulvinar ut bibendum non, dignissim quis nibh. Cras interdum dictum dui, at venenatis magna auctor a. In a turpis risus, quis mollis augue. Mauris cursus, metus eu accumsan cursus, arcu sapien posuere elit, in viverra nisi diam non arcu. Maecenas ultricies commodo diam, sit amet mattis sapien accumsan ut. Vivamus a felis in enim porta congue. Cras dui tortor, adipiscing imperdiet tempus eu, adipiscing id tellus. Quisque id varius metus. Suspendisse ac euismod neque. Nullam orci dui, tincidunt nec mollis quis, aliquet nec risus. Pellentesque et neque felis, a ullamcorper lacus. Quisque mollis, odio sed fringilla rutrum, elit ipsum adipiscing turpis, sit amet mollis purus neque sed nibh. Donec vitae arcu lorem. Suspendisse id elit felis, non condimentum mauris. Nullam ullamcorper volutpat urna vel feugiat.</p>', NULL, NULL, 1, 1, 3, 0, 0, NULL, 'Inherit', 'Inherit', 0, 3, 16, 'None', 0),
(21, 'HelpPage', '2015-03-16 19:24:00', '2015-03-17 18:27:38', 'help-center', 'Help Center', NULL, NULL, NULL, NULL, 1, 1, 3, 0, 0, NULL, 'Inherit', 'Inherit', 0, 3, 8, 'None', 0),
(22, 'HelpArticle', '2015-03-16 19:25:02', '2015-03-17 17:04:45', 'lorem-ipsum-dolor-sit-amet-consectetur-adipiscing-elit-ut-ac-tortor-vitae-lorem-lobortis', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut ac tortor vitae lorem lobortis', NULL, '<p>Donec massa urna, tristique sed lectus quis, suscipit ultricies velit. Curabitur pulvinar rutrum risus eu aliquet. Vestibulum at felis et ipsum lacinia fringilla. Praesent blandit ultricies velit non euismod. Integer fringilla, ipsum eu adipiscing venenatis, nisl nisl fermentum sem, nec suscipit felis arcu in augue. Nunc ac blandit lorem. Maecenas auctor justo odio, at eleifend nulla venenatis quis. Aenean semper, libero ac dictum bibendum, enim augue lacinia neque, quis aliquam lacus nulla sed nisi. Etiam eleifend scelerisque odio sit amet fermentum. Etiam at nunc est. Nam eu lobortis nulla. Pellentesque consectetur augue neque, ut porttitor massa tincidunt egestas. Fusce diam tellus, convallis rutrum faucibus porta, venenatis non velit. Nulla non convallis urna, lacinia mollis massa. Nam consequat tristique felis a egestas.</p>\n<p>Donec massa urna, tristique sed lectus quis, suscipit ultricies velit. Curabitur pulvinar rutrum risus eu aliquet. Vestibulum at felis et ipsum lacinia fringilla. Praesent blandit ultricies velit non euismod. Integer fringilla, ipsum eu adipiscing venenatis, nisl nisl fermentum sem, nec suscipit felis arcu in augue. Nunc ac blandit lorem. Maecenas auctor justo odio, at eleifend nulla venenatis quis. Aenean semper, libero ac dictum bibendum, enim augue lacinia neque, quis aliquam lacus nulla sed nisi. Etiam eleifend scelerisque odio sit amet fermentum. Etiam at nunc est. Nam eu lobortis nulla. Pellentesque consectetur augue neque, ut porttitor massa tincidunt egestas. Fusce diam tellus, convallis rutrum faucibus porta, venenatis non velit. Nulla non convallis urna, lacinia mollis massa. Nam consequat tristique felis a egestas.</p>\n<p>Donec massa urna, tristique sed lectus quis, suscipit ultricies velit. Curabitur pulvinar rutrum risus eu aliquet. Vestibulum at felis et ipsum lacinia fringilla. Praesent blandit ultricies velit non euismod. Integer fringilla, ipsum eu adipiscing venenatis, nisl nisl fermentum sem, nec suscipit felis arcu in augue. Nunc ac blandit lorem. Maecenas auctor justo odio, at eleifend nulla venenatis quis. Aenean semper, libero ac dictum bibendum, enim augue lacinia neque, quis aliquam lacus nulla sed nisi. Etiam eleifend scelerisque odio sit amet fermentum. Etiam at nunc est. Nam eu lobortis nulla. Pellentesque consectetur augue neque, ut porttitor massa tincidunt egestas. Fusce diam tellus, convallis rutrum faucibus porta, venenatis non velit. Nulla non convallis urna, lacinia mollis massa. Nam consequat tristique felis a egestas.</p>\n<p>ThemeStripe.</p>', NULL, NULL, 1, 1, 1, 0, 0, NULL, 'Inherit', 'Inherit', 1, 5, 21, 'None', 0),
(23, 'HelpArticle', '2015-03-16 19:26:59', '2015-03-16 19:27:42', 'ut-ac-tortor-vitae-lorem-lobortis-vulputate-eget-ac-nisi', 'Ut ac tortor vitae lorem lobortis vulputate eget ac nisi', NULL, '<p>Donec massa urna, tristique sed lectus quis, suscipit ultricies velit. Curabitur pulvinar rutrum risus eu aliquet. Vestibulum at felis et ipsum lacinia fringilla. Praesent blandit ultricies velit non euismod. Integer fringilla, ipsum eu adipiscing venenatis, nisl nisl fermentum sem, nec suscipit felis arcu in augue. Nunc ac blandit lorem. Maecenas auctor justo odio, at eleifend nulla venenatis quis. Aenean semper, libero ac dictum bibendum, enim augue lacinia neque, quis aliquam lacus nulla sed nisi. Etiam eleifend scelerisque odio sit amet fermentum. Etiam at nunc est. Nam eu lobortis nulla. Pellentesque consectetur augue neque, ut porttitor massa tincidunt egestas. Fusce diam tellus, convallis rutrum faucibus porta, venenatis non velit. Nulla non convallis urna, lacinia mollis massa. Nam consequat tristique felis a egestas.</p>', NULL, NULL, 1, 1, 2, 0, 0, NULL, 'Inherit', 'Inherit', 0, 2, 21, 'None', 0),
(24, 'HelpArticle', '2015-03-16 19:28:08', '2015-03-16 19:31:51', 'donec-massa-urna-tristique-sed-lectus-quis-suscipit-ultricies-velit', 'Donec massa urna, tristique sed lectus quis, suscipit ultricies velit', NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus. Donec iaculis, est ut adipiscing cursus, lectus turpis tristique massa, faucibus faucibus urna odio nec ante. Integer magna purus, tincidunt ut vestibulum eget, mattis sit amet purus. Donec interdum orci nec felis pulvinar hendrerit. Donec suscipit turpis et libero fermentum non venenatis massa eleifend. Maecenas fringilla consectetur risus vel venenatis. Sed tincidunt tellus sit amet tellus mattis a malesuada dui vulputate. Aenean ut orci metus, vitae bibendum diam. Aliquam sit amet leo sed est convallis blandit vel sed libero. Integer leo nisi, viverra sit amet congue in, suscipit ac orci. Ut ut nulla at nulla posuere rutrum. Etiam cursus ultricies placerat. Praesent eu tellus nec enim pulvinar porta. Maecenas faucibus interdum turpis, sed rhoncus ante luctus vel. Duis ut orci nec metus lobortis commodo. Donec aliquet, leo non vestibulum dictum, ante justo molestie leo, id eleifend diam odio nec tellus. Cras consequat nunc a quam interdum luctus mollis velit viverra.</p>\n<p>Nulla at leo eros, nec porttitor erat. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed venenatis facilisis dolor id pulvinar. Suspendisse tincidunt, arcu vestibulum venenatis blandit, arcu quam scelerisque nibh, nec imperdiet tellus tellus nec mauris. Suspendisse cursus varius velit, vel ultricies tortor fringilla pretium. Pellentesque posuere lobortis vehicula. Proin scelerisque dapibus eros, eget iaculis metus ultrices vel. Morbi malesuada ligula sit amet mauris mollis sed vulputate tellus fringilla. Maecenas at velit sem. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum in arcu quis odio ullamcorper vulputate. Etiam tempor placerat lorem, id rhoncus erat vulputate sed. Pellentesque dapibus sollicitudin ipsum. Aliquam sollicitudin augue sit amet sapien tristique vel tristique nisl auctor. Aliquam porta, dui quis molestie vehicula, sem est luctus felis, id suscipit massa ipsum sed elit. Quisque vehicula nulla nec felis egestas id pellentesque risus condimentum. Nam varius purus quis erat egestas feugiat. Duis a odio eros, a vehicula sapien. Pellentesque ac dolor in velit aliquam gravida.</p>\n<p>Donec ut bibendum risus. Sed nisl turpis, pulvinar ut bibendum non, dignissim quis nibh. Cras interdum dictum dui, at venenatis magna auctor a. In a turpis risus, quis mollis augue. Mauris cursus, metus eu accumsan cursus, arcu sapien posuere elit, in viverra nisi diam non arcu. Maecenas ultricies commodo diam, sit amet mattis sapien accumsan ut. Vivamus a felis in enim porta congue. Cras dui tortor, adipiscing imperdiet tempus eu, adipiscing id tellus. Quisque id varius metus. Suspendisse ac euismod neque. Nullam orci dui, tincidunt nec mollis quis, aliquet nec risus. Pellentesque et neque felis, a ullamcorper lacus. Quisque mollis, odio sed fringilla rutrum, elit ipsum adipiscing turpis, sit amet mollis purus neque sed nibh. Donec vitae arcu lorem. Suspendisse id elit felis, non condimentum mauris. Nullam ullamcorper volutpat urna vel feugiat.</p>', NULL, NULL, 1, 1, 3, 0, 0, NULL, 'Inherit', 'Inherit', 0, 2, 21, 'None', 0),
(25, 'HelpArticle', '2015-03-16 19:32:05', '2015-03-16 19:33:35', 'find-your-computers-ip-address', 'Find your computer''s IP address', NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus. Donec iaculis, est ut adipiscing cursus, lectus turpis tristique massa, faucibus faucibus urna odio nec ante. Integer magna purus, tincidunt ut vestibulum eget, mattis sit amet purus. Donec interdum orci nec felis pulvinar hendrerit. Donec suscipit turpis et libero fermentum non venenatis massa eleifend. Maecenas fringilla consectetur risus vel venenatis. Sed tincidunt tellus sit amet tellus mattis a malesuada dui vulputate. Aenean ut orci metus, vitae bibendum diam. Aliquam sit amet leo sed est convallis blandit vel sed libero. Integer leo nisi, viverra sit amet congue in, suscipit ac orci. Ut ut nulla at nulla posuere rutrum. Etiam cursus ultricies placerat. Praesent eu tellus nec enim pulvinar porta. Maecenas faucibus interdum turpis, sed rhoncus ante luctus vel. Duis ut orci nec metus lobortis commodo. Donec aliquet, leo non vestibulum dictum, ante justo molestie leo, id eleifend diam odio nec tellus. Cras consequat nunc a quam interdum luctus mollis velit viverra.</p>\n<p>Nulla at leo eros, nec porttitor erat. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed venenatis facilisis dolor id pulvinar. Suspendisse tincidunt, arcu vestibulum venenatis blandit, arcu quam scelerisque nibh, nec imperdiet tellus tellus nec mauris. Suspendisse cursus varius velit, vel ultricies tortor fringilla pretium. Pellentesque posuere lobortis vehicula. Proin scelerisque dapibus eros, eget iaculis metus ultrices vel. Morbi malesuada ligula sit amet mauris mollis sed vulputate tellus fringilla. Maecenas at velit sem. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum in arcu quis odio ullamcorper vulputate. Etiam tempor placerat lorem, id rhoncus erat vulputate sed. Pellentesque dapibus sollicitudin ipsum. Aliquam sollicitudin augue sit amet sapien tristique vel tristique nisl auctor. Aliquam porta, dui quis molestie vehicula, sem est luctus felis, id suscipit massa ipsum sed elit. Quisque vehicula nulla nec felis egestas id pellentesque risus condimentum. Nam varius purus quis erat egestas feugiat. Duis a odio eros, a vehicula sapien. Pellentesque ac dolor in velit aliquam gravida.</p>\n<p>Donec ut bibendum risus. Sed nisl turpis, pulvinar ut bibendum non, dignissim quis nibh. Cras interdum dictum dui, at venenatis magna auctor a. In a turpis risus, quis mollis augue. Mauris cursus, metus eu accumsan cursus, arcu sapien posuere elit, in viverra nisi diam non arcu. Maecenas ultricies commodo diam, sit amet mattis sapien accumsan ut. Vivamus a felis in enim porta congue. Cras dui tortor, adipiscing imperdiet tempus eu, adipiscing id tellus. Quisque id varius metus. Suspendisse ac euismod neque. Nullam orci dui, tincidunt nec mollis quis, aliquet nec risus. Pellentesque et neque felis, a ullamcorper lacus. Quisque mollis, odio sed fringilla rutrum, elit ipsum adipiscing turpis, sit amet mollis purus neque sed nibh. Donec vitae arcu lorem. Suspendisse id elit felis, non condimentum mauris. Nullam ullamcorper volutpat urna vel feugiat.</p>', NULL, NULL, 1, 1, 4, 0, 0, NULL, 'Inherit', 'Inherit', 0, 3, 21, 'None', 0),
(26, 'HelpArticle', '2015-03-16 19:34:21', '2015-03-16 19:34:33', 'wired-and-wireless-network-problems', 'Wired and wireless network problems', NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus. Donec iaculis, est ut adipiscing cursus, lectus turpis tristique massa, faucibus faucibus urna odio nec ante. Integer magna purus, tincidunt ut vestibulum eget, mattis sit amet purus. Donec interdum orci nec felis pulvinar hendrerit. Donec suscipit turpis et libero fermentum non venenatis massa eleifend. Maecenas fringilla consectetur risus vel venenatis. Sed tincidunt tellus sit amet tellus mattis a malesuada dui vulputate. Aenean ut orci metus, vitae bibendum diam. Aliquam sit amet leo sed est convallis blandit vel sed libero. Integer leo nisi, viverra sit amet congue in, suscipit ac orci. Ut ut nulla at nulla posuere rutrum. Etiam cursus ultricies placerat. Praesent eu tellus nec enim pulvinar porta. Maecenas faucibus interdum turpis, sed rhoncus ante luctus vel. Duis ut orci nec metus lobortis commodo. Donec aliquet, leo non vestibulum dictum, ante justo molestie leo, id eleifend diam odio nec tellus. Cras consequat nunc a quam interdum luctus mollis velit viverra.</p>\n<p>Nulla at leo eros, nec porttitor erat. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed venenatis facilisis dolor id pulvinar. Suspendisse tincidunt, arcu vestibulum venenatis blandit, arcu quam scelerisque nibh, nec imperdiet tellus tellus nec mauris. Suspendisse cursus varius velit, vel ultricies tortor fringilla pretium. Pellentesque posuere lobortis vehicula. Proin scelerisque dapibus eros, eget iaculis metus ultrices vel. Morbi malesuada ligula sit amet mauris mollis sed vulputate tellus fringilla. Maecenas at velit sem. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum in arcu quis odio ullamcorper vulputate. Etiam tempor placerat lorem, id rhoncus erat vulputate sed. Pellentesque dapibus sollicitudin ipsum. Aliquam sollicitudin augue sit amet sapien tristique vel tristique nisl auctor. Aliquam porta, dui quis molestie vehicula, sem est luctus felis, id suscipit massa ipsum sed elit. Quisque vehicula nulla nec felis egestas id pellentesque risus condimentum. Nam varius purus quis erat egestas feugiat. Duis a odio eros, a vehicula sapien. Pellentesque ac dolor in velit aliquam gravida.</p>\n<p>Donec ut bibendum risus. Sed nisl turpis, pulvinar ut bibendum non, dignissim quis nibh. Cras interdum dictum dui, at venenatis magna auctor a. In a turpis risus, quis mollis augue. Mauris cursus, metus eu accumsan cursus, arcu sapien posuere elit, in viverra nisi diam non arcu. Maecenas ultricies commodo diam, sit amet mattis sapien accumsan ut. Vivamus a felis in enim porta congue. Cras dui tortor, adipiscing imperdiet tempus eu, adipiscing id tellus. Quisque id varius metus. Suspendisse ac euismod neque. Nullam orci dui, tincidunt nec mollis quis, aliquet nec risus. Pellentesque et neque felis, a ullamcorper lacus. Quisque mollis, odio sed fringilla rutrum, elit ipsum adipiscing turpis, sit amet mollis purus neque sed nibh. Donec vitae arcu lorem. Suspendisse id elit felis, non condimentum mauris. Nullam ullamcorper volutpat urna vel feugiat.</p>', NULL, NULL, 1, 1, 5, 0, 0, NULL, 'Inherit', 'Inherit', 0, 2, 21, 'None', 0),
(27, 'HelpArticle', '2015-03-16 19:34:41', '2015-03-16 19:35:08', 'setting-up-email', 'Setting up email', NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus. Donec iaculis, est ut adipiscing cursus, lectus turpis tristique massa, faucibus faucibus urna odio nec ante. Integer magna purus, tincidunt ut vestibulum eget, mattis sit amet purus. Donec interdum orci nec felis pulvinar hendrerit. Donec suscipit turpis et libero fermentum non venenatis massa eleifend. Maecenas fringilla consectetur risus vel venenatis. Sed tincidunt tellus sit amet tellus mattis a malesuada dui vulputate. Aenean ut orci metus, vitae bibendum diam. Aliquam sit amet leo sed est convallis blandit vel sed libero. Integer leo nisi, viverra sit amet congue in, suscipit ac orci. Ut ut nulla at nulla posuere rutrum. Etiam cursus ultricies placerat. Praesent eu tellus nec enim pulvinar porta. Maecenas faucibus interdum turpis, sed rhoncus ante luctus vel. Duis ut orci nec metus lobortis commodo. Donec aliquet, leo non vestibulum dictum, ante justo molestie leo, id eleifend diam odio nec tellus. Cras consequat nunc a quam interdum luctus mollis velit viverra.</p>\n<p>Nulla at leo eros, nec porttitor erat. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed venenatis facilisis dolor id pulvinar. Suspendisse tincidunt, arcu vestibulum venenatis blandit, arcu quam scelerisque nibh, nec imperdiet tellus tellus nec mauris. Suspendisse cursus varius velit, vel ultricies tortor fringilla pretium. Pellentesque posuere lobortis vehicula. Proin scelerisque dapibus eros, eget iaculis metus ultrices vel. Morbi malesuada ligula sit amet mauris mollis sed vulputate tellus fringilla. Maecenas at velit sem. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum in arcu quis odio ullamcorper vulputate. Etiam tempor placerat lorem, id rhoncus erat vulputate sed. Pellentesque dapibus sollicitudin ipsum. Aliquam sollicitudin augue sit amet sapien tristique vel tristique nisl auctor. Aliquam porta, dui quis molestie vehicula, sem est luctus felis, id suscipit massa ipsum sed elit. Quisque vehicula nulla nec felis egestas id pellentesque risus condimentum. Nam varius purus quis erat egestas feugiat. Duis a odio eros, a vehicula sapien. Pellentesque ac dolor in velit aliquam gravida.</p>\n<p>Donec ut bibendum risus. Sed nisl turpis, pulvinar ut bibendum non, dignissim quis nibh. Cras interdum dictum dui, at venenatis magna auctor a. In a turpis risus, quis mollis augue. Mauris cursus, metus eu accumsan cursus, arcu sapien posuere elit, in viverra nisi diam non arcu. Maecenas ultricies commodo diam, sit amet mattis sapien accumsan ut. Vivamus a felis in enim porta congue. Cras dui tortor, adipiscing imperdiet tempus eu, adipiscing id tellus. Quisque id varius metus. Suspendisse ac euismod neque. Nullam orci dui, tincidunt nec mollis quis, aliquet nec risus. Pellentesque et neque felis, a ullamcorper lacus. Quisque mollis, odio sed fringilla rutrum, elit ipsum adipiscing turpis, sit amet mollis purus neque sed nibh. Donec vitae arcu lorem. Suspendisse id elit felis, non condimentum mauris. Nullam ullamcorper volutpat urna vel feugiat.</p>', NULL, NULL, 1, 1, 6, 0, 0, NULL, 'Inherit', 'Inherit', 0, 2, 21, 'None', 0),
(28, 'RedirectorPage', '2015-03-17 20:11:10', '2015-03-17 20:11:36', '404-error-page', '404 Error Page', NULL, NULL, NULL, NULL, 1, 1, 6, 0, 0, NULL, 'Inherit', 'Inherit', 0, 2, 8, 'None', 0);

-- --------------------------------------------------------

--
-- Table structure for table `SiteTree_versions`
--

CREATE TABLE IF NOT EXISTS `SiteTree_versions` (
`ID` int(11) NOT NULL,
  `RecordID` int(11) NOT NULL DEFAULT '0',
  `Version` int(11) NOT NULL DEFAULT '0',
  `WasPublished` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `AuthorID` int(11) NOT NULL DEFAULT '0',
  `PublisherID` int(11) NOT NULL DEFAULT '0',
  `ClassName` enum('SiteTree','Page','Blog','BlogPost','BlogEntry','ErrorPage','RedirectorPage','VirtualPage','UserDefinedForm','ContactPage','AboutPage','HelpArticle','HelpPage','HomePage','PortfolioItem','PortfolioPage','ServicePage','TimelineItem','TimelinePage','BlogTree','BlogHolder') CHARACTER SET utf8 DEFAULT 'SiteTree',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `URLSegment` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Title` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `MenuTitle` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `Content` mediumtext CHARACTER SET utf8,
  `MetaDescription` mediumtext CHARACTER SET utf8,
  `ExtraMeta` mediumtext CHARACTER SET utf8,
  `ShowInMenus` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ShowInSearch` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `Sort` int(11) NOT NULL DEFAULT '0',
  `HasBrokenFile` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `HasBrokenLink` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ReportClass` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `CanViewType` enum('Anyone','LoggedInUsers','OnlyTheseUsers','Inherit') CHARACTER SET utf8 DEFAULT 'Inherit',
  `CanEditType` enum('LoggedInUsers','OnlyTheseUsers','Inherit') CHARACTER SET utf8 DEFAULT 'Inherit',
  `ProvideComments` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ParentID` int(11) NOT NULL DEFAULT '0',
  `ModerationRequired` enum('None','Required','NonMembersOnly') CHARACTER SET utf8 DEFAULT 'None',
  `CommentsRequireLogin` tinyint(1) unsigned NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=179 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `SiteTree_versions`
--

INSERT INTO `SiteTree_versions` (`ID`, `RecordID`, `Version`, `WasPublished`, `AuthorID`, `PublisherID`, `ClassName`, `Created`, `LastEdited`, `URLSegment`, `Title`, `MenuTitle`, `Content`, `MetaDescription`, `ExtraMeta`, `ShowInMenus`, `ShowInSearch`, `Sort`, `HasBrokenFile`, `HasBrokenLink`, `ReportClass`, `CanViewType`, `CanEditType`, `ProvideComments`, `ParentID`, `ModerationRequired`, `CommentsRequireLogin`) VALUES
(1, 1, 1, 1, 0, 0, 'Page', '2015-01-26 04:46:25', '2015-01-26 04:46:25', 'home', 'Home', NULL, '<p>Welcome to SilverStripe! This is the default homepage. You can edit this page by opening <a href="admin/">the CMS</a>. You can now access the <a href="http://doc.silverstripe.org">developer documentation</a>, or begin <a href="http://doc.silverstripe.org/doku.php?id=tutorials">the tutorials.</a></p>', NULL, NULL, 1, 1, 1, 0, 0, NULL, 'Inherit', 'Inherit', 0, 0, 'None', 0),
(15, 3, 2, 0, 1, 0, 'Page', '2015-01-26 04:46:26', '2015-01-27 09:43:54', 'contact-us', 'Contact Us', NULL, '<p>You can fill this page out with your own content, or delete it and create your own pages.<br /></p>', NULL, NULL, 1, 1, 4, 0, 0, NULL, 'Inherit', 'Inherit', 0, 8, 'None', 0),
(18, 9, 1, 0, 1, 0, 'Page', '2015-01-27 09:45:10', '2015-01-27 09:45:10', 'new-page', 'New Page', NULL, NULL, NULL, NULL, 1, 1, 8, 0, 0, NULL, 'Inherit', 'Inherit', 0, 0, 'None', 0),
(19, 9, 2, 1, 1, 1, 'Page', '2015-01-27 09:45:10', '2015-01-27 09:45:33', 'portfolio', 'Portfolio', NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus. Donec iaculis, est ut adipiscing cursus, lectus turpis tristique massa, faucibus faucibus urna odio nec ante. Integer magna purus, tincidunt ut vestibulum eget, mattis sit amet purus. Donec interdum orci nec felis pulvinar hendrerit. Donec suscipit turpis et libero fermentum non venenatis massa eleifend. Maecenas fringilla consectetur risus vel venenatis. Sed tincidunt tellus sit amet tellus mattis a malesuada dui vulputate. Aenean ut orci metus, vitae bibendum diam. Aliquam sit amet leo sed est convallis blandit vel sed libero. Integer leo nisi, viverra sit amet congue in, suscipit ac orci. Ut ut nulla at nulla posuere rutrum. Etiam cursus ultricies placerat. Praesent eu tellus nec enim pulvinar porta. Maecenas faucibus interdum turpis, sed rhoncus ante luctus vel. Duis ut orci nec metus lobortis commodo. Donec aliquet, leo non vestibulum dictum, ante justo molestie leo, id eleifend diam odio nec tellus. Cras consequat nunc a quam interdum luctus mollis velit viverra.</p>\n<p>Nulla at leo eros, nec porttitor erat. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed venenatis facilisis dolor id pulvinar. Suspendisse tincidunt, arcu vestibulum venenatis blandit, arcu quam scelerisque nibh, nec imperdiet tellus tellus nec mauris. Suspendisse cursus varius velit, vel ultricies tortor fringilla pretium. Pellentesque posuere lobortis vehicula. Proin scelerisque dapibus eros, eget iaculis metus ultrices vel. Morbi malesuada ligula sit amet mauris mollis sed vulputate tellus fringilla. Maecenas at velit sem. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum in arcu quis odio ullamcorper vulputate. Etiam tempor placerat lorem, id rhoncus erat vulputate sed. Pellentesque dapibus sollicitudin ipsum. Aliquam sollicitudin augue sit amet sapien tristique vel tristique nisl auctor. Aliquam porta, dui quis molestie vehicula, sem est luctus felis, id suscipit massa ipsum sed elit. Quisque vehicula nulla nec felis egestas id pellentesque risus condimentum. Nam varius purus quis erat egestas feugiat. Duis a odio eros, a vehicula sapien. Pellentesque ac dolor in velit aliquam gravida.</p>\n<p>Donec ut bibendum risus. Sed nisl turpis, pulvinar ut bibendum non, dignissim quis nibh. Cras interdum dictum dui, at venenatis magna auctor a. In a turpis risus, quis mollis augue. Mauris cursus, metus eu accumsan cursus, arcu sapien posuere elit, in viverra nisi diam non arcu. Maecenas ultricies commodo diam, sit amet mattis sapien accumsan ut. Vivamus a felis in enim porta congue. Cras dui tortor, adipiscing imperdiet tempus eu, adipiscing id tellus. Quisque id varius metus. Suspendisse ac euismod neque. Nullam orci dui, tincidunt nec mollis quis, aliquet nec risus. Pellentesque et neque felis, a ullamcorper lacus. Quisque mollis, odio sed fringilla rutrum, elit ipsum adipiscing turpis, sit amet mollis purus neque sed nibh. Donec vitae arcu lorem. Suspendisse id elit felis, non condimentum mauris. Nullam ullamcorper volutpat urna vel feugiat.</p>', NULL, NULL, 1, 1, 8, 0, 0, NULL, 'Inherit', 'Inherit', 0, 0, 'None', 0),
(4, 4, 1, 1, 0, 0, 'BlogHolder', '2015-01-26 04:46:26', '2015-01-26 04:46:26', 'blog', 'Blog', NULL, NULL, NULL, NULL, 1, 1, 4, 0, 0, NULL, 'Inherit', 'Inherit', 0, 0, 'None', 0),
(5, 5, 1, 1, 0, 0, 'BlogEntry', '2015-01-26 04:46:26', '2015-01-26 04:46:26', 'sample-blog-entry', 'SilverStripe blog module successfully installed', NULL, '<p>Congratulations, the SilverStripe blog module has been successfully installed. This blog entry can be safely deleted. You can configure aspects of your blog in <a href="admin">the CMS</a>.</p>', NULL, NULL, 0, 1, 0, 0, 0, NULL, 'Inherit', 'Inherit', 1, 4, 'None', 0),
(6, 6, 1, 1, 0, 0, 'ErrorPage', '2015-01-26 04:46:26', '2015-01-26 04:46:26', 'page-not-found', 'Page not found', NULL, '<p>Sorry, it seems you were trying to access a page that doesn''t exist.</p><p>Please check the spelling of the URL you were trying to access and try again.</p>', NULL, NULL, 0, 0, 5, 0, 0, NULL, 'Inherit', 'Inherit', 0, 0, 'None', 0),
(7, 7, 1, 1, 0, 0, 'ErrorPage', '2015-01-26 04:46:27', '2015-01-26 04:46:27', 'server-error', 'Server error', NULL, '<p>Sorry, there was a problem with handling your request.</p>', NULL, NULL, 0, 0, 6, 0, 0, NULL, 'Inherit', 'Inherit', 0, 0, 'None', 0),
(8, 5, 2, 0, 0, 0, 'BlogEntry', '2015-01-26 04:46:26', '2015-01-26 04:46:27', 'sample-blog-entry', 'SilverStripe blog module successfully installed', NULL, '<p>Congratulations, the SilverStripe blog module has been successfully installed. This blog entry can be safely deleted. You can configure aspects of your blog in <a href="admin">the CMS</a>.</p>', NULL, NULL, 0, 1, 1, 0, 0, NULL, 'Inherit', 'Inherit', 1, 4, 'None', 0),
(9, 8, 1, 0, 1, 0, 'Page', '2015-01-27 09:42:21', '2015-01-27 09:42:21', 'new-page', 'New Page', NULL, NULL, NULL, NULL, 1, 1, 7, 0, 0, NULL, 'Inherit', 'Inherit', 0, 0, 'None', 0),
(10, 8, 2, 1, 1, 1, 'Page', '2015-01-27 09:42:21', '2015-01-27 09:42:57', 'pages', 'Pages', NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus. Donec iaculis, est ut adipiscing cursus, lectus turpis tristique massa, faucibus faucibus urna odio nec ante. Integer magna purus, tincidunt ut vestibulum eget, mattis sit amet purus. Donec interdum orci nec felis pulvinar hendrerit. Donec suscipit turpis et libero fermentum non venenatis massa eleifend. Maecenas fringilla consectetur risus vel venenatis. Sed tincidunt tellus sit amet tellus mattis a malesuada dui vulputate. Aenean ut orci metus, vitae bibendum diam. Aliquam sit amet leo sed est convallis blandit vel sed libero. Integer leo nisi, viverra sit amet congue in, suscipit ac orci. Ut ut nulla at nulla posuere rutrum. Etiam cursus ultricies placerat. Praesent eu tellus nec enim pulvinar porta. Maecenas faucibus interdum turpis, sed rhoncus ante luctus vel. Duis ut orci nec metus lobortis commodo. Donec aliquet, leo non vestibulum dictum, ante justo molestie leo, id eleifend diam odio nec tellus. Cras consequat nunc a quam interdum luctus mollis velit viverra.</p>\n<p>Nulla at leo eros, nec porttitor erat. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed venenatis facilisis dolor id pulvinar. Suspendisse tincidunt, arcu vestibulum venenatis blandit, arcu quam scelerisque nibh, nec imperdiet tellus tellus nec mauris. Suspendisse cursus varius velit, vel ultricies tortor fringilla pretium. Pellentesque posuere lobortis vehicula. Proin scelerisque dapibus eros, eget iaculis metus ultrices vel. Morbi malesuada ligula sit amet mauris mollis sed vulputate tellus fringilla. Maecenas at velit sem. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum in arcu quis odio ullamcorper vulputate. Etiam tempor placerat lorem, id rhoncus erat vulputate sed. Pellentesque dapibus sollicitudin ipsum. Aliquam sollicitudin augue sit amet sapien tristique vel tristique nisl auctor. Aliquam porta, dui quis molestie vehicula, sem est luctus felis, id suscipit massa ipsum sed elit. Quisque vehicula nulla nec felis egestas id pellentesque risus condimentum. Nam varius purus quis erat egestas feugiat. Duis a odio eros, a vehicula sapien. Pellentesque ac dolor in velit aliquam gravida.</p>\n<p>Donec ut bibendum risus. Sed nisl turpis, pulvinar ut bibendum non, dignissim quis nibh. Cras interdum dictum dui, at venenatis magna auctor a. In a turpis risus, quis mollis augue. Mauris cursus, metus eu accumsan cursus, arcu sapien posuere elit, in viverra nisi diam non arcu. Maecenas ultricies commodo diam, sit amet mattis sapien accumsan ut. Vivamus a felis in enim porta congue. Cras dui tortor, adipiscing imperdiet tempus eu, adipiscing id tellus. Quisque id varius metus. Suspendisse ac euismod neque. Nullam orci dui, tincidunt nec mollis quis, aliquet nec risus. Pellentesque et neque felis, a ullamcorper lacus. Quisque mollis, odio sed fringilla rutrum, elit ipsum adipiscing turpis, sit amet mollis purus neque sed nibh. Donec vitae arcu lorem. Suspendisse id elit felis, non condimentum mauris. Nullam ullamcorper volutpat urna vel feugiat.</p>', NULL, NULL, 1, 1, 7, 0, 0, NULL, 'Inherit', 'Inherit', 0, 0, 'None', 0),
(11, 8, 3, 1, 1, 1, 'Page', '2015-01-27 09:42:21', '2015-01-27 09:43:24', 'pages', 'Pages', NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus. Donec iaculis, est ut adipiscing cursus, lectus turpis tristique massa, faucibus faucibus urna odio nec ante. Integer magna purus, tincidunt ut vestibulum eget, mattis sit amet purus. Donec interdum orci nec felis pulvinar hendrerit. Donec suscipit turpis et libero fermentum non venenatis massa eleifend. Maecenas fringilla consectetur risus vel venenatis. Sed tincidunt tellus sit amet tellus mattis a malesuada dui vulputate. Aenean ut orci metus, vitae bibendum diam. Aliquam sit amet leo sed est convallis blandit vel sed libero. Integer leo nisi, viverra sit amet congue in, suscipit ac orci. Ut ut nulla at nulla posuere rutrum. Etiam cursus ultricies placerat. Praesent eu tellus nec enim pulvinar porta. Maecenas faucibus interdum turpis, sed rhoncus ante luctus vel. Duis ut orci nec metus lobortis commodo. Donec aliquet, leo non vestibulum dictum, ante justo molestie leo, id eleifend diam odio nec tellus. Cras consequat nunc a quam interdum luctus mollis velit viverra.</p>\n<p>Nulla at leo eros, nec porttitor erat. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed venenatis facilisis dolor id pulvinar. Suspendisse tincidunt, arcu vestibulum venenatis blandit, arcu quam scelerisque nibh, nec imperdiet tellus tellus nec mauris. Suspendisse cursus varius velit, vel ultricies tortor fringilla pretium. Pellentesque posuere lobortis vehicula. Proin scelerisque dapibus eros, eget iaculis metus ultrices vel. Morbi malesuada ligula sit amet mauris mollis sed vulputate tellus fringilla. Maecenas at velit sem. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum in arcu quis odio ullamcorper vulputate. Etiam tempor placerat lorem, id rhoncus erat vulputate sed. Pellentesque dapibus sollicitudin ipsum. Aliquam sollicitudin augue sit amet sapien tristique vel tristique nisl auctor. Aliquam porta, dui quis molestie vehicula, sem est luctus felis, id suscipit massa ipsum sed elit. Quisque vehicula nulla nec felis egestas id pellentesque risus condimentum. Nam varius purus quis erat egestas feugiat. Duis a odio eros, a vehicula sapien. Pellentesque ac dolor in velit aliquam gravida.</p>\n<p>Donec ut bibendum risus. Sed nisl turpis, pulvinar ut bibendum non, dignissim quis nibh. Cras interdum dictum dui, at venenatis magna auctor a. In a turpis risus, quis mollis augue. Mauris cursus, metus eu accumsan cursus, arcu sapien posuere elit, in viverra nisi diam non arcu. Maecenas ultricies commodo diam, sit amet mattis sapien accumsan ut. Vivamus a felis in enim porta congue. Cras dui tortor, adipiscing imperdiet tempus eu, adipiscing id tellus. Quisque id varius metus. Suspendisse ac euismod neque. Nullam orci dui, tincidunt nec mollis quis, aliquet nec risus. Pellentesque et neque felis, a ullamcorper lacus. Quisque mollis, odio sed fringilla rutrum, elit ipsum adipiscing turpis, sit amet mollis purus neque sed nibh. Donec vitae arcu lorem. Suspendisse id elit felis, non condimentum mauris. Nullam ullamcorper volutpat urna vel feugiat.</p>', NULL, NULL, 1, 1, 2, 0, 0, NULL, 'Inherit', 'Inherit', 0, 0, 'None', 0),
(12, 2, 2, 0, 1, 0, 'Page', '2015-01-26 04:46:26', '2015-01-27 09:43:38', 'about-us', 'About Us', NULL, '<p>You can fill this page out with your own content, or delete it and create your own pages.<br /></p>', NULL, NULL, 1, 1, 3, 0, 0, NULL, 'Inherit', 'Inherit', 0, 8, 'None', 0),
(13, 2, 3, 0, 1, 0, 'Page', '2015-01-26 04:46:26', '2015-01-27 09:43:38', 'about-us', 'About Us', NULL, '<p>You can fill this page out with your own content, or delete it and create your own pages.<br /></p>', NULL, NULL, 1, 1, 1, 0, 0, NULL, 'Inherit', 'Inherit', 0, 8, 'None', 0),
(14, 2, 4, 1, 1, 1, 'Page', '2015-01-26 04:46:26', '2015-01-27 09:43:48', 'about-us', 'About Us', NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus. Donec iaculis, est ut adipiscing cursus, lectus turpis tristique massa, faucibus faucibus urna odio nec ante. Integer magna purus, tincidunt ut vestibulum eget, mattis sit amet purus. Donec interdum orci nec felis pulvinar hendrerit. Donec suscipit turpis et libero fermentum non venenatis massa eleifend. Maecenas fringilla consectetur risus vel venenatis. Sed tincidunt tellus sit amet tellus mattis a malesuada dui vulputate. Aenean ut orci metus, vitae bibendum diam. Aliquam sit amet leo sed est convallis blandit vel sed libero. Integer leo nisi, viverra sit amet congue in, suscipit ac orci. Ut ut nulla at nulla posuere rutrum. Etiam cursus ultricies placerat. Praesent eu tellus nec enim pulvinar porta. Maecenas faucibus interdum turpis, sed rhoncus ante luctus vel. Duis ut orci nec metus lobortis commodo. Donec aliquet, leo non vestibulum dictum, ante justo molestie leo, id eleifend diam odio nec tellus. Cras consequat nunc a quam interdum luctus mollis velit viverra.</p>\n<p>Nulla at leo eros, nec porttitor erat. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed venenatis facilisis dolor id pulvinar. Suspendisse tincidunt, arcu vestibulum venenatis blandit, arcu quam scelerisque nibh, nec imperdiet tellus tellus nec mauris. Suspendisse cursus varius velit, vel ultricies tortor fringilla pretium. Pellentesque posuere lobortis vehicula. Proin scelerisque dapibus eros, eget iaculis metus ultrices vel. Morbi malesuada ligula sit amet mauris mollis sed vulputate tellus fringilla. Maecenas at velit sem. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum in arcu quis odio ullamcorper vulputate. Etiam tempor placerat lorem, id rhoncus erat vulputate sed. Pellentesque dapibus sollicitudin ipsum. Aliquam sollicitudin augue sit amet sapien tristique vel tristique nisl auctor. Aliquam porta, dui quis molestie vehicula, sem est luctus felis, id suscipit massa ipsum sed elit. Quisque vehicula nulla nec felis egestas id pellentesque risus condimentum. Nam varius purus quis erat egestas feugiat. Duis a odio eros, a vehicula sapien. Pellentesque ac dolor in velit aliquam gravida.</p>\n<p>Donec ut bibendum risus. Sed nisl turpis, pulvinar ut bibendum non, dignissim quis nibh. Cras interdum dictum dui, at venenatis magna auctor a. In a turpis risus, quis mollis augue. Mauris cursus, metus eu accumsan cursus, arcu sapien posuere elit, in viverra nisi diam non arcu. Maecenas ultricies commodo diam, sit amet mattis sapien accumsan ut. Vivamus a felis in enim porta congue. Cras dui tortor, adipiscing imperdiet tempus eu, adipiscing id tellus. Quisque id varius metus. Suspendisse ac euismod neque. Nullam orci dui, tincidunt nec mollis quis, aliquet nec risus. Pellentesque et neque felis, a ullamcorper lacus. Quisque mollis, odio sed fringilla rutrum, elit ipsum adipiscing turpis, sit amet mollis purus neque sed nibh. Donec vitae arcu lorem. Suspendisse id elit felis, non condimentum mauris. Nullam ullamcorper volutpat urna vel feugiat.</p>', NULL, NULL, 1, 1, 1, 0, 0, NULL, 'Inherit', 'Inherit', 0, 8, 'None', 0),
(16, 3, 3, 0, 1, 0, 'Page', '2015-01-26 04:46:26', '2015-01-27 09:43:54', 'contact-us', 'Contact Us', NULL, '<p>You can fill this page out with your own content, or delete it and create your own pages.<br /></p>', NULL, NULL, 1, 1, 1, 0, 0, NULL, 'Inherit', 'Inherit', 0, 8, 'None', 0),
(17, 3, 4, 1, 1, 1, 'Page', '2015-01-26 04:46:26', '2015-01-27 09:44:05', 'contact-us', 'Contact Us', NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus. Donec iaculis, est ut adipiscing cursus, lectus turpis tristique massa, faucibus faucibus urna odio nec ante. Integer magna purus, tincidunt ut vestibulum eget, mattis sit amet purus. Donec interdum orci nec felis pulvinar hendrerit. Donec suscipit turpis et libero fermentum non venenatis massa eleifend. Maecenas fringilla consectetur risus vel venenatis. Sed tincidunt tellus sit amet tellus mattis a malesuada dui vulputate. Aenean ut orci metus, vitae bibendum diam. Aliquam sit amet leo sed est convallis blandit vel sed libero. Integer leo nisi, viverra sit amet congue in, suscipit ac orci. Ut ut nulla at nulla posuere rutrum. Etiam cursus ultricies placerat. Praesent eu tellus nec enim pulvinar porta. Maecenas faucibus interdum turpis, sed rhoncus ante luctus vel. Duis ut orci nec metus lobortis commodo. Donec aliquet, leo non vestibulum dictum, ante justo molestie leo, id eleifend diam odio nec tellus. Cras consequat nunc a quam interdum luctus mollis velit viverra.</p>\n<p>Nulla at leo eros, nec porttitor erat. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed venenatis facilisis dolor id pulvinar. Suspendisse tincidunt, arcu vestibulum venenatis blandit, arcu quam scelerisque nibh, nec imperdiet tellus tellus nec mauris. Suspendisse cursus varius velit, vel ultricies tortor fringilla pretium. Pellentesque posuere lobortis vehicula. Proin scelerisque dapibus eros, eget iaculis metus ultrices vel. Morbi malesuada ligula sit amet mauris mollis sed vulputate tellus fringilla. Maecenas at velit sem. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum in arcu quis odio ullamcorper vulputate. Etiam tempor placerat lorem, id rhoncus erat vulputate sed. Pellentesque dapibus sollicitudin ipsum. Aliquam sollicitudin augue sit amet sapien tristique vel tristique nisl auctor. Aliquam porta, dui quis molestie vehicula, sem est luctus felis, id suscipit massa ipsum sed elit. Quisque vehicula nulla nec felis egestas id pellentesque risus condimentum. Nam varius purus quis erat egestas feugiat. Duis a odio eros, a vehicula sapien. Pellentesque ac dolor in velit aliquam gravida.</p>\n<p>Donec ut bibendum risus. Sed nisl turpis, pulvinar ut bibendum non, dignissim quis nibh. Cras interdum dictum dui, at venenatis magna auctor a. In a turpis risus, quis mollis augue. Mauris cursus, metus eu accumsan cursus, arcu sapien posuere elit, in viverra nisi diam non arcu. Maecenas ultricies commodo diam, sit amet mattis sapien accumsan ut. Vivamus a felis in enim porta congue. Cras dui tortor, adipiscing imperdiet tempus eu, adipiscing id tellus. Quisque id varius metus. Suspendisse ac euismod neque. Nullam orci dui, tincidunt nec mollis quis, aliquet nec risus. Pellentesque et neque felis, a ullamcorper lacus. Quisque mollis, odio sed fringilla rutrum, elit ipsum adipiscing turpis, sit amet mollis purus neque sed nibh. Donec vitae arcu lorem. Suspendisse id elit felis, non condimentum mauris. Nullam ullamcorper volutpat urna vel feugiat.</p>', NULL, NULL, 1, 1, 1, 0, 0, NULL, 'Inherit', 'Inherit', 0, 8, 'None', 0),
(20, 9, 3, 1, 1, 1, 'Page', '2015-01-27 09:45:10', '2015-01-27 09:45:42', 'portfolio', 'Portfolio', NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus. Donec iaculis, est ut adipiscing cursus, lectus turpis tristique massa, faucibus faucibus urna odio nec ante. Integer magna purus, tincidunt ut vestibulum eget, mattis sit amet purus. Donec interdum orci nec felis pulvinar hendrerit. Donec suscipit turpis et libero fermentum non venenatis massa eleifend. Maecenas fringilla consectetur risus vel venenatis. Sed tincidunt tellus sit amet tellus mattis a malesuada dui vulputate. Aenean ut orci metus, vitae bibendum diam. Aliquam sit amet leo sed est convallis blandit vel sed libero. Integer leo nisi, viverra sit amet congue in, suscipit ac orci. Ut ut nulla at nulla posuere rutrum. Etiam cursus ultricies placerat. Praesent eu tellus nec enim pulvinar porta. Maecenas faucibus interdum turpis, sed rhoncus ante luctus vel. Duis ut orci nec metus lobortis commodo. Donec aliquet, leo non vestibulum dictum, ante justo molestie leo, id eleifend diam odio nec tellus. Cras consequat nunc a quam interdum luctus mollis velit viverra.</p>\n<p>Nulla at leo eros, nec porttitor erat. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed venenatis facilisis dolor id pulvinar. Suspendisse tincidunt, arcu vestibulum venenatis blandit, arcu quam scelerisque nibh, nec imperdiet tellus tellus nec mauris. Suspendisse cursus varius velit, vel ultricies tortor fringilla pretium. Pellentesque posuere lobortis vehicula. Proin scelerisque dapibus eros, eget iaculis metus ultrices vel. Morbi malesuada ligula sit amet mauris mollis sed vulputate tellus fringilla. Maecenas at velit sem. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum in arcu quis odio ullamcorper vulputate. Etiam tempor placerat lorem, id rhoncus erat vulputate sed. Pellentesque dapibus sollicitudin ipsum. Aliquam sollicitudin augue sit amet sapien tristique vel tristique nisl auctor. Aliquam porta, dui quis molestie vehicula, sem est luctus felis, id suscipit massa ipsum sed elit. Quisque vehicula nulla nec felis egestas id pellentesque risus condimentum. Nam varius purus quis erat egestas feugiat. Duis a odio eros, a vehicula sapien. Pellentesque ac dolor in velit aliquam gravida.</p>\n<p>Donec ut bibendum risus. Sed nisl turpis, pulvinar ut bibendum non, dignissim quis nibh. Cras interdum dictum dui, at venenatis magna auctor a. In a turpis risus, quis mollis augue. Mauris cursus, metus eu accumsan cursus, arcu sapien posuere elit, in viverra nisi diam non arcu. Maecenas ultricies commodo diam, sit amet mattis sapien accumsan ut. Vivamus a felis in enim porta congue. Cras dui tortor, adipiscing imperdiet tempus eu, adipiscing id tellus. Quisque id varius metus. Suspendisse ac euismod neque. Nullam orci dui, tincidunt nec mollis quis, aliquet nec risus. Pellentesque et neque felis, a ullamcorper lacus. Quisque mollis, odio sed fringilla rutrum, elit ipsum adipiscing turpis, sit amet mollis purus neque sed nibh. Donec vitae arcu lorem. Suspendisse id elit felis, non condimentum mauris. Nullam ullamcorper volutpat urna vel feugiat.</p>', NULL, NULL, 1, 1, 3, 0, 0, NULL, 'Inherit', 'Inherit', 0, 0, 'None', 0),
(50, 18, 1, 1, 1, 1, 'TimelineItem', '2015-02-08 18:05:54', '2015-02-10 11:44:41', 'event-2', 'Event 002', NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus. Donec iaculis, est ut adipiscing cursus, lectus turpis tristique massa, faucibus faucibus urna odio nec ante. Integer magna purus, tincidunt ut vestibulum eget, mattis sit amet purus. Donec interdum orci nec felis pulvinar hendrerit. Donec suscipit turpis et libero fermentum non venenatis massa eleifend. Maecenas fringilla consectetur risus vel venenatis. Sed tincidunt tellus sit amet tellus mattis a malesuada dui vulputate. Aenean ut orci metus, vitae bibendum diam. Aliquam sit amet leo sed est convallis blandit vel sed libero. Integer leo nisi, viverra sit amet congue in, suscipit ac orci. Ut ut nulla at nulla posuere rutrum. Etiam cursus ultricies placerat. Praesent eu tellus nec enim pulvinar porta. Maecenas faucibus interdum turpis, sed rhoncus ante luctus vel. Duis ut orci nec metus lobortis commodo. Donec aliquet, leo non vestibulum dictum, ante justo molestie leo, id eleifend diam odio nec tellus. Cras consequat nunc a quam interdum luctus mollis velit viverra.</p>\n<p>Nulla at leo eros, nec porttitor erat. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed venenatis facilisis dolor id pulvinar. Suspendisse tincidunt, arcu vestibulum venenatis blandit, arcu quam scelerisque nibh, nec imperdiet tellus tellus nec mauris. Suspendisse cursus varius velit, vel ultricies tortor fringilla pretium. Pellentesque posuere lobortis vehicula. Proin scelerisque dapibus eros, eget iaculis metus ultrices vel. Morbi malesuada ligula sit amet mauris mollis sed vulputate tellus fringilla. Maecenas at velit sem. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum in arcu quis odio ullamcorper vulputate. Etiam tempor placerat lorem, id rhoncus erat vulputate sed. Pellentesque dapibus sollicitudin ipsum. Aliquam sollicitudin augue sit amet sapien tristique vel tristique nisl auctor. Aliquam porta, dui quis molestie vehicula, sem est luctus felis, id suscipit massa ipsum sed elit. Quisque vehicula nulla nec felis egestas id pellentesque risus condimentum. Nam varius purus quis erat egestas feugiat. Duis a odio eros, a vehicula sapien. Pellentesque ac dolor in velit aliquam gravida.</p>\n<p>Donec ut bibendum risus. Sed nisl turpis, pulvinar ut bibendum non, dignissim quis nibh. Cras interdum dictum dui, at venenatis magna auctor a. In a turpis risus, quis mollis augue. Mauris cursus, metus eu accumsan cursus, arcu sapien posuere elit, in viverra nisi diam non arcu. Maecenas ultricies commodo diam, sit amet mattis sapien accumsan ut. Vivamus a felis in enim porta congue. Cras dui tortor, adipiscing imperdiet tempus eu, adipiscing id tellus. Quisque id varius metus. Suspendisse ac euismod neque. Nullam orci dui, tincidunt nec mollis quis, aliquet nec risus. Pellentesque et neque felis, a ullamcorper lacus. Quisque mollis, odio sed fringilla rutrum, elit ipsum adipiscing turpis, sit amet mollis purus neque sed nibh. Donec vitae arcu lorem. Suspendisse id elit felis, non condimentum mauris. Nullam ullamcorper volutpat urna vel feugiat.</p>', NULL, NULL, 1, 1, 2, 0, 0, NULL, 'Inherit', 'Inherit', 0, 16, 'None', 0),
(166, 9, 8, 1, 1, 1, 'PortfolioPage', '2015-01-27 09:45:10', '2015-03-18 19:00:04', 'portfolio', 'Portfolio', NULL, '<p class="lead" style="text-align: center;"><span style="color: #ec7263;">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris nec velit consequat, pharetra risus et, tempus mi. </span></p>', NULL, NULL, 1, 1, 3, 0, 0, NULL, 'Inherit', 'Inherit', 0, 0, 'None', 0),
(168, 12, 4, 1, 1, 1, 'PortfolioItem', '2015-01-28 20:07:31', '2015-03-18 19:26:00', 'portfolio-item-3', 'Portfolio Item #3', NULL, '<p>Integer sodales, lectus et elementum volutpat, ipsum purus tristique dolor, non scelerisque diam sem id neque. Etiam sit amet eros magna. Mauris purus nunc, venenatis vitae erat ac, sagittis consectetur dolor.</p>', NULL, NULL, 1, 1, 3, 0, 0, NULL, 'Inherit', 'Inherit', 0, 9, 'None', 0),
(171, 29, 3, 1, 1, 1, 'BlogPost', '2015-03-18 20:25:32', '2015-03-18 20:26:57', 'lorem-ipsum-dolor-sit-amet-consectetur-adipiscing-elit', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit', NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus. Donec iaculis, est ut adipiscing cursus, lectus turpis tristique massa, faucibus faucibus urna odio nec ante. Integer magna purus, tincidunt ut vestibulum eget, mattis sit amet purus. Donec interdum orci nec felis pulvinar hendrerit. Donec suscipit turpis et libero fermentum non venenatis massa eleifend. Maecenas fringilla consectetur risus vel venenatis. Sed tincidunt tellus sit amet tellus mattis a malesuada dui vulputate. Aenean ut orci metus, vitae bibendum diam. Aliquam sit amet leo sed est convallis blandit vel sed libero. Integer leo nisi, viverra sit amet congue in, suscipit ac orci. Ut ut nulla at nulla posuere rutrum. Etiam cursus ultricies placerat. Praesent eu tellus nec enim pulvinar porta. Maecenas faucibus interdum turpis, sed rhoncus ante luctus vel. Duis ut orci nec metus lobortis commodo. Donec aliquet, leo non vestibulum dictum, ante justo molestie leo, id eleifend diam odio nec tellus. Cras consequat nunc a quam interdum luctus mollis velit viverra.</p>\n<p>Nulla at leo eros, nec porttitor erat. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed venenatis facilisis dolor id pulvinar. Suspendisse tincidunt, arcu vestibulum venenatis blandit, arcu quam scelerisque nibh, nec imperdiet tellus tellus nec mauris. Suspendisse cursus varius velit, vel ultricies tortor fringilla pretium. Pellentesque posuere lobortis vehicula. Proin scelerisque dapibus eros, eget iaculis metus ultrices vel. Morbi malesuada ligula sit amet mauris mollis sed vulputate tellus fringilla. Maecenas at velit sem. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum in arcu quis odio ullamcorper vulputate. Etiam tempor placerat lorem, id rhoncus erat vulputate sed. Pellentesque dapibus sollicitudin ipsum. Aliquam sollicitudin augue sit amet sapien tristique vel tristique nisl auctor. Aliquam porta, dui quis molestie vehicula, sem est luctus felis, id suscipit massa ipsum sed elit. Quisque vehicula nulla nec felis egestas id pellentesque risus condimentum. Nam varius purus quis erat egestas feugiat. Duis a odio eros, a vehicula sapien. Pellentesque ac dolor in velit aliquam gravida.</p>\n<p>Donec ut bibendum risus. Sed nisl turpis, pulvinar ut bibendum non, dignissim quis nibh. Cras interdum dictum dui, at venenatis magna auctor a. In a turpis risus, quis mollis augue. Mauris cursus, metus eu accumsan cursus, arcu sapien posuere elit, in viverra nisi diam non arcu. Maecenas ultricies commodo diam, sit amet mattis sapien accumsan ut. Vivamus a felis in enim porta congue. Cras dui tortor, adipiscing imperdiet tempus eu, adipiscing id tellus. Quisque id varius metus. Suspendisse ac euismod neque. Nullam orci dui, tincidunt nec mollis quis, aliquet nec risus. Pellentesque et neque felis, a ullamcorper lacus. Quisque mollis, odio sed fringilla rutrum, elit ipsum adipiscing turpis, sit amet mollis purus neque sed nibh. Donec vitae arcu lorem. Suspendisse id elit felis, non condimentum mauris. Nullam ullamcorper volutpat urna vel feugiat.</p>', NULL, NULL, 0, 1, 2, 0, 0, NULL, 'Inherit', 'Inherit', 1, 4, 'None', 0),
(167, 12, 3, 1, 1, 1, 'PortfolioItem', '2015-01-28 20:07:31', '2015-03-18 19:25:29', 'portfolio-item-3', 'Portfolio Item #3', NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus. Donec iaculis, est ut adipiscing cursus, lectus turpis tristique massa, faucibus faucibus urna odio nec ante. Integer magna purus, tincidunt ut vestibulum eget, mattis sit amet purus.</p>', NULL, NULL, 1, 1, 3, 0, 0, NULL, 'Inherit', 'Inherit', 0, 9, 'None', 0),
(25, 10, 1, 0, 1, 0, 'PortfolioItem', '2015-01-28 20:07:31', '2015-01-28 20:07:31', 'new-portfolio-item', 'New Portfolio Item', NULL, NULL, NULL, NULL, 1, 1, 1, 0, 0, NULL, 'Inherit', 'Inherit', 0, 9, 'None', 0),
(30, 10, 6, 1, 1, 1, 'PortfolioItem', '2015-01-28 20:07:31', '2015-01-29 04:41:09', 'portfolio-item-1', 'Portfolio Item #1', NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus. Donec iaculis, est ut adipiscing cursus, lectus turpis tristique massa, faucibus faucibus urna odio nec ante. Integer magna purus, tincidunt ut vestibulum eget, mattis sit amet purus. Donec interdum orci nec felis pulvinar hendrerit. Donec suscipit turpis et libero fermentum non venenatis massa eleifend. Maecenas fringilla consectetur risus vel venenatis. Sed tincidunt tellus sit amet tellus mattis a malesuada dui vulputate. Aenean ut orci metus, vitae bibendum diam. Aliquam sit amet leo sed est convallis blandit vel sed libero. Integer leo nisi, viverra sit amet congue in, suscipit ac orci. Ut ut nulla at nulla posuere rutrum. Etiam cursus ultricies placerat. Praesent eu tellus nec enim pulvinar porta. Maecenas faucibus interdum turpis, sed rhoncus ante luctus vel. Duis ut orci nec metus lobortis commodo. Donec aliquet, leo non vestibulum dictum, ante justo molestie leo, id eleifend diam odio nec tellus. Cras consequat nunc a quam interdum luctus mollis velit viverra.</p>', NULL, NULL, 1, 1, 1, 0, 0, NULL, 'Inherit', 'Inherit', 0, 9, 'None', 0),
(31, 10, 7, 1, 1, 1, 'PortfolioItem', '2015-01-28 20:07:31', '2015-01-29 04:41:22', 'portfolio-item-1', 'Portfolio Item #1', NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus. Donec iaculis, est ut adipiscing cursus, lectus turpis tristique massa, faucibus faucibus urna odio nec ante. Integer magna purus, tincidunt ut vestibulum eget, mattis sit amet purus. Donec interdum orci nec felis pulvinar hendrerit. Donec suscipit turpis et libero fermentum non venenatis massa eleifend. Maecenas fringilla consectetur risus vel venenatis. Sed tincidunt tellus sit amet tellus mattis a malesuada dui vulputate. Aenean ut orci metus, vitae bibendum diam. Aliquam sit amet leo sed est convallis blandit vel sed libero. Integer leo nisi, viverra sit amet congue in, suscipit ac orci. Ut ut nulla at nulla posuere rutrum. Etiam cursus ultricies placerat. Praesent eu tellus nec enim pulvinar porta. Maecenas faucibus interdum turpis, sed rhoncus ante luctus vel. Duis ut orci nec metus lobortis commodo. Donec aliquet, leo non vestibulum dictum, ante justo molestie leo, id eleifend diam odio nec tellus. Cras consequat nunc a quam interdum luctus mollis velit viverra.</p>', NULL, NULL, 1, 1, 1, 0, 0, NULL, 'Inherit', 'Inherit', 0, 9, 'None', 0),
(177, 11, 5, 1, 1, 1, 'PortfolioItem', '2015-01-28 20:07:31', '2015-03-19 09:58:51', 'portfolio-item-2', 'Portfolio Item #2', NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus. Donec iaculis, est ut adipiscing cursus, lectus turpis tristique massa, faucibus faucibus urna odio nec ante. Integer magna purus, tincidunt ut vestibulum eget, mattis sit amet purus. Donec interdum orci nec felis pulvinar hendrerit. Donec suscipit turpis et libero fermentum non venenatis massa eleifend. Maecenas fringilla consectetur risus vel venenatis. Sed tincidunt tellus sit amet tellus mattis a malesuada dui vulputate. Aenean ut orci metus, vitae bibendum diam. Aliquam sit amet leo sed est convallis blandit vel sed libero. Integer leo nisi, viverra sit amet congue in, suscipit ac orci. Ut ut nulla at nulla posuere rutrum. Etiam cursus ultricies placerat. Praesent eu tellus nec enim pulvinar porta. Maecenas faucibus interdum turpis, sed rhoncus ante luctus vel. Duis ut orci nec metus lobortis commodo. Donec aliquet, leo non vestibulum dictum, ante justo molestie leo, id eleifend diam odio nec tellus. Cras consequat nunc a quam interdum luctus mollis velit viverra.</p>', NULL, NULL, 1, 1, 1, 0, 0, NULL, 'Inherit', 'Inherit', 0, 9, 'None', 0),
(36, 12, 2, 1, 1, 1, 'PortfolioItem', '2015-01-28 20:07:31', '2015-01-29 04:54:27', 'portfolio-item-3', 'Portfolio Item #3', NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus. Donec iaculis, est ut adipiscing cursus, lectus turpis tristique massa, faucibus faucibus urna odio nec ante. Integer magna purus, tincidunt ut vestibulum eget, mattis sit amet purus. Donec interdum orci nec felis pulvinar hendrerit. Donec suscipit turpis et libero fermentum non venenatis massa eleifend. Maecenas fringilla consectetur risus vel venenatis. Sed tincidunt tellus sit amet tellus mattis a malesuada dui vulputate. Aenean ut orci metus, vitae bibendum diam. Aliquam sit amet leo sed est convallis blandit vel sed libero. Integer leo nisi, viverra sit amet congue in, suscipit ac orci. Ut ut nulla at nulla posuere rutrum. Etiam cursus ultricies placerat. Praesent eu tellus nec enim pulvinar porta. Maecenas faucibus interdum turpis, sed rhoncus ante luctus vel. Duis ut orci nec metus lobortis commodo. Donec aliquet, leo non vestibulum dictum, ante justo molestie leo, id eleifend diam odio nec tellus. Cras consequat nunc a quam interdum luctus mollis velit viverra.</p>', NULL, NULL, 1, 1, 3, 0, 0, NULL, 'Inherit', 'Inherit', 0, 9, 'None', 0),
(169, 29, 1, 0, 1, 0, 'BlogPost', '2015-03-18 20:25:32', '2015-03-18 20:25:32', 'new-blog-post', 'New Blog Post', NULL, NULL, NULL, NULL, 0, 1, 2, 0, 0, NULL, 'Inherit', 'Inherit', 1, 4, 'None', 0),
(170, 29, 2, 0, 1, 0, 'BlogPost', '2015-03-18 20:25:32', '2015-03-18 20:26:57', 'lorem-ipsum-dolor-sit-amet-consectetur-adipiscing-elit', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit', NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus. Donec iaculis, est ut adipiscing cursus, lectus turpis tristique massa, faucibus faucibus urna odio nec ante. Integer magna purus, tincidunt ut vestibulum eget, mattis sit amet purus. Donec interdum orci nec felis pulvinar hendrerit. Donec suscipit turpis et libero fermentum non venenatis massa eleifend. Maecenas fringilla consectetur risus vel venenatis. Sed tincidunt tellus sit amet tellus mattis a malesuada dui vulputate. Aenean ut orci metus, vitae bibendum diam. Aliquam sit amet leo sed est convallis blandit vel sed libero. Integer leo nisi, viverra sit amet congue in, suscipit ac orci. Ut ut nulla at nulla posuere rutrum. Etiam cursus ultricies placerat. Praesent eu tellus nec enim pulvinar porta. Maecenas faucibus interdum turpis, sed rhoncus ante luctus vel. Duis ut orci nec metus lobortis commodo. Donec aliquet, leo non vestibulum dictum, ante justo molestie leo, id eleifend diam odio nec tellus. Cras consequat nunc a quam interdum luctus mollis velit viverra.</p>\n<p>Nulla at leo eros, nec porttitor erat. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed venenatis facilisis dolor id pulvinar. Suspendisse tincidunt, arcu vestibulum venenatis blandit, arcu quam scelerisque nibh, nec imperdiet tellus tellus nec mauris. Suspendisse cursus varius velit, vel ultricies tortor fringilla pretium. Pellentesque posuere lobortis vehicula. Proin scelerisque dapibus eros, eget iaculis metus ultrices vel. Morbi malesuada ligula sit amet mauris mollis sed vulputate tellus fringilla. Maecenas at velit sem. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum in arcu quis odio ullamcorper vulputate. Etiam tempor placerat lorem, id rhoncus erat vulputate sed. Pellentesque dapibus sollicitudin ipsum. Aliquam sollicitudin augue sit amet sapien tristique vel tristique nisl auctor. Aliquam porta, dui quis molestie vehicula, sem est luctus felis, id suscipit massa ipsum sed elit. Quisque vehicula nulla nec felis egestas id pellentesque risus condimentum. Nam varius purus quis erat egestas feugiat. Duis a odio eros, a vehicula sapien. Pellentesque ac dolor in velit aliquam gravida.</p>\n<p>Donec ut bibendum risus. Sed nisl turpis, pulvinar ut bibendum non, dignissim quis nibh. Cras interdum dictum dui, at venenatis magna auctor a. In a turpis risus, quis mollis augue. Mauris cursus, metus eu accumsan cursus, arcu sapien posuere elit, in viverra nisi diam non arcu. Maecenas ultricies commodo diam, sit amet mattis sapien accumsan ut. Vivamus a felis in enim porta congue. Cras dui tortor, adipiscing imperdiet tempus eu, adipiscing id tellus. Quisque id varius metus. Suspendisse ac euismod neque. Nullam orci dui, tincidunt nec mollis quis, aliquet nec risus. Pellentesque et neque felis, a ullamcorper lacus. Quisque mollis, odio sed fringilla rutrum, elit ipsum adipiscing turpis, sit amet mollis purus neque sed nibh. Donec vitae arcu lorem. Suspendisse id elit felis, non condimentum mauris. Nullam ullamcorper volutpat urna vel feugiat.</p>', NULL, NULL, 0, 1, 2, 0, 0, NULL, 'Inherit', 'Inherit', 1, 4, 'None', 0),
(34, 13, 1, 1, 1, 1, 'PortfolioItem', '2015-01-28 20:07:31', '2015-01-29 04:52:36', 'portfolio-item-4', 'Portfolio Item #4', NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus. Donec iaculis, est ut adipiscing cursus, lectus turpis tristique massa, faucibus faucibus urna odio nec ante. Integer magna purus, tincidunt ut vestibulum eget, mattis sit amet purus. Donec interdum orci nec felis pulvinar hendrerit. Donec suscipit turpis et libero fermentum non venenatis massa eleifend. Maecenas fringilla consectetur risus vel venenatis. Sed tincidunt tellus sit amet tellus mattis a malesuada dui vulputate. Aenean ut orci metus, vitae bibendum diam. Aliquam sit amet leo sed est convallis blandit vel sed libero. Integer leo nisi, viverra sit amet congue in, suscipit ac orci. Ut ut nulla at nulla posuere rutrum. Etiam cursus ultricies placerat. Praesent eu tellus nec enim pulvinar porta. Maecenas faucibus interdum turpis, sed rhoncus ante luctus vel. Duis ut orci nec metus lobortis commodo. Donec aliquet, leo non vestibulum dictum, ante justo molestie leo, id eleifend diam odio nec tellus. Cras consequat nunc a quam interdum luctus mollis velit viverra.</p>', NULL, NULL, 1, 1, 4, 0, 0, NULL, 'Inherit', 'Inherit', 0, 9, 'None', 0),
(35, 10, 8, 1, 1, 1, 'PortfolioItem', '2015-01-28 20:07:31', '2015-01-29 04:54:01', 'portfolio-item-1', 'Portfolio Item #1', NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus. Donec iaculis, est ut adipiscing cursus, lectus turpis tristique massa, faucibus faucibus urna odio nec ante. Integer magna purus, tincidunt ut vestibulum eget, mattis sit amet purus. Donec interdum orci nec felis pulvinar hendrerit. Donec suscipit turpis et libero fermentum non venenatis massa eleifend. Maecenas fringilla consectetur risus vel venenatis. Sed tincidunt tellus sit amet tellus mattis a malesuada dui vulputate. Aenean ut orci metus, vitae bibendum diam. Aliquam sit amet leo sed est convallis blandit vel sed libero. Integer leo nisi, viverra sit amet congue in, suscipit ac orci. Ut ut nulla at nulla posuere rutrum. Etiam cursus ultricies placerat. Praesent eu tellus nec enim pulvinar porta. Maecenas faucibus interdum turpis, sed rhoncus ante luctus vel. Duis ut orci nec metus lobortis commodo. Donec aliquet, leo non vestibulum dictum, ante justo molestie leo, id eleifend diam odio nec tellus. Cras consequat nunc a quam interdum luctus mollis velit viverra.</p>', NULL, NULL, 1, 1, 1, 0, 0, NULL, 'Inherit', 'Inherit', 0, 9, 'None', 0),
(178, 29, 4, 1, 1, 1, 'BlogPost', '2015-03-18 20:25:32', '2015-03-20 11:05:55', 'lorem-ipsum-dolor-sit-amet-consectetur-adipiscing-elit', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit', NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus. Donec iaculis, est ut adipiscing cursus, lectus turpis tristique massa, faucibus faucibus urna odio nec ante. Integer magna purus, tincidunt ut vestibulum eget, mattis sit amet purus. Donec interdum orci nec felis pulvinar hendrerit. Donec suscipit turpis et libero fermentum non venenatis massa eleifend. Maecenas fringilla consectetur risus vel venenatis. Sed tincidunt tellus sit amet tellus mattis a malesuada dui vulputate. Aenean ut orci metus, vitae bibendum diam. Aliquam sit amet leo sed est convallis blandit vel sed libero. Integer leo nisi, viverra sit amet congue in, suscipit ac orci. Ut ut nulla at nulla posuere rutrum. Etiam cursus ultricies placerat. Praesent eu tellus nec enim pulvinar porta. Maecenas faucibus interdum turpis, sed rhoncus ante luctus vel. Duis ut orci nec metus lobortis commodo. Donec aliquet, leo non vestibulum dictum, ante justo molestie leo, id eleifend diam odio nec tellus. Cras consequat nunc a quam interdum luctus mollis velit viverra.</p>\n<p>Nulla at leo eros, nec porttitor erat. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed venenatis facilisis dolor id pulvinar. Suspendisse tincidunt, arcu vestibulum venenatis blandit, arcu quam scelerisque nibh, nec imperdiet tellus tellus nec mauris. Suspendisse cursus varius velit, vel ultricies tortor fringilla pretium. Pellentesque posuere lobortis vehicula. Proin scelerisque dapibus eros, eget iaculis metus ultrices vel. Morbi malesuada ligula sit amet mauris mollis sed vulputate tellus fringilla. Maecenas at velit sem. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum in arcu quis odio ullamcorper vulputate. Etiam tempor placerat lorem, id rhoncus erat vulputate sed. Pellentesque dapibus sollicitudin ipsum. Aliquam sollicitudin augue sit amet sapien tristique vel tristique nisl auctor. Aliquam porta, dui quis molestie vehicula, sem est luctus felis, id suscipit massa ipsum sed elit. Quisque vehicula nulla nec felis egestas id pellentesque risus condimentum. Nam varius purus quis erat egestas feugiat. Duis a odio eros, a vehicula sapien. Pellentesque ac dolor in velit aliquam gravida.</p>\n<p>Donec ut bibendum risus. Sed nisl turpis, pulvinar ut bibendum non, dignissim quis nibh. Cras interdum dictum dui, at venenatis magna auctor a. In a turpis risus, quis mollis augue. Mauris cursus, metus eu accumsan cursus, arcu sapien posuere elit, in viverra nisi diam non arcu. Maecenas ultricies commodo diam, sit amet mattis sapien accumsan ut. Vivamus a felis in enim porta congue. Cras dui tortor, adipiscing imperdiet tempus eu, adipiscing id tellus. Quisque id varius metus. Suspendisse ac euismod neque. Nullam orci dui, tincidunt nec mollis quis, aliquet nec risus. Pellentesque et neque felis, a ullamcorper lacus. Quisque mollis, odio sed fringilla rutrum, elit ipsum adipiscing turpis, sit amet mollis purus neque sed nibh. Donec vitae arcu lorem. Suspendisse id elit felis, non condimentum mauris. Nullam ullamcorper volutpat urna vel feugiat.</p>', NULL, NULL, 0, 1, 2, 0, 0, NULL, 'Inherit', 'Inherit', 1, 4, 'None', 0),
(38, 14, 1, 1, 1, 1, 'PortfolioItem', '2015-01-28 20:07:31', '2015-01-29 04:56:54', 'portfolio-item-5', 'Portfolio Item #5', NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus. Donec iaculis, est ut adipiscing cursus, lectus turpis tristique massa, faucibus faucibus urna odio nec ante. Integer magna purus, tincidunt ut vestibulum eget, mattis sit amet purus. Donec interdum orci nec felis pulvinar hendrerit. Donec suscipit turpis et libero fermentum non venenatis massa eleifend. Maecenas fringilla consectetur risus vel venenatis. Sed tincidunt tellus sit amet tellus mattis a malesuada dui vulputate. Aenean ut orci metus, vitae bibendum diam. Aliquam sit amet leo sed est convallis blandit vel sed libero. Integer leo nisi, viverra sit amet congue in, suscipit ac orci. Ut ut nulla at nulla posuere rutrum. Etiam cursus ultricies placerat. Praesent eu tellus nec enim pulvinar porta. Maecenas faucibus interdum turpis, sed rhoncus ante luctus vel. Duis ut orci nec metus lobortis commodo. Donec aliquet, leo non vestibulum dictum, ante justo molestie leo, id eleifend diam odio nec tellus. Cras consequat nunc a quam interdum luctus mollis velit viverra.</p>', NULL, NULL, 1, 1, 5, 0, 0, NULL, 'Inherit', 'Inherit', 0, 9, 'None', 0);
INSERT INTO `SiteTree_versions` (`ID`, `RecordID`, `Version`, `WasPublished`, `AuthorID`, `PublisherID`, `ClassName`, `Created`, `LastEdited`, `URLSegment`, `Title`, `MenuTitle`, `Content`, `MetaDescription`, `ExtraMeta`, `ShowInMenus`, `ShowInSearch`, `Sort`, `HasBrokenFile`, `HasBrokenLink`, `ReportClass`, `CanViewType`, `CanEditType`, `ProvideComments`, `ParentID`, `ModerationRequired`, `CommentsRequireLogin`) VALUES
(39, 15, 1, 1, 1, 1, 'PortfolioItem', '2015-01-28 20:07:31', '2015-01-29 04:58:06', 'portfolio-item-6', 'Portfolio Item #6', NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus. Donec iaculis, est ut adipiscing cursus, lectus turpis tristique massa, faucibus faucibus urna odio nec ante. Integer magna purus, tincidunt ut vestibulum eget, mattis sit amet purus. Donec interdum orci nec felis pulvinar hendrerit. Donec suscipit turpis et libero fermentum non venenatis massa eleifend. Maecenas fringilla consectetur risus vel venenatis. Sed tincidunt tellus sit amet tellus mattis a malesuada dui vulputate. Aenean ut orci metus, vitae bibendum diam. Aliquam sit amet leo sed est convallis blandit vel sed libero. Integer leo nisi, viverra sit amet congue in, suscipit ac orci. Ut ut nulla at nulla posuere rutrum. Etiam cursus ultricies placerat. Praesent eu tellus nec enim pulvinar porta. Maecenas faucibus interdum turpis, sed rhoncus ante luctus vel. Duis ut orci nec metus lobortis commodo. Donec aliquet, leo non vestibulum dictum, ante justo molestie leo, id eleifend diam odio nec tellus. Cras consequat nunc a quam interdum luctus mollis velit viverra.</p>', NULL, NULL, 1, 1, 6, 0, 0, NULL, 'Inherit', 'Inherit', 0, 9, 'None', 0),
(40, 16, 1, 0, 1, 0, 'TimelinePage', '2015-02-08 18:05:28', '2015-02-08 18:05:28', 'new-timeline-page', 'New Timeline Page', NULL, NULL, NULL, NULL, 1, 1, 3, 0, 0, NULL, 'Inherit', 'Inherit', 0, 8, 'None', 0),
(41, 16, 2, 1, 1, 1, 'TimelinePage', '2015-02-08 18:05:28', '2015-02-08 18:05:48', 'timeline', 'Timeline', NULL, NULL, NULL, NULL, 1, 1, 3, 0, 0, NULL, 'Inherit', 'Inherit', 0, 8, 'None', 0),
(42, 17, 1, 0, 1, 0, 'TimelineItem', '2015-02-08 18:05:54', '2015-02-08 18:05:54', 'new-timeline-item', 'New Timeline Item', NULL, NULL, NULL, NULL, 1, 1, 1, 0, 0, NULL, 'Inherit', 'Inherit', 0, 16, 'None', 0),
(55, 17, 8, 1, 1, 1, 'TimelineItem', '2015-02-08 18:05:54', '2015-02-10 17:58:53', 'event-001', 'Event 001', NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus. Donec iaculis, est ut adipiscing cursus, lectus turpis tristique massa, faucibus faucibus urna odio nec ante. Integer magna purus, tincidunt ut vestibulum eget, mattis sit amet purus. Donec interdum orci nec felis pulvinar hendrerit. Donec suscipit turpis et libero fermentum non venenatis massa eleifend. Maecenas fringilla consectetur risus vel venenatis. Sed tincidunt tellus sit amet tellus mattis a malesuada dui vulputate. Aenean ut orci metus, vitae bibendum diam. Aliquam sit amet leo sed est convallis blandit vel sed libero. Integer leo nisi, viverra sit amet congue in, suscipit ac orci. Ut ut nulla at nulla posuere rutrum. Etiam cursus ultricies placerat. Praesent eu tellus nec enim pulvinar porta. Maecenas faucibus interdum turpis, sed rhoncus ante luctus vel. Duis ut orci nec metus lobortis commodo. Donec aliquet, leo non vestibulum dictum, ante justo molestie leo, id eleifend diam odio nec tellus. Cras consequat nunc a quam interdum luctus mollis velit viverra.</p>\n<p>Nulla at leo eros, nec porttitor erat. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed venenatis facilisis dolor id pulvinar. Suspendisse tincidunt, arcu vestibulum venenatis blandit, arcu quam scelerisque nibh, nec imperdiet tellus tellus nec mauris. Suspendisse cursus varius velit, vel ultricies tortor fringilla pretium. Pellentesque posuere lobortis vehicula. Proin scelerisque dapibus eros, eget iaculis metus ultrices vel. Morbi malesuada ligula sit amet mauris mollis sed vulputate tellus fringilla. Maecenas at velit sem. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum in arcu quis odio ullamcorper vulputate. Etiam tempor placerat lorem, id rhoncus erat vulputate sed. Pellentesque dapibus sollicitudin ipsum. Aliquam sollicitudin augue sit amet sapien tristique vel tristique nisl auctor. Aliquam porta, dui quis molestie vehicula, sem est luctus felis, id suscipit massa ipsum sed elit. Quisque vehicula nulla nec felis egestas id pellentesque risus condimentum. Nam varius purus quis erat egestas feugiat. Duis a odio eros, a vehicula sapien. Pellentesque ac dolor in velit aliquam gravida.</p>\n<p>Donec ut bibendum risus. Sed nisl turpis, pulvinar ut bibendum non, dignissim quis nibh. Cras interdum dictum dui, at venenatis magna auctor a. In a turpis risus, quis mollis augue. Mauris cursus, metus eu accumsan cursus, arcu sapien posuere elit, in viverra nisi diam non arcu. Maecenas ultricies commodo diam, sit amet mattis sapien accumsan ut. Vivamus a felis in enim porta congue. Cras dui tortor, adipiscing imperdiet tempus eu, adipiscing id tellus. Quisque id varius metus. Suspendisse ac euismod neque. Nullam orci dui, tincidunt nec mollis quis, aliquet nec risus. Pellentesque et neque felis, a ullamcorper lacus. Quisque mollis, odio sed fringilla rutrum, elit ipsum adipiscing turpis, sit amet mollis purus neque sed nibh. Donec vitae arcu lorem. Suspendisse id elit felis, non condimentum mauris. Nullam ullamcorper volutpat urna vel feugiat.</p>', NULL, NULL, 1, 1, 1, 0, 0, NULL, 'Inherit', 'Inherit', 0, 16, 'None', 0),
(56, 18, 2, 1, 1, 1, 'TimelineItem', '2015-02-08 18:05:54', '2015-02-10 18:00:11', 'event-2', 'Event 002', NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus. Donec iaculis, est ut adipiscing cursus, lectus turpis tristique massa, faucibus faucibus urna odio nec ante. Integer magna purus, tincidunt ut vestibulum eget, mattis sit amet purus. Donec interdum orci nec felis pulvinar hendrerit. Donec suscipit turpis et libero fermentum non venenatis massa eleifend. Maecenas fringilla consectetur risus vel venenatis. Sed tincidunt tellus sit amet tellus mattis a malesuada dui vulputate. Aenean ut orci metus, vitae bibendum diam. Aliquam sit amet leo sed est convallis blandit vel sed libero. Integer leo nisi, viverra sit amet congue in, suscipit ac orci. Ut ut nulla at nulla posuere rutrum. Etiam cursus ultricies placerat. Praesent eu tellus nec enim pulvinar porta. Maecenas faucibus interdum turpis, sed rhoncus ante luctus vel. Duis ut orci nec metus lobortis commodo. Donec aliquet, leo non vestibulum dictum, ante justo molestie leo, id eleifend diam odio nec tellus. Cras consequat nunc a quam interdum luctus mollis velit viverra.</p>\n<p>Nulla at leo eros, nec porttitor erat. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed venenatis facilisis dolor id pulvinar. Suspendisse tincidunt, arcu vestibulum venenatis blandit, arcu quam scelerisque nibh, nec imperdiet tellus tellus nec mauris. Suspendisse cursus varius velit, vel ultricies tortor fringilla pretium. Pellentesque posuere lobortis vehicula. Proin scelerisque dapibus eros, eget iaculis metus ultrices vel. Morbi malesuada ligula sit amet mauris mollis sed vulputate tellus fringilla. Maecenas at velit sem. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum in arcu quis odio ullamcorper vulputate. Etiam tempor placerat lorem, id rhoncus erat vulputate sed. Pellentesque dapibus sollicitudin ipsum. Aliquam sollicitudin augue sit amet sapien tristique vel tristique nisl auctor. Aliquam porta, dui quis molestie vehicula, sem est luctus felis, id suscipit massa ipsum sed elit. Quisque vehicula nulla nec felis egestas id pellentesque risus condimentum. Nam varius purus quis erat egestas feugiat. Duis a odio eros, a vehicula sapien. Pellentesque ac dolor in velit aliquam gravida.</p>\n<p>Donec ut bibendum risus. Sed nisl turpis, pulvinar ut bibendum non, dignissim quis nibh. Cras interdum dictum dui, at venenatis magna auctor a. In a turpis risus, quis mollis augue. Mauris cursus, metus eu accumsan cursus, arcu sapien posuere elit, in viverra nisi diam non arcu. Maecenas ultricies commodo diam, sit amet mattis sapien accumsan ut. Vivamus a felis in enim porta congue. Cras dui tortor, adipiscing imperdiet tempus eu, adipiscing id tellus. Quisque id varius metus. Suspendisse ac euismod neque. Nullam orci dui, tincidunt nec mollis quis, aliquet nec risus. Pellentesque et neque felis, a ullamcorper lacus. Quisque mollis, odio sed fringilla rutrum, elit ipsum adipiscing turpis, sit amet mollis purus neque sed nibh. Donec vitae arcu lorem. Suspendisse id elit felis, non condimentum mauris. Nullam ullamcorper volutpat urna vel feugiat.</p>', NULL, NULL, 1, 1, 2, 0, 0, NULL, 'Inherit', 'Inherit', 0, 16, 'None', 0),
(51, 19, 1, 1, 1, 1, 'TimelineItem', '2015-02-08 18:05:54', '2015-02-10 11:45:04', 'event-3', 'Event 003', NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus. Donec iaculis, est ut adipiscing cursus, lectus turpis tristique massa, faucibus faucibus urna odio nec ante. Integer magna purus, tincidunt ut vestibulum eget, mattis sit amet purus. Donec interdum orci nec felis pulvinar hendrerit. Donec suscipit turpis et libero fermentum non venenatis massa eleifend. Maecenas fringilla consectetur risus vel venenatis. Sed tincidunt tellus sit amet tellus mattis a malesuada dui vulputate. Aenean ut orci metus, vitae bibendum diam. Aliquam sit amet leo sed est convallis blandit vel sed libero. Integer leo nisi, viverra sit amet congue in, suscipit ac orci. Ut ut nulla at nulla posuere rutrum. Etiam cursus ultricies placerat. Praesent eu tellus nec enim pulvinar porta. Maecenas faucibus interdum turpis, sed rhoncus ante luctus vel. Duis ut orci nec metus lobortis commodo. Donec aliquet, leo non vestibulum dictum, ante justo molestie leo, id eleifend diam odio nec tellus. Cras consequat nunc a quam interdum luctus mollis velit viverra.</p>\n<p>Nulla at leo eros, nec porttitor erat. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed venenatis facilisis dolor id pulvinar. Suspendisse tincidunt, arcu vestibulum venenatis blandit, arcu quam scelerisque nibh, nec imperdiet tellus tellus nec mauris. Suspendisse cursus varius velit, vel ultricies tortor fringilla pretium. Pellentesque posuere lobortis vehicula. Proin scelerisque dapibus eros, eget iaculis metus ultrices vel. Morbi malesuada ligula sit amet mauris mollis sed vulputate tellus fringilla. Maecenas at velit sem. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum in arcu quis odio ullamcorper vulputate. Etiam tempor placerat lorem, id rhoncus erat vulputate sed. Pellentesque dapibus sollicitudin ipsum. Aliquam sollicitudin augue sit amet sapien tristique vel tristique nisl auctor. Aliquam porta, dui quis molestie vehicula, sem est luctus felis, id suscipit massa ipsum sed elit. Quisque vehicula nulla nec felis egestas id pellentesque risus condimentum. Nam varius purus quis erat egestas feugiat. Duis a odio eros, a vehicula sapien. Pellentesque ac dolor in velit aliquam gravida.</p>\n<p>Donec ut bibendum risus. Sed nisl turpis, pulvinar ut bibendum non, dignissim quis nibh. Cras interdum dictum dui, at venenatis magna auctor a. In a turpis risus, quis mollis augue. Mauris cursus, metus eu accumsan cursus, arcu sapien posuere elit, in viverra nisi diam non arcu. Maecenas ultricies commodo diam, sit amet mattis sapien accumsan ut. Vivamus a felis in enim porta congue. Cras dui tortor, adipiscing imperdiet tempus eu, adipiscing id tellus. Quisque id varius metus. Suspendisse ac euismod neque. Nullam orci dui, tincidunt nec mollis quis, aliquet nec risus. Pellentesque et neque felis, a ullamcorper lacus. Quisque mollis, odio sed fringilla rutrum, elit ipsum adipiscing turpis, sit amet mollis purus neque sed nibh. Donec vitae arcu lorem. Suspendisse id elit felis, non condimentum mauris. Nullam ullamcorper volutpat urna vel feugiat.</p>', NULL, NULL, 1, 1, 3, 0, 0, NULL, 'Inherit', 'Inherit', 0, 16, 'None', 0),
(60, 17, 10, 1, 1, 1, 'TimelineItem', '2015-02-08 18:05:54', '2015-02-10 18:39:03', 'event-001', 'Event 001', NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus. Donec iaculis, est ut adipiscing cursus, lectus turpis tristique massa, faucibus faucibus urna odio nec ante. Integer magna purus, tincidunt ut vestibulum eget, mattis sit amet purus. Donec interdum orci nec felis pulvinar hendrerit. Donec suscipit turpis et libero fermentum non venenatis massa eleifend. Maecenas fringilla consectetur risus vel venenatis. Sed tincidunt tellus sit amet tellus mattis a malesuada dui vulputate. Aenean ut orci metus, vitae bibendum diam. Aliquam sit amet leo sed est convallis blandit vel sed libero. Integer leo nisi, viverra sit amet congue in, suscipit ac orci. Ut ut nulla at nulla posuere rutrum. Etiam cursus ultricies placerat. Praesent eu tellus nec enim pulvinar porta. Maecenas faucibus interdum turpis, sed rhoncus ante luctus vel. Duis ut orci nec metus lobortis commodo. Donec aliquet, leo non vestibulum dictum, ante justo molestie leo, id eleifend diam odio nec tellus. Cras consequat nunc a quam interdum luctus mollis velit viverra.</p>\n<p>Nulla at leo eros, nec porttitor erat. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed venenatis facilisis dolor id pulvinar. Suspendisse tincidunt, arcu vestibulum venenatis blandit, arcu quam scelerisque nibh, nec imperdiet tellus tellus nec mauris. Suspendisse cursus varius velit, vel ultricies tortor fringilla pretium. Pellentesque posuere lobortis vehicula. Proin scelerisque dapibus eros, eget iaculis metus ultrices vel. Morbi malesuada ligula sit amet mauris mollis sed vulputate tellus fringilla. Maecenas at velit sem. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum in arcu quis odio ullamcorper vulputate. Etiam tempor placerat lorem, id rhoncus erat vulputate sed. Pellentesque dapibus sollicitudin ipsum. Aliquam sollicitudin augue sit amet sapien tristique vel tristique nisl auctor. Aliquam porta, dui quis molestie vehicula, sem est luctus felis, id suscipit massa ipsum sed elit. Quisque vehicula nulla nec felis egestas id pellentesque risus condimentum. Nam varius purus quis erat egestas feugiat. Duis a odio eros, a vehicula sapien. Pellentesque ac dolor in velit aliquam gravida.</p>\n<p>Donec ut bibendum risus. Sed nisl turpis, pulvinar ut bibendum non, dignissim quis nibh. Cras interdum dictum dui, at venenatis magna auctor a. In a turpis risus, quis mollis augue. Mauris cursus, metus eu accumsan cursus, arcu sapien posuere elit, in viverra nisi diam non arcu. Maecenas ultricies commodo diam, sit amet mattis sapien accumsan ut. Vivamus a felis in enim porta congue. Cras dui tortor, adipiscing imperdiet tempus eu, adipiscing id tellus. Quisque id varius metus. Suspendisse ac euismod neque. Nullam orci dui, tincidunt nec mollis quis, aliquet nec risus. Pellentesque et neque felis, a ullamcorper lacus. Quisque mollis, odio sed fringilla rutrum, elit ipsum adipiscing turpis, sit amet mollis purus neque sed nibh. Donec vitae arcu lorem. Suspendisse id elit felis, non condimentum mauris. Nullam ullamcorper volutpat urna vel feugiat.</p>', NULL, NULL, 1, 1, 1, 0, 0, NULL, 'Inherit', 'Inherit', 0, 16, 'None', 0),
(61, 2, 5, 1, 1, 1, 'Page', '2015-01-26 04:46:26', '2015-03-02 03:51:35', 'about-us', 'About SimLine', NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus. Donec iaculis, est ut adipiscing cursus, lectus turpis tristique massa, faucibus faucibus urna odio nec ante. Integer magna purus, tincidunt ut vestibulum eget, mattis sit amet purus. Donec interdum orci nec felis pulvinar hendrerit. Donec suscipit turpis et libero fermentum non venenatis massa eleifend. Maecenas fringilla consectetur risus vel venenatis. Sed tincidunt tellus sit amet tellus mattis a malesuada dui vulputate. Aenean ut orci metus, vitae bibendum diam. Aliquam sit amet leo sed est convallis blandit vel sed libero. Integer leo nisi, viverra sit amet congue in, suscipit ac orci. Ut ut nulla at nulla posuere rutrum. Etiam cursus ultricies placerat. Praesent eu tellus nec enim pulvinar porta. Maecenas faucibus interdum turpis, sed rhoncus ante luctus vel. Duis ut orci nec metus lobortis commodo. Donec aliquet, leo non vestibulum dictum, ante justo molestie leo, id eleifend diam odio nec tellus. Cras consequat nunc a quam interdum luctus mollis velit viverra.</p>\n<p>Nulla at leo eros, nec porttitor erat. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed venenatis facilisis dolor id pulvinar. Suspendisse tincidunt, arcu vestibulum venenatis blandit, arcu quam scelerisque nibh, nec imperdiet tellus tellus nec mauris. Suspendisse cursus varius velit, vel ultricies tortor fringilla pretium. Pellentesque posuere lobortis vehicula. Proin scelerisque dapibus eros, eget iaculis metus ultrices vel. Morbi malesuada ligula sit amet mauris mollis sed vulputate tellus fringilla. Maecenas at velit sem. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum in arcu quis odio ullamcorper vulputate. Etiam tempor placerat lorem, id rhoncus erat vulputate sed. Pellentesque dapibus sollicitudin ipsum. Aliquam sollicitudin augue sit amet sapien tristique vel tristique nisl auctor. Aliquam porta, dui quis molestie vehicula, sem est luctus felis, id suscipit massa ipsum sed elit. Quisque vehicula nulla nec felis egestas id pellentesque risus condimentum. Nam varius purus quis erat egestas feugiat. Duis a odio eros, a vehicula sapien. Pellentesque ac dolor in velit aliquam gravida.</p>\n<p>Donec ut bibendum risus. Sed nisl turpis, pulvinar ut bibendum non, dignissim quis nibh. Cras interdum dictum dui, at venenatis magna auctor a. In a turpis risus, quis mollis augue. Mauris cursus, metus eu accumsan cursus, arcu sapien posuere elit, in viverra nisi diam non arcu. Maecenas ultricies commodo diam, sit amet mattis sapien accumsan ut. Vivamus a felis in enim porta congue. Cras dui tortor, adipiscing imperdiet tempus eu, adipiscing id tellus. Quisque id varius metus. Suspendisse ac euismod neque. Nullam orci dui, tincidunt nec mollis quis, aliquet nec risus. Pellentesque et neque felis, a ullamcorper lacus. Quisque mollis, odio sed fringilla rutrum, elit ipsum adipiscing turpis, sit amet mollis purus neque sed nibh. Donec vitae arcu lorem. Suspendisse id elit felis, non condimentum mauris. Nullam ullamcorper volutpat urna vel feugiat.</p>', NULL, NULL, 1, 1, 2, 0, 0, NULL, 'Inherit', 'Inherit', 0, 8, 'None', 0),
(57, 19, 2, 1, 1, 1, 'TimelineItem', '2015-02-08 18:05:54', '2015-02-10 18:36:05', 'event-3', 'Event 003', NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus. Donec iaculis, est ut adipiscing cursus, lectus turpis tristique massa, faucibus faucibus urna odio nec ante. Integer magna purus, tincidunt ut vestibulum eget, mattis sit amet purus. Donec interdum orci nec felis pulvinar hendrerit. Donec suscipit turpis et libero fermentum non venenatis massa eleifend. Maecenas fringilla consectetur risus vel venenatis. Sed tincidunt tellus sit amet tellus mattis a malesuada dui vulputate. Aenean ut orci metus, vitae bibendum diam. Aliquam sit amet leo sed est convallis blandit vel sed libero. Integer leo nisi, viverra sit amet congue in, suscipit ac orci. Ut ut nulla at nulla posuere rutrum. Etiam cursus ultricies placerat. Praesent eu tellus nec enim pulvinar porta. Maecenas faucibus interdum turpis, sed rhoncus ante luctus vel. Duis ut orci nec metus lobortis commodo. Donec aliquet, leo non vestibulum dictum, ante justo molestie leo, id eleifend diam odio nec tellus. Cras consequat nunc a quam interdum luctus mollis velit viverra.</p>\n<p>Nulla at leo eros, nec porttitor erat. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed venenatis facilisis dolor id pulvinar. Suspendisse tincidunt, arcu vestibulum venenatis blandit, arcu quam scelerisque nibh, nec imperdiet tellus tellus nec mauris. Suspendisse cursus varius velit, vel ultricies tortor fringilla pretium. Pellentesque posuere lobortis vehicula. Proin scelerisque dapibus eros, eget iaculis metus ultrices vel. Morbi malesuada ligula sit amet mauris mollis sed vulputate tellus fringilla. Maecenas at velit sem. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum in arcu quis odio ullamcorper vulputate. Etiam tempor placerat lorem, id rhoncus erat vulputate sed. Pellentesque dapibus sollicitudin ipsum. Aliquam sollicitudin augue sit amet sapien tristique vel tristique nisl auctor. Aliquam porta, dui quis molestie vehicula, sem est luctus felis, id suscipit massa ipsum sed elit. Quisque vehicula nulla nec felis egestas id pellentesque risus condimentum. Nam varius purus quis erat egestas feugiat. Duis a odio eros, a vehicula sapien. Pellentesque ac dolor in velit aliquam gravida.</p>\n<p>Donec ut bibendum risus. Sed nisl turpis, pulvinar ut bibendum non, dignissim quis nibh. Cras interdum dictum dui, at venenatis magna auctor a. In a turpis risus, quis mollis augue. Mauris cursus, metus eu accumsan cursus, arcu sapien posuere elit, in viverra nisi diam non arcu. Maecenas ultricies commodo diam, sit amet mattis sapien accumsan ut. Vivamus a felis in enim porta congue. Cras dui tortor, adipiscing imperdiet tempus eu, adipiscing id tellus. Quisque id varius metus. Suspendisse ac euismod neque. Nullam orci dui, tincidunt nec mollis quis, aliquet nec risus. Pellentesque et neque felis, a ullamcorper lacus. Quisque mollis, odio sed fringilla rutrum, elit ipsum adipiscing turpis, sit amet mollis purus neque sed nibh. Donec vitae arcu lorem. Suspendisse id elit felis, non condimentum mauris. Nullam ullamcorper volutpat urna vel feugiat.</p>', NULL, NULL, 1, 1, 3, 0, 0, NULL, 'Inherit', 'Inherit', 0, 16, 'None', 0),
(58, 18, 3, 1, 1, 1, 'TimelineItem', '2015-02-08 18:05:54', '2015-02-10 18:37:41', 'event-2', 'Event 002', NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus. Donec iaculis, est ut adipiscing cursus, lectus turpis tristique massa, faucibus faucibus urna odio nec ante. Integer magna purus, tincidunt ut vestibulum eget, mattis sit amet purus. Donec interdum orci nec felis pulvinar hendrerit. Donec suscipit turpis et libero fermentum non venenatis massa eleifend. Maecenas fringilla consectetur risus vel venenatis. Sed tincidunt tellus sit amet tellus mattis a malesuada dui vulputate. Aenean ut orci metus, vitae bibendum diam. Aliquam sit amet leo sed est convallis blandit vel sed libero. Integer leo nisi, viverra sit amet congue in, suscipit ac orci. Ut ut nulla at nulla posuere rutrum. Etiam cursus ultricies placerat. Praesent eu tellus nec enim pulvinar porta. Maecenas faucibus interdum turpis, sed rhoncus ante luctus vel. Duis ut orci nec metus lobortis commodo. Donec aliquet, leo non vestibulum dictum, ante justo molestie leo, id eleifend diam odio nec tellus. Cras consequat nunc a quam interdum luctus mollis velit viverra.</p>\n<p>Nulla at leo eros, nec porttitor erat. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed venenatis facilisis dolor id pulvinar. Suspendisse tincidunt, arcu vestibulum venenatis blandit, arcu quam scelerisque nibh, nec imperdiet tellus tellus nec mauris. Suspendisse cursus varius velit, vel ultricies tortor fringilla pretium. Pellentesque posuere lobortis vehicula. Proin scelerisque dapibus eros, eget iaculis metus ultrices vel. Morbi malesuada ligula sit amet mauris mollis sed vulputate tellus fringilla. Maecenas at velit sem. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum in arcu quis odio ullamcorper vulputate. Etiam tempor placerat lorem, id rhoncus erat vulputate sed. Pellentesque dapibus sollicitudin ipsum. Aliquam sollicitudin augue sit amet sapien tristique vel tristique nisl auctor. Aliquam porta, dui quis molestie vehicula, sem est luctus felis, id suscipit massa ipsum sed elit. Quisque vehicula nulla nec felis egestas id pellentesque risus condimentum. Nam varius purus quis erat egestas feugiat. Duis a odio eros, a vehicula sapien. Pellentesque ac dolor in velit aliquam gravida.</p>\n<p>Donec ut bibendum risus. Sed nisl turpis, pulvinar ut bibendum non, dignissim quis nibh. Cras interdum dictum dui, at venenatis magna auctor a. In a turpis risus, quis mollis augue. Mauris cursus, metus eu accumsan cursus, arcu sapien posuere elit, in viverra nisi diam non arcu. Maecenas ultricies commodo diam, sit amet mattis sapien accumsan ut. Vivamus a felis in enim porta congue. Cras dui tortor, adipiscing imperdiet tempus eu, adipiscing id tellus. Quisque id varius metus. Suspendisse ac euismod neque. Nullam orci dui, tincidunt nec mollis quis, aliquet nec risus. Pellentesque et neque felis, a ullamcorper lacus. Quisque mollis, odio sed fringilla rutrum, elit ipsum adipiscing turpis, sit amet mollis purus neque sed nibh. Donec vitae arcu lorem. Suspendisse id elit felis, non condimentum mauris. Nullam ullamcorper volutpat urna vel feugiat.</p>', NULL, NULL, 1, 1, 2, 0, 0, NULL, 'Inherit', 'Inherit', 0, 16, 'None', 0),
(59, 17, 9, 1, 1, 1, 'TimelineItem', '2015-02-08 18:05:54', '2015-02-10 18:38:43', 'event-001', 'Event 001', NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus. Donec iaculis, est ut adipiscing cursus, lectus turpis tristique massa, faucibus faucibus urna odio nec ante. Integer magna purus, tincidunt ut vestibulum eget, mattis sit amet purus. Donec interdum orci nec felis pulvinar hendrerit. Donec suscipit turpis et libero fermentum non venenatis massa eleifend. Maecenas fringilla consectetur risus vel venenatis. Sed tincidunt tellus sit amet tellus mattis a malesuada dui vulputate. Aenean ut orci metus, vitae bibendum diam. Aliquam sit amet leo sed est convallis blandit vel sed libero. Integer leo nisi, viverra sit amet congue in, suscipit ac orci. Ut ut nulla at nulla posuere rutrum. Etiam cursus ultricies placerat. Praesent eu tellus nec enim pulvinar porta. Maecenas faucibus interdum turpis, sed rhoncus ante luctus vel. Duis ut orci nec metus lobortis commodo. Donec aliquet, leo non vestibulum dictum, ante justo molestie leo, id eleifend diam odio nec tellus. Cras consequat nunc a quam interdum luctus mollis velit viverra.</p>\n<p>Nulla at leo eros, nec porttitor erat. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed venenatis facilisis dolor id pulvinar. Suspendisse tincidunt, arcu vestibulum venenatis blandit, arcu quam scelerisque nibh, nec imperdiet tellus tellus nec mauris. Suspendisse cursus varius velit, vel ultricies tortor fringilla pretium. Pellentesque posuere lobortis vehicula. Proin scelerisque dapibus eros, eget iaculis metus ultrices vel. Morbi malesuada ligula sit amet mauris mollis sed vulputate tellus fringilla. Maecenas at velit sem. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum in arcu quis odio ullamcorper vulputate. Etiam tempor placerat lorem, id rhoncus erat vulputate sed. Pellentesque dapibus sollicitudin ipsum. Aliquam sollicitudin augue sit amet sapien tristique vel tristique nisl auctor. Aliquam porta, dui quis molestie vehicula, sem est luctus felis, id suscipit massa ipsum sed elit. Quisque vehicula nulla nec felis egestas id pellentesque risus condimentum. Nam varius purus quis erat egestas feugiat. Duis a odio eros, a vehicula sapien. Pellentesque ac dolor in velit aliquam gravida.</p>\n<p>Donec ut bibendum risus. Sed nisl turpis, pulvinar ut bibendum non, dignissim quis nibh. Cras interdum dictum dui, at venenatis magna auctor a. In a turpis risus, quis mollis augue. Mauris cursus, metus eu accumsan cursus, arcu sapien posuere elit, in viverra nisi diam non arcu. Maecenas ultricies commodo diam, sit amet mattis sapien accumsan ut. Vivamus a felis in enim porta congue. Cras dui tortor, adipiscing imperdiet tempus eu, adipiscing id tellus. Quisque id varius metus. Suspendisse ac euismod neque. Nullam orci dui, tincidunt nec mollis quis, aliquet nec risus. Pellentesque et neque felis, a ullamcorper lacus. Quisque mollis, odio sed fringilla rutrum, elit ipsum adipiscing turpis, sit amet mollis purus neque sed nibh. Donec vitae arcu lorem. Suspendisse id elit felis, non condimentum mauris. Nullam ullamcorper volutpat urna vel feugiat.</p>', NULL, NULL, 1, 1, 1, 0, 0, NULL, 'Inherit', 'Inherit', 0, 16, 'None', 0),
(62, 2, 6, 1, 1, 1, 'Page', '2015-01-26 04:46:26', '2015-03-02 03:52:12', 'about-us', 'About Us', NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus. Donec iaculis, est ut adipiscing cursus, lectus turpis tristique massa, faucibus faucibus urna odio nec ante. Integer magna purus, tincidunt ut vestibulum eget, mattis sit amet purus. Donec interdum orci nec felis pulvinar hendrerit. Donec suscipit turpis et libero fermentum non venenatis massa eleifend. Maecenas fringilla consectetur risus vel venenatis. Sed tincidunt tellus sit amet tellus mattis a malesuada dui vulputate. Aenean ut orci metus, vitae bibendum diam. Aliquam sit amet leo sed est convallis blandit vel sed libero. Integer leo nisi, viverra sit amet congue in, suscipit ac orci. Ut ut nulla at nulla posuere rutrum. Etiam cursus ultricies placerat. Praesent eu tellus nec enim pulvinar porta. Maecenas faucibus interdum turpis, sed rhoncus ante luctus vel. Duis ut orci nec metus lobortis commodo. Donec aliquet, leo non vestibulum dictum, ante justo molestie leo, id eleifend diam odio nec tellus. Cras consequat nunc a quam interdum luctus mollis velit viverra.</p>\n<p>Nulla at leo eros, nec porttitor erat. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed venenatis facilisis dolor id pulvinar. Suspendisse tincidunt, arcu vestibulum venenatis blandit, arcu quam scelerisque nibh, nec imperdiet tellus tellus nec mauris. Suspendisse cursus varius velit, vel ultricies tortor fringilla pretium. Pellentesque posuere lobortis vehicula. Proin scelerisque dapibus eros, eget iaculis metus ultrices vel. Morbi malesuada ligula sit amet mauris mollis sed vulputate tellus fringilla. Maecenas at velit sem. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum in arcu quis odio ullamcorper vulputate. Etiam tempor placerat lorem, id rhoncus erat vulputate sed. Pellentesque dapibus sollicitudin ipsum. Aliquam sollicitudin augue sit amet sapien tristique vel tristique nisl auctor. Aliquam porta, dui quis molestie vehicula, sem est luctus felis, id suscipit massa ipsum sed elit. Quisque vehicula nulla nec felis egestas id pellentesque risus condimentum. Nam varius purus quis erat egestas feugiat. Duis a odio eros, a vehicula sapien. Pellentesque ac dolor in velit aliquam gravida.</p>\n<p>Donec ut bibendum risus. Sed nisl turpis, pulvinar ut bibendum non, dignissim quis nibh. Cras interdum dictum dui, at venenatis magna auctor a. In a turpis risus, quis mollis augue. Mauris cursus, metus eu accumsan cursus, arcu sapien posuere elit, in viverra nisi diam non arcu. Maecenas ultricies commodo diam, sit amet mattis sapien accumsan ut. Vivamus a felis in enim porta congue. Cras dui tortor, adipiscing imperdiet tempus eu, adipiscing id tellus. Quisque id varius metus. Suspendisse ac euismod neque. Nullam orci dui, tincidunt nec mollis quis, aliquet nec risus. Pellentesque et neque felis, a ullamcorper lacus. Quisque mollis, odio sed fringilla rutrum, elit ipsum adipiscing turpis, sit amet mollis purus neque sed nibh. Donec vitae arcu lorem. Suspendisse id elit felis, non condimentum mauris. Nullam ullamcorper volutpat urna vel feugiat.</p>', NULL, NULL, 1, 1, 2, 0, 0, NULL, 'Inherit', 'Inherit', 0, 8, 'None', 0),
(123, 20, 9, 1, 1, 1, 'Page', '2015-03-12 21:25:41', '2015-03-12 21:40:59', 'services', 'Services', NULL, '<table class="fluid-table col-md-12"><tbody><tr valign="top"><td class="col-md-7">\n<h4>Company Introduction</h4>\n<p>Sed at porta tellus. Sed sit amet ipsum non dolor tincidunt vestibulum eget et urna. In et placerat eros. Curabitur tristique lacinia tortor ut ornare. Proin vehicula rhoncus fermentum. Integer scelerisque aliquam turpis. Quisque pellentesque, sem vel molestie posuere, orci sapien interdum mauris, eget condimentum purus arcu ut augue.</p>\n<hr><p> </p>\n<p>[button,link="contact-us/",classes="btn btn-lg btn-red",location="left"]Contact us[/button]</p>\n</td>\n<td class="col-md-5">\n<h4>Video guide</h4>\n<p>[video,id="67449472",service="vimeo",width="480",height="320",location="left"]</p>\n</td>\n</tr></tbody></table>', NULL, NULL, 1, 1, 4, 0, 0, NULL, 'Inherit', 'Inherit', 0, 8, 'None', 0),
(124, 20, 10, 1, 1, 1, 'Page', '2015-03-12 21:25:41', '2015-03-12 21:41:49', 'services', 'Services', NULL, '<table class="fluid-table col-md-12"><tbody><tr valign="top"><td class="col-md-7">\n<h4>Company Introduction</h4>\n<p>Sed at porta tellus. Sed sit amet ipsum non dolor tincidunt vestibulum eget et urna. In et placerat eros. Curabitur tristique lacinia tortor ut ornare. Proin vehicula rhoncus fermentum. Integer scelerisque aliquam turpis. Quisque pellentesque, sem vel molestie posuere, orci sapien interdum mauris, eget condimentum purus arcu ut augue.</p>\n<hr><p>[button,link="contact-us/",classes="btn btn-lg btn-red",location="left"]Contact us[/button]</p>\n</td>\n<td class="col-md-5">\n<h4>Video guide</h4>\n<p>[video,id="67449472",service="vimeo",width="480",height="320",location="left"]</p>\n</td>\n</tr></tbody></table>', NULL, NULL, 1, 1, 4, 0, 0, NULL, 'Inherit', 'Inherit', 0, 8, 'None', 0),
(125, 20, 11, 1, 1, 1, 'Page', '2015-03-12 21:25:41', '2015-03-12 21:43:46', 'services', 'Services', NULL, '<table class="fluid-table col-md-12"><tbody><tr valign="top"><td class="col-md-7">\n<h4>Company Introduction</h4>\n<p>Sed at porta tellus. Sed sit amet ipsum non dolor tincidunt vestibulum eget et urna. In et placerat eros. Curabitur tristique lacinia tortor ut ornare. Proin vehicula rhoncus fermentum. Integer scelerisque aliquam turpis. Quisque pellentesque, sem vel molestie posuere, orci sapien interdum mauris, eget condimentum purus arcu ut augue.</p>\n<hr><p>[button,link="contact-us/",classes="btn btn-lg btn-red",location="left"]Contact us[/button]</p>\n</td>\n<td class="col-md-5">\n<h4>Video guide</h4>\n<p>[video,id="67449472",service="vimeo",width="480",height="320",location="left"]</p>\n</td>\n</tr></tbody></table>', NULL, NULL, 1, 1, 4, 0, 0, NULL, 'Inherit', 'Inherit', 0, 8, 'None', 0),
(113, 2, 37, 1, 1, 1, 'AboutPage', '2015-01-26 04:46:26', '2015-03-12 20:33:33', 'about-us', 'About Us', NULL, '<p class="lead" style="text-align: center;"><span style="color: #ec7263;">Oneline is a modern fully responsive HTML5 template perfect for your web &amp; mobile apps.</span></p>\n<p class="text-center">Sed at porta tellus. Sed sit amet ipsum non dolor tincidunt vestibulum eget et urna. In et placerat eros. Curabitur tristique lacinia tortor ut ornare. Proin vehicula rhoncus fermentum. Integer scelerisque aliquam turpis. Quisque pellentesque, sem vel molestie posuere, orci sapien interdum mauris, eget condimentum purus arcu ut augue.</p>\n<p class="text-center"> </p>\n<table class="fluid-table col-md-12"><tbody><tr valign="top"><td class="col-md-6">\n<p>[video,id="67449472",service="vimeo",width="480",height="320",location="left"]</p>\n</td>\n<td class="col-md-6">\n<div class="well">This video is fully responsive. It will automatically adjust its size according to the parent block width.</div>\n<ul class="ft-list"><li>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>\n<li>Donec vulputate tellus quis volutpat congue.</li>\n<li>Sed ultrices eros eu euismod semper.</li>\n<li>Integer vulputate mauris in eleifend laoreet.</li>\n<li>Donec vulputate tellus quis volutpat congue.</li>\n<li>Sed ultrices eros eu euismod semper.</li>\n</ul></td>\n</tr></tbody></table><p>ss</p>\n<table class="fluid-table col-md-12"><tbody><tr><td class="col-md-col-md-12">Content goes here.</td>\n</tr></tbody></table><p> </p>\n<table class="fluid-table col-md-12"><tbody><tr><td class="col-md-col-md-3">Content goes here.</td>\n<td class="col-md-col-md-3">Content goes here.</td>\n<td class="col-md-col-md-3">Content goes here.</td>\n<td class="col-md-col-md-3">Content goes here.</td>\n</tr><tr><td class="col-md-col-md-3">Content goes here.</td>\n<td class="col-md-col-md-3">Content goes here.</td>\n<td class="col-md-col-md-3">Content goes here.</td>\n<td class="col-md-col-md-3">Content goes here.</td>\n</tr><tr><td class="col-md-col-md-3">Content goes here.</td>\n<td class="col-md-col-md-3">Content goes here.</td>\n<td class="col-md-col-md-3">Content goes here.</td>\n<td class="col-md-col-md-3">Content goes here.</td>\n</tr><tr><td class="col-md-col-md-3">Content goes here.</td>\n<td class="col-md-col-md-3">Content goes here.</td>\n<td class="col-md-col-md-3">Content goes here.</td>\n<td class="col-md-col-md-3">Content goes here.</td>\n</tr><tr><td class="col-md-col-md-3">Content goes here.</td>\n<td class="col-md-col-md-3">Content goes here.</td>\n<td class="col-md-col-md-3">Content goes here.</td>\n<td class="col-md-col-md-3">Content goes here.</td>\n</tr><tr><td class="col-md-col-md-3">Content goes here.</td>\n<td class="col-md-col-md-3">Content goes here.</td>\n<td class="col-md-col-md-3">Content goes here.</td>\n<td class="col-md-col-md-3">Content goes here.</td>\n</tr></tbody></table>', NULL, NULL, 1, 1, 1, 0, 0, NULL, 'Inherit', 'Inherit', 0, 8, 'None', 0),
(65, 2, 9, 0, 1, 0, 'AboutPage', '2015-01-26 04:46:26', '2015-03-02 04:54:17', 'about-us', 'About Us', NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus. Donec iaculis, est ut adipiscing cursus, lectus turpis tristique massa, faucibus faucibus urna odio nec ante. Integer magna purus, tincidunt ut vestibulum eget, mattis sit amet purus. Donec interdum orci nec felis pulvinar hendrerit. Donec suscipit turpis et libero fermentum non venenatis massa eleifend. Maecenas fringilla consectetur risus vel venenatis. Sed tincidunt tellus sit amet tellus mattis a malesuada dui vulputate. Aenean ut orci metus, vitae bibendum diam. Aliquam sit amet leo sed est convallis blandit vel sed libero. Integer leo nisi, viverra sit amet congue in, suscipit ac orci. Ut ut nulla at nulla posuere rutrum. Etiam cursus ultricies placerat. Praesent eu tellus nec enim pulvinar porta. Maecenas faucibus interdum turpis, sed rhoncus ante luctus vel. Duis ut orci nec metus lobortis commodo. Donec aliquet, leo non vestibulum dictum, ante justo molestie leo, id eleifend diam odio nec tellus. Cras consequat nunc a quam interdum luctus mollis velit viverra.</p>\n<p>Nulla at leo eros, nec porttitor erat. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed venenatis facilisis dolor id pulvinar. Suspendisse tincidunt, arcu vestibulum venenatis blandit, arcu quam scelerisque nibh, nec imperdiet tellus tellus nec mauris. Suspendisse cursus varius velit, vel ultricies tortor fringilla pretium. Pellentesque posuere lobortis vehicula. Proin scelerisque dapibus eros, eget iaculis metus ultrices vel. Morbi malesuada ligula sit amet mauris mollis sed vulputate tellus fringilla. Maecenas at velit sem. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum in arcu quis odio ullamcorper vulputate. Etiam tempor placerat lorem, id rhoncus erat vulputate sed. Pellentesque dapibus sollicitudin ipsum. Aliquam sollicitudin augue sit amet sapien tristique vel tristique nisl auctor. Aliquam porta, dui quis molestie vehicula, sem est luctus felis, id suscipit massa ipsum sed elit. Quisque vehicula nulla nec felis egestas id pellentesque risus condimentum. Nam varius purus quis erat egestas feugiat. Duis a odio eros, a vehicula sapien. Pellentesque ac dolor in velit aliquam gravida.</p>\n<p>Donec ut bibendum risus. Sed nisl turpis, pulvinar ut bibendum non, dignissim quis nibh. Cras interdum dictum dui, at venenatis magna auctor a. In a turpis risus, quis mollis augue. Mauris cursus, metus eu accumsan cursus, arcu sapien posuere elit, in viverra nisi diam non arcu. Maecenas ultricies commodo diam, sit amet mattis sapien accumsan ut. Vivamus a felis in enim porta congue. Cras dui tortor, adipiscing imperdiet tempus eu, adipiscing id tellus. Quisque id varius metus. Suspendisse ac euismod neque. Nullam orci dui, tincidunt nec mollis quis, aliquet nec risus. Pellentesque et neque felis, a ullamcorper lacus. Quisque mollis, odio sed fringilla rutrum, elit ipsum adipiscing turpis, sit amet mollis purus neque sed nibh. Donec vitae arcu lorem. Suspendisse id elit felis, non condimentum mauris. Nullam ullamcorper volutpat urna vel feugiat.</p>', NULL, NULL, 1, 1, 2, 0, 0, NULL, 'Inherit', 'Inherit', 0, 8, 'None', 0),
(66, 2, 10, 0, 1, 0, 'AboutPage', '2015-01-26 04:46:26', '2015-03-02 05:00:21', 'about-us', 'About Us', NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus. Donec iaculis, est ut adipiscing cursus, lectus turpis tristique massa, faucibus faucibus urna odio nec ante. Integer magna purus, tincidunt ut vestibulum eget, mattis sit amet purus. Donec interdum orci nec felis pulvinar hendrerit. Donec suscipit turpis et libero fermentum non venenatis massa eleifend. Maecenas fringilla consectetur risus vel venenatis. Sed tincidunt tellus sit amet tellus mattis a malesuada dui vulputate. Aenean ut orci metus, vitae bibendum diam. Aliquam sit amet leo sed est convallis blandit vel sed libero. Integer leo nisi, viverra sit amet congue in, suscipit ac orci. Ut ut nulla at nulla posuere rutrum. Etiam cursus ultricies placerat. Praesent eu tellus nec enim pulvinar porta. Maecenas faucibus interdum turpis, sed rhoncus ante luctus vel. Duis ut orci nec metus lobortis commodo. Donec aliquet, leo non vestibulum dictum, ante justo molestie leo, id eleifend diam odio nec tellus. Cras consequat nunc a quam interdum luctus mollis velit viverra.</p>\n<p>Nulla at leo eros, nec porttitor erat. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed venenatis facilisis dolor id pulvinar. Suspendisse tincidunt, arcu vestibulum venenatis blandit, arcu quam scelerisque nibh, nec imperdiet tellus tellus nec mauris. Suspendisse cursus varius velit, vel ultricies tortor fringilla pretium. Pellentesque posuere lobortis vehicula. Proin scelerisque dapibus eros, eget iaculis metus ultrices vel. Morbi malesuada ligula sit amet mauris mollis sed vulputate tellus fringilla. Maecenas at velit sem. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum in arcu quis odio ullamcorper vulputate. Etiam tempor placerat lorem, id rhoncus erat vulputate sed. Pellentesque dapibus sollicitudin ipsum. Aliquam sollicitudin augue sit amet sapien tristique vel tristique nisl auctor. Aliquam porta, dui quis molestie vehicula, sem est luctus felis, id suscipit massa ipsum sed elit. Quisque vehicula nulla nec felis egestas id pellentesque risus condimentum. Nam varius purus quis erat egestas feugiat. Duis a odio eros, a vehicula sapien. Pellentesque ac dolor in velit aliquam gravida.</p>\n<p>Donec ut bibendum risus. Sed nisl turpis, pulvinar ut bibendum non, dignissim quis nibh. Cras interdum dictum dui, at venenatis magna auctor a. In a turpis risus, quis mollis augue. Mauris cursus, metus eu accumsan cursus, arcu sapien posuere elit, in viverra nisi diam non arcu. Maecenas ultricies commodo diam, sit amet mattis sapien accumsan ut. Vivamus a felis in enim porta congue. Cras dui tortor, adipiscing imperdiet tempus eu, adipiscing id tellus. Quisque id varius metus. Suspendisse ac euismod neque. Nullam orci dui, tincidunt nec mollis quis, aliquet nec risus. Pellentesque et neque felis, a ullamcorper lacus. Quisque mollis, odio sed fringilla rutrum, elit ipsum adipiscing turpis, sit amet mollis purus neque sed nibh. Donec vitae arcu lorem. Suspendisse id elit felis, non condimentum mauris. Nullam ullamcorper volutpat urna vel feugiat.</p>', NULL, NULL, 1, 1, 2, 0, 0, NULL, 'Inherit', 'Inherit', 0, 8, 'None', 0),
(84, 1, 24, 1, 1, 1, 'HomePage', '2015-01-26 04:46:25', '2015-03-06 18:41:10', 'home', 'Home', NULL, '<p class="lead" style="text-align: center;">Look No Further. Get It Now.</p>\n<p>[button,iconClass="fa fa-download",wrapperClass="well",classes="btn btn-grand btn-block btn-blue",link="https://google.com",newWindow="true",noFollow="true",location="left"]Download[/button]</p>\n<p><span class="title-block"><img class="left" title="" src="assets/Uploads/Pages/10/_resampled/ResizedImage600400-general-1.jpg" alt="general 1" height="400" width="600">Lorem ipsum dolor sit amet</span>,<span class="tooltip-inner"> consectetur adipiscing elit</span>. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus. Donec iaculis, est ut adipiscing cursus, lectus turpis tristique massa, faucibus faucibus urna odio nec ante. Integer magna purus, tincidunt ut vestibulum eget, mattis sit amet purus. Donec interdum orci nec felis pulvinar hendrerit. Donec suscipit turpis et libero fermentum non venenatis massa eleifend. Maecenas fringilla consectetur risus vel venenatis. Sed tincidunt tellus sit amet tellus mattis a malesuada dui vulputate. Aenean ut orci metus, vitae bibendum diam. Aliquam sit amet leo sed est convallis blandit vel sed libero. Integer leo nisi, viverra sit amet congue in, suscipit ac orci. Ut ut nulla at nulla posuere rutrum. Etiam cursus ultricies placerat. Praesent eu tellus nec enim pulvinar porta. Maecenas faucibus interdum turpis, sed rhoncus ante luctus vel. Duis ut orci nec metus lobortis commodo. Donec aliquet, leo non vestibulum dictum, ante justo molestie leo, id eleifend diam odio nec tellus. Cras consequat nunc a quam interdum luctus mollis velit viverra.</p>', NULL, NULL, 1, 1, 1, 0, 0, NULL, 'Inherit', 'Inherit', 0, 0, 'None', 0),
(85, 1, 25, 1, 1, 1, 'HomePage', '2015-01-26 04:46:25', '2015-03-06 18:48:57', 'home', 'Home', NULL, '<p class="lead" style="text-align: center;">Look No Further. Get It Now.</p>\n<p>[button,iconClass="fa fa-download",wrapperClass="well",classes="btn btn-grand btn-block btn-blue",link="https://google.com",newWindow="true",noFollow="true",location="left"]Download[/button]</p>', NULL, NULL, 1, 1, 1, 0, 0, NULL, 'Inherit', 'Inherit', 0, 0, 'None', 0),
(83, 1, 23, 1, 1, 1, 'HomePage', '2015-01-26 04:46:25', '2015-03-06 18:37:23', 'home', 'Home', NULL, '<p class="lead" style="text-align: center;">Look No Further. Get It Now.</p>\n<p>[button,iconClass="fa fa-download",wrapperClass="well",classes="btn btn-grand btn-block btn-blue",link="https://google.com",newWindow="true",noFollow="true",location="left"]Download[/button]</p>\n<p><span class="title-block"><img class="leftAlone" title="" src="assets/Uploads/Pages/10/_resampled/ResizedImage600400-general-1.jpg" alt="general 1" height="400" width="600">Lorem ipsum dolor sit amet</span>,<span class="tooltip-inner"> consectetur adipiscing elit</span>. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus. Donec iaculis, est ut adipiscing cursus, lectus turpis tristique massa, faucibus faucibus urna odio nec ante. Integer magna purus, tincidunt ut vestibulum eget, mattis sit amet purus. Donec interdum orci nec felis pulvinar hendrerit. Donec suscipit turpis et libero fermentum non venenatis massa eleifend. Maecenas fringilla consectetur risus vel venenatis. Sed tincidunt tellus sit amet tellus mattis a malesuada dui vulputate. Aenean ut orci metus, vitae bibendum diam. Aliquam sit amet leo sed est convallis blandit vel sed libero. Integer leo nisi, viverra sit amet congue in, suscipit ac orci. Ut ut nulla at nulla posuere rutrum. Etiam cursus ultricies placerat. Praesent eu tellus nec enim pulvinar porta. Maecenas faucibus interdum turpis, sed rhoncus ante luctus vel. Duis ut orci nec metus lobortis commodo. Donec aliquet, leo non vestibulum dictum, ante justo molestie leo, id eleifend diam odio nec tellus. Cras consequat nunc a quam interdum luctus mollis velit viverra.</p>', NULL, NULL, 1, 1, 1, 0, 0, NULL, 'Inherit', 'Inherit', 0, 0, 'None', 0);
INSERT INTO `SiteTree_versions` (`ID`, `RecordID`, `Version`, `WasPublished`, `AuthorID`, `PublisherID`, `ClassName`, `Created`, `LastEdited`, `URLSegment`, `Title`, `MenuTitle`, `Content`, `MetaDescription`, `ExtraMeta`, `ShowInMenus`, `ShowInSearch`, `Sort`, `HasBrokenFile`, `HasBrokenLink`, `ReportClass`, `CanViewType`, `CanEditType`, `ProvideComments`, `ParentID`, `ModerationRequired`, `CommentsRequireLogin`) VALUES
(175, 11, 3, 1, 1, 1, 'PortfolioItem', '2015-01-28 20:07:31', '2015-03-19 09:45:29', 'portfolio-item-2', 'Portfolio Item #2', NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus. Donec iaculis, est ut adipiscing cursus, lectus turpis tristique massa, faucibus faucibus urna odio nec ante. Integer magna purus, tincidunt ut vestibulum eget, mattis sit amet purus. Donec interdum orci nec felis pulvinar hendrerit. Donec suscipit turpis et libero fermentum non venenatis massa eleifend. Maecenas fringilla consectetur risus vel venenatis. Sed tincidunt tellus sit amet tellus mattis a malesuada dui vulputate. Aenean ut orci metus, vitae bibendum diam. Aliquam sit amet leo sed est convallis blandit vel sed libero. Integer leo nisi, viverra sit amet congue in, suscipit ac orci. Ut ut nulla at nulla posuere rutrum. Etiam cursus ultricies placerat. Praesent eu tellus nec enim pulvinar porta. Maecenas faucibus interdum turpis, sed rhoncus ante luctus vel. Duis ut orci nec metus lobortis commodo. Donec aliquet, leo non vestibulum dictum, ante justo molestie leo, id eleifend diam odio nec tellus. Cras consequat nunc a quam interdum luctus mollis velit viverra.</p>', NULL, NULL, 1, 1, 1, 0, 0, NULL, 'Inherit', 'Inherit', 0, 9, 'None', 0),
(92, 4, 3, 0, 0, 0, 'Blog', '2015-01-26 04:46:26', '2015-03-12 08:13:07', 'blog', 'Blog', NULL, NULL, NULL, NULL, 1, 1, 4, 0, 0, NULL, 'Inherit', 'Inherit', 0, 0, 'None', 0),
(114, 2, 38, 1, 1, 1, 'AboutPage', '2015-01-26 04:46:26', '2015-03-12 20:35:53', 'about-us', 'About Us', NULL, '<p class="lead" style="text-align: center;"><span style="color: #ec7263;">Oneline is a modern fully responsive HTML5 template perfect for your web &amp; mobile apps.</span></p>\n<p class="text-center">Sed at porta tellus. Sed sit amet ipsum non dolor tincidunt vestibulum eget et urna. In et placerat eros. Curabitur tristique lacinia tortor ut ornare. Proin vehicula rhoncus fermentum. Integer scelerisque aliquam turpis. Quisque pellentesque, sem vel molestie posuere, orci sapien interdum mauris, eget condimentum purus arcu ut augue.</p>\n<p class="text-center"> </p>\n<table class="fluid-table col-md-12"><tbody><tr valign="top"><td class="col-md-6">\n<p>[video,id="67449472",service="vimeo",width="480",height="320",location="left"]</p>\n</td>\n<td class="col-md-6">\n<div class="well">This video is fully responsive. It will automatically adjust its size according to the parent block width.</div>\n<ul class="ft-list"><li>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>\n<li>Donec vulputate tellus quis volutpat congue.</li>\n<li>Sed ultrices eros eu euismod semper.</li>\n<li>Integer vulputate mauris in eleifend laoreet.</li>\n<li>Donec vulputate tellus quis volutpat congue.</li>\n<li>Sed ultrices eros eu euismod semper.</li>\n</ul></td>\n</tr></tbody></table>', NULL, NULL, 1, 1, 1, 0, 0, NULL, 'Inherit', 'Inherit', 0, 8, 'None', 0),
(115, 20, 1, 0, 1, 0, 'Page', '2015-03-12 21:25:41', '2015-03-12 21:25:41', 'new-page', 'New Page', NULL, NULL, NULL, NULL, 1, 1, 4, 0, 0, NULL, 'Inherit', 'Inherit', 0, 8, 'None', 0),
(112, 2, 36, 1, 1, 1, 'AboutPage', '2015-01-26 04:46:26', '2015-03-12 20:11:29', 'about-us', 'About Us', NULL, '<p class="lead" style="text-align: center;"><span style="color: #ec7263;">Oneline is a modern fully responsive HTML5 template perfect for your web &amp; mobile apps.</span></p>\n<p class="text-center">Sed at porta tellus. Sed sit amet ipsum non dolor tincidunt vestibulum eget et urna. In et placerat eros. Curabitur tristique lacinia tortor ut ornare. Proin vehicula rhoncus fermentum. Integer scelerisque aliquam turpis. Quisque pellentesque, sem vel molestie posuere, orci sapien interdum mauris, eget condimentum purus arcu ut augue.</p>\n<p class="text-center"> </p>\n<table class="fluid-table col-md-12"><tbody><tr valign="top"><td class="col-md-6">\n<p>[video,id="67449472",service="vimeo",width="480",height="320",location="left"]</p>\n</td>\n<td class="col-md-6">\n<div class="well">This video is fully responsive. It will automatically adjust its size according to the parent block width.</div>\n<ul class="ft-list"><li>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>\n<li>Donec vulputate tellus quis volutpat congue.</li>\n<li>Sed ultrices eros eu euismod semper.</li>\n<li>Integer vulputate mauris in eleifend laoreet.</li>\n<li>Donec vulputate tellus quis volutpat congue.</li>\n<li>Sed ultrices eros eu euismod semper.</li>\n</ul></td>\n</tr></tbody></table>', NULL, NULL, 1, 1, 1, 0, 0, NULL, 'Inherit', 'Inherit', 0, 8, 'None', 0),
(126, 5, 3, 0, 1, 0, 'BlogPost', '2015-01-26 04:46:26', '2015-03-13 16:39:41', 'sample-blog-entry', 'SilverStripe blog module successfully installed', NULL, '<p>Congratulations, the SilverStripe blog module has been successfully installed. This blog entry can be safely deleted. You can configure aspects of your blog in <a href="admin">the CMS</a>.</p>', NULL, NULL, 0, 1, 1, 0, 0, NULL, 'Inherit', 'Inherit', 1, 4, 'None', 0),
(134, 3, 10, 1, 1, 1, 'ContactPage', '2015-01-26 04:46:26', '2015-03-14 17:46:49', 'contact-us', 'Contact Us', NULL, '<h3 class="title-block second-child">Drop Us A Few Lines</h3>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin congue tellus ut velit mollis condimentum. Nulla egestas neque sed odio varius facilisis. Donec ac metus gravida leo dictum porttitor.</p>\n<hr>', NULL, NULL, 1, 1, 2, 0, 0, NULL, 'Inherit', 'Inherit', 0, 8, 'None', 0),
(135, 3, 11, 1, 1, 1, 'ContactPage', '2015-01-26 04:46:26', '2015-03-15 05:31:48', 'contact-us', 'Contact Us', NULL, '<h3 class="title-block second-child">Drop Us A Few Lines</h3>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin congue tellus ut velit mollis condimentum. Nulla egestas neque sed odio varius facilisis. Donec ac metus gravida leo dictum porttitor.</p>\n<hr>', NULL, NULL, 1, 1, 2, 0, 0, NULL, 'Inherit', 'Inherit', 0, 8, 'None', 0),
(131, 5, 4, 1, 1, 1, 'BlogPost', '2015-01-26 04:46:26', '2015-03-14 13:32:21', 'sample-blog-entry', 'SilverStripe blog module successfully installed', NULL, '<p>Congratulations, the SilverStripe blog module has been successfully installed. This blog entry can be safely deleted. You can configure aspects of your blog in <a href="admin">the CMS</a>.</p>', NULL, NULL, 0, 1, 1, 0, 0, NULL, 'Inherit', 'Inherit', 1, 4, 'None', 0),
(132, 5, 5, 1, 1, 1, 'BlogPost', '2015-01-26 04:46:26', '2015-03-14 13:34:12', 'sample-blog-entry', 'SilverStripe blog module successfully installed', NULL, '<p>Congratulations, the SilverStripe blog module has been successfully installed. This blog entry can be safely deleted. You can configure aspects of your blog in <a href="admin">the CMS</a>.</p>', NULL, NULL, 0, 1, 1, 0, 0, NULL, 'Inherit', 'Inherit', 1, 4, 'None', 0),
(136, 3, 12, 1, 1, 1, 'ContactPage', '2015-01-26 04:46:26', '2015-03-16 02:23:26', 'contact-us', 'Contact Us', NULL, '<h3 class="title-block second-child">Drop Us A Few Lines</h3>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin congue tellus ut velit mollis condimentum. Nulla egestas neque sed odio varius facilisis. Donec ac metus gravida leo dictum porttitor.</p>\n<hr>', NULL, NULL, 1, 1, 2, 0, 0, NULL, 'Inherit', 'Inherit', 0, 8, 'None', 0),
(137, 21, 1, 0, 1, 0, 'HelpPage', '2015-03-16 19:24:00', '2015-03-16 19:24:00', 'new-help-page', 'New Help Page', NULL, NULL, NULL, NULL, 1, 1, 5, 0, 0, NULL, 'Inherit', 'Inherit', 0, 8, 'None', 0),
(138, 21, 2, 1, 1, 1, 'HelpPage', '2015-03-16 19:24:00', '2015-03-16 19:24:25', 'help-center', 'Help Center', NULL, NULL, NULL, NULL, 1, 1, 5, 0, 0, NULL, 'Inherit', 'Inherit', 0, 8, 'None', 0),
(139, 22, 1, 0, 1, 0, 'HelpArticle', '2015-03-16 19:25:02', '2015-03-16 19:25:02', 'new-help-article', 'New Help article', NULL, NULL, NULL, NULL, 1, 1, 1, 0, 0, NULL, 'Inherit', 'Inherit', 0, 21, 'None', 0),
(141, 23, 1, 0, 1, 0, 'HelpArticle', '2015-03-16 19:26:59', '2015-03-16 19:26:59', 'new-help-article', 'New Help article', NULL, NULL, NULL, NULL, 1, 1, 2, 0, 0, NULL, 'Inherit', 'Inherit', 0, 21, 'None', 0),
(142, 23, 2, 1, 1, 1, 'HelpArticle', '2015-03-16 19:26:59', '2015-03-16 19:27:42', 'ut-ac-tortor-vitae-lorem-lobortis-vulputate-eget-ac-nisi', 'Ut ac tortor vitae lorem lobortis vulputate eget ac nisi', NULL, '<p>Donec massa urna, tristique sed lectus quis, suscipit ultricies velit. Curabitur pulvinar rutrum risus eu aliquet. Vestibulum at felis et ipsum lacinia fringilla. Praesent blandit ultricies velit non euismod. Integer fringilla, ipsum eu adipiscing venenatis, nisl nisl fermentum sem, nec suscipit felis arcu in augue. Nunc ac blandit lorem. Maecenas auctor justo odio, at eleifend nulla venenatis quis. Aenean semper, libero ac dictum bibendum, enim augue lacinia neque, quis aliquam lacus nulla sed nisi. Etiam eleifend scelerisque odio sit amet fermentum. Etiam at nunc est. Nam eu lobortis nulla. Pellentesque consectetur augue neque, ut porttitor massa tincidunt egestas. Fusce diam tellus, convallis rutrum faucibus porta, venenatis non velit. Nulla non convallis urna, lacinia mollis massa. Nam consequat tristique felis a egestas.</p>', NULL, NULL, 1, 1, 2, 0, 0, NULL, 'Inherit', 'Inherit', 0, 21, 'None', 0),
(143, 24, 1, 0, 1, 0, 'HelpArticle', '2015-03-16 19:28:08', '2015-03-16 19:28:08', 'new-help-article', 'New Help article', NULL, NULL, NULL, NULL, 1, 1, 3, 0, 0, NULL, 'Inherit', 'Inherit', 0, 21, 'None', 0),
(144, 24, 2, 1, 1, 1, 'HelpArticle', '2015-03-16 19:28:08', '2015-03-16 19:28:41', 'donec-massa-urna-tristique-sed-lectus-quis-suscipit-ultricies-velit', 'Donec massa urna, tristique sed lectus quis, suscipit ultricies velit', NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus. Donec iaculis, est ut adipiscing cursus, lectus turpis tristique massa, faucibus faucibus urna odio nec ante. Integer magna purus, tincidunt ut vestibulum eget, mattis sit amet purus. Donec interdum orci nec felis pulvinar hendrerit. Donec suscipit turpis et libero fermentum non venenatis massa eleifend. Maecenas fringilla consectetur risus vel venenatis. Sed tincidunt tellus sit amet tellus mattis a malesuada dui vulputate. Aenean ut orci metus, vitae bibendum diam. Aliquam sit amet leo sed est convallis blandit vel sed libero. Integer leo nisi, viverra sit amet congue in, suscipit ac orci. Ut ut nulla at nulla posuere rutrum. Etiam cursus ultricies placerat. Praesent eu tellus nec enim pulvinar porta. Maecenas faucibus interdum turpis, sed rhoncus ante luctus vel. Duis ut orci nec metus lobortis commodo. Donec aliquet, leo non vestibulum dictum, ante justo molestie leo, id eleifend diam odio nec tellus. Cras consequat nunc a quam interdum luctus mollis velit viverra.</p>\n<p>Nulla at leo eros, nec porttitor erat. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed venenatis facilisis dolor id pulvinar. Suspendisse tincidunt, arcu vestibulum venenatis blandit, arcu quam scelerisque nibh, nec imperdiet tellus tellus nec mauris. Suspendisse cursus varius velit, vel ultricies tortor fringilla pretium. Pellentesque posuere lobortis vehicula. Proin scelerisque dapibus eros, eget iaculis metus ultrices vel. Morbi malesuada ligula sit amet mauris mollis sed vulputate tellus fringilla. Maecenas at velit sem. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum in arcu quis odio ullamcorper vulputate. Etiam tempor placerat lorem, id rhoncus erat vulputate sed. Pellentesque dapibus sollicitudin ipsum. Aliquam sollicitudin augue sit amet sapien tristique vel tristique nisl auctor. Aliquam porta, dui quis molestie vehicula, sem est luctus felis, id suscipit massa ipsum sed elit. Quisque vehicula nulla nec felis egestas id pellentesque risus condimentum. Nam varius purus quis erat egestas feugiat. Duis a odio eros, a vehicula sapien. Pellentesque ac dolor in velit aliquam gravida.</p>\n<p>Donec ut bibendum risus. Sed nisl turpis, pulvinar ut bibendum non, dignissim quis nibh. Cras interdum dictum dui, at venenatis magna auctor a. In a turpis risus, quis mollis augue. Mauris cursus, metus eu accumsan cursus, arcu sapien posuere elit, in viverra nisi diam non arcu. Maecenas ultricies commodo diam, sit amet mattis sapien accumsan ut. Vivamus a felis in enim porta congue. Cras dui tortor, adipiscing imperdiet tempus eu, adipiscing id tellus. Quisque id varius metus. Suspendisse ac euismod neque. Nullam orci dui, tincidunt nec mollis quis, aliquet nec risus. Pellentesque et neque felis, a ullamcorper lacus. Quisque mollis, odio sed fringilla rutrum, elit ipsum adipiscing turpis, sit amet mollis purus neque sed nibh. Donec vitae arcu lorem. Suspendisse id elit felis, non condimentum mauris. Nullam ullamcorper volutpat urna vel feugiat.</p>', NULL, NULL, 1, 1, 3, 0, 0, NULL, 'Inherit', 'Inherit', 0, 21, 'None', 0),
(145, 25, 1, 0, 1, 0, 'HelpArticle', '2015-03-16 19:32:05', '2015-03-16 19:32:05', 'new-help-article', 'New Help article', NULL, NULL, NULL, NULL, 1, 1, 4, 0, 0, NULL, 'Inherit', 'Inherit', 0, 21, 'None', 0),
(146, 25, 2, 1, 1, 1, 'HelpArticle', '2015-03-16 19:32:05', '2015-03-16 19:33:20', 'find-your-computers-ip-address', 'Find your computer''s IP address', NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus. Donec iaculis, est ut adipiscing cursus, lectus turpis tristique massa, faucibus faucibus urna odio nec ante. Integer magna purus, tincidunt ut vestibulum eget, mattis sit amet purus. Donec interdum orci nec felis pulvinar hendrerit. Donec suscipit turpis et libero fermentum non venenatis massa eleifend. Maecenas fringilla consectetur risus vel venenatis. Sed tincidunt tellus sit amet tellus mattis a malesuada dui vulputate. Aenean ut orci metus, vitae bibendum diam. Aliquam sit amet leo sed est convallis blandit vel sed libero. Integer leo nisi, viverra sit amet congue in, suscipit ac orci. Ut ut nulla at nulla posuere rutrum. Etiam cursus ultricies placerat. Praesent eu tellus nec enim pulvinar porta. Maecenas faucibus interdum turpis, sed rhoncus ante luctus vel. Duis ut orci nec metus lobortis commodo. Donec aliquet, leo non vestibulum dictum, ante justo molestie leo, id eleifend diam odio nec tellus. Cras consequat nunc a quam interdum luctus mollis velit viverra.</p>\n<p>Nulla at leo eros, nec porttitor erat. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed venenatis facilisis dolor id pulvinar. Suspendisse tincidunt, arcu vestibulum venenatis blandit, arcu quam scelerisque nibh, nec imperdiet tellus tellus nec mauris. Suspendisse cursus varius velit, vel ultricies tortor fringilla pretium. Pellentesque posuere lobortis vehicula. Proin scelerisque dapibus eros, eget iaculis metus ultrices vel. Morbi malesuada ligula sit amet mauris mollis sed vulputate tellus fringilla. Maecenas at velit sem. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum in arcu quis odio ullamcorper vulputate. Etiam tempor placerat lorem, id rhoncus erat vulputate sed. Pellentesque dapibus sollicitudin ipsum. Aliquam sollicitudin augue sit amet sapien tristique vel tristique nisl auctor. Aliquam porta, dui quis molestie vehicula, sem est luctus felis, id suscipit massa ipsum sed elit. Quisque vehicula nulla nec felis egestas id pellentesque risus condimentum. Nam varius purus quis erat egestas feugiat. Duis a odio eros, a vehicula sapien. Pellentesque ac dolor in velit aliquam gravida.</p>\n<p>Donec ut bibendum risus. Sed nisl turpis, pulvinar ut bibendum non, dignissim quis nibh. Cras interdum dictum dui, at venenatis magna auctor a. In a turpis risus, quis mollis augue. Mauris cursus, metus eu accumsan cursus, arcu sapien posuere elit, in viverra nisi diam non arcu. Maecenas ultricies commodo diam, sit amet mattis sapien accumsan ut. Vivamus a felis in enim porta congue. Cras dui tortor, adipiscing imperdiet tempus eu, adipiscing id tellus. Quisque id varius metus. Suspendisse ac euismod neque. Nullam orci dui, tincidunt nec mollis quis, aliquet nec risus. Pellentesque et neque felis, a ullamcorper lacus. Quisque mollis, odio sed fringilla rutrum, elit ipsum adipiscing turpis, sit amet mollis purus neque sed nibh. Donec vitae arcu lorem. Suspendisse id elit felis, non condimentum mauris. Nullam ullamcorper volutpat urna vel feugiat.</p>', NULL, NULL, 1, 1, 4, 0, 0, NULL, 'Inherit', 'Inherit', 0, 21, 'None', 0),
(147, 25, 3, 1, 1, 1, 'HelpArticle', '2015-03-16 19:32:05', '2015-03-16 19:33:30', 'find-your-computers-ip-address', 'Find your computer''s IP address', NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus. Donec iaculis, est ut adipiscing cursus, lectus turpis tristique massa, faucibus faucibus urna odio nec ante. Integer magna purus, tincidunt ut vestibulum eget, mattis sit amet purus. Donec interdum orci nec felis pulvinar hendrerit. Donec suscipit turpis et libero fermentum non venenatis massa eleifend. Maecenas fringilla consectetur risus vel venenatis. Sed tincidunt tellus sit amet tellus mattis a malesuada dui vulputate. Aenean ut orci metus, vitae bibendum diam. Aliquam sit amet leo sed est convallis blandit vel sed libero. Integer leo nisi, viverra sit amet congue in, suscipit ac orci. Ut ut nulla at nulla posuere rutrum. Etiam cursus ultricies placerat. Praesent eu tellus nec enim pulvinar porta. Maecenas faucibus interdum turpis, sed rhoncus ante luctus vel. Duis ut orci nec metus lobortis commodo. Donec aliquet, leo non vestibulum dictum, ante justo molestie leo, id eleifend diam odio nec tellus. Cras consequat nunc a quam interdum luctus mollis velit viverra.</p>\n<p>Nulla at leo eros, nec porttitor erat. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed venenatis facilisis dolor id pulvinar. Suspendisse tincidunt, arcu vestibulum venenatis blandit, arcu quam scelerisque nibh, nec imperdiet tellus tellus nec mauris. Suspendisse cursus varius velit, vel ultricies tortor fringilla pretium. Pellentesque posuere lobortis vehicula. Proin scelerisque dapibus eros, eget iaculis metus ultrices vel. Morbi malesuada ligula sit amet mauris mollis sed vulputate tellus fringilla. Maecenas at velit sem. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum in arcu quis odio ullamcorper vulputate. Etiam tempor placerat lorem, id rhoncus erat vulputate sed. Pellentesque dapibus sollicitudin ipsum. Aliquam sollicitudin augue sit amet sapien tristique vel tristique nisl auctor. Aliquam porta, dui quis molestie vehicula, sem est luctus felis, id suscipit massa ipsum sed elit. Quisque vehicula nulla nec felis egestas id pellentesque risus condimentum. Nam varius purus quis erat egestas feugiat. Duis a odio eros, a vehicula sapien. Pellentesque ac dolor in velit aliquam gravida.</p>\n<p>Donec ut bibendum risus. Sed nisl turpis, pulvinar ut bibendum non, dignissim quis nibh. Cras interdum dictum dui, at venenatis magna auctor a. In a turpis risus, quis mollis augue. Mauris cursus, metus eu accumsan cursus, arcu sapien posuere elit, in viverra nisi diam non arcu. Maecenas ultricies commodo diam, sit amet mattis sapien accumsan ut. Vivamus a felis in enim porta congue. Cras dui tortor, adipiscing imperdiet tempus eu, adipiscing id tellus. Quisque id varius metus. Suspendisse ac euismod neque. Nullam orci dui, tincidunt nec mollis quis, aliquet nec risus. Pellentesque et neque felis, a ullamcorper lacus. Quisque mollis, odio sed fringilla rutrum, elit ipsum adipiscing turpis, sit amet mollis purus neque sed nibh. Donec vitae arcu lorem. Suspendisse id elit felis, non condimentum mauris. Nullam ullamcorper volutpat urna vel feugiat.</p>', NULL, NULL, 1, 1, 4, 0, 0, NULL, 'Inherit', 'Inherit', 0, 21, 'None', 0),
(148, 26, 1, 0, 1, 0, 'HelpArticle', '2015-03-16 19:34:21', '2015-03-16 19:34:21', 'new-help-article', 'New Help article', NULL, NULL, NULL, NULL, 1, 1, 5, 0, 0, NULL, 'Inherit', 'Inherit', 0, 21, 'None', 0),
(149, 26, 2, 1, 1, 1, 'HelpArticle', '2015-03-16 19:34:21', '2015-03-16 19:34:33', 'wired-and-wireless-network-problems', 'Wired and wireless network problems', NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus. Donec iaculis, est ut adipiscing cursus, lectus turpis tristique massa, faucibus faucibus urna odio nec ante. Integer magna purus, tincidunt ut vestibulum eget, mattis sit amet purus. Donec interdum orci nec felis pulvinar hendrerit. Donec suscipit turpis et libero fermentum non venenatis massa eleifend. Maecenas fringilla consectetur risus vel venenatis. Sed tincidunt tellus sit amet tellus mattis a malesuada dui vulputate. Aenean ut orci metus, vitae bibendum diam. Aliquam sit amet leo sed est convallis blandit vel sed libero. Integer leo nisi, viverra sit amet congue in, suscipit ac orci. Ut ut nulla at nulla posuere rutrum. Etiam cursus ultricies placerat. Praesent eu tellus nec enim pulvinar porta. Maecenas faucibus interdum turpis, sed rhoncus ante luctus vel. Duis ut orci nec metus lobortis commodo. Donec aliquet, leo non vestibulum dictum, ante justo molestie leo, id eleifend diam odio nec tellus. Cras consequat nunc a quam interdum luctus mollis velit viverra.</p>\n<p>Nulla at leo eros, nec porttitor erat. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed venenatis facilisis dolor id pulvinar. Suspendisse tincidunt, arcu vestibulum venenatis blandit, arcu quam scelerisque nibh, nec imperdiet tellus tellus nec mauris. Suspendisse cursus varius velit, vel ultricies tortor fringilla pretium. Pellentesque posuere lobortis vehicula. Proin scelerisque dapibus eros, eget iaculis metus ultrices vel. Morbi malesuada ligula sit amet mauris mollis sed vulputate tellus fringilla. Maecenas at velit sem. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum in arcu quis odio ullamcorper vulputate. Etiam tempor placerat lorem, id rhoncus erat vulputate sed. Pellentesque dapibus sollicitudin ipsum. Aliquam sollicitudin augue sit amet sapien tristique vel tristique nisl auctor. Aliquam porta, dui quis molestie vehicula, sem est luctus felis, id suscipit massa ipsum sed elit. Quisque vehicula nulla nec felis egestas id pellentesque risus condimentum. Nam varius purus quis erat egestas feugiat. Duis a odio eros, a vehicula sapien. Pellentesque ac dolor in velit aliquam gravida.</p>\n<p>Donec ut bibendum risus. Sed nisl turpis, pulvinar ut bibendum non, dignissim quis nibh. Cras interdum dictum dui, at venenatis magna auctor a. In a turpis risus, quis mollis augue. Mauris cursus, metus eu accumsan cursus, arcu sapien posuere elit, in viverra nisi diam non arcu. Maecenas ultricies commodo diam, sit amet mattis sapien accumsan ut. Vivamus a felis in enim porta congue. Cras dui tortor, adipiscing imperdiet tempus eu, adipiscing id tellus. Quisque id varius metus. Suspendisse ac euismod neque. Nullam orci dui, tincidunt nec mollis quis, aliquet nec risus. Pellentesque et neque felis, a ullamcorper lacus. Quisque mollis, odio sed fringilla rutrum, elit ipsum adipiscing turpis, sit amet mollis purus neque sed nibh. Donec vitae arcu lorem. Suspendisse id elit felis, non condimentum mauris. Nullam ullamcorper volutpat urna vel feugiat.</p>', NULL, NULL, 1, 1, 5, 0, 0, NULL, 'Inherit', 'Inherit', 0, 21, 'None', 0),
(150, 27, 1, 0, 1, 0, 'HelpArticle', '2015-03-16 19:34:41', '2015-03-16 19:34:41', 'new-help-article', 'New Help article', NULL, NULL, NULL, NULL, 1, 1, 6, 0, 0, NULL, 'Inherit', 'Inherit', 0, 21, 'None', 0),
(151, 27, 2, 1, 1, 1, 'HelpArticle', '2015-03-16 19:34:41', '2015-03-16 19:35:08', 'setting-up-email', 'Setting up email', NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus. Donec iaculis, est ut adipiscing cursus, lectus turpis tristique massa, faucibus faucibus urna odio nec ante. Integer magna purus, tincidunt ut vestibulum eget, mattis sit amet purus. Donec interdum orci nec felis pulvinar hendrerit. Donec suscipit turpis et libero fermentum non venenatis massa eleifend. Maecenas fringilla consectetur risus vel venenatis. Sed tincidunt tellus sit amet tellus mattis a malesuada dui vulputate. Aenean ut orci metus, vitae bibendum diam. Aliquam sit amet leo sed est convallis blandit vel sed libero. Integer leo nisi, viverra sit amet congue in, suscipit ac orci. Ut ut nulla at nulla posuere rutrum. Etiam cursus ultricies placerat. Praesent eu tellus nec enim pulvinar porta. Maecenas faucibus interdum turpis, sed rhoncus ante luctus vel. Duis ut orci nec metus lobortis commodo. Donec aliquet, leo non vestibulum dictum, ante justo molestie leo, id eleifend diam odio nec tellus. Cras consequat nunc a quam interdum luctus mollis velit viverra.</p>\n<p>Nulla at leo eros, nec porttitor erat. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed venenatis facilisis dolor id pulvinar. Suspendisse tincidunt, arcu vestibulum venenatis blandit, arcu quam scelerisque nibh, nec imperdiet tellus tellus nec mauris. Suspendisse cursus varius velit, vel ultricies tortor fringilla pretium. Pellentesque posuere lobortis vehicula. Proin scelerisque dapibus eros, eget iaculis metus ultrices vel. Morbi malesuada ligula sit amet mauris mollis sed vulputate tellus fringilla. Maecenas at velit sem. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum in arcu quis odio ullamcorper vulputate. Etiam tempor placerat lorem, id rhoncus erat vulputate sed. Pellentesque dapibus sollicitudin ipsum. Aliquam sollicitudin augue sit amet sapien tristique vel tristique nisl auctor. Aliquam porta, dui quis molestie vehicula, sem est luctus felis, id suscipit massa ipsum sed elit. Quisque vehicula nulla nec felis egestas id pellentesque risus condimentum. Nam varius purus quis erat egestas feugiat. Duis a odio eros, a vehicula sapien. Pellentesque ac dolor in velit aliquam gravida.</p>\n<p>Donec ut bibendum risus. Sed nisl turpis, pulvinar ut bibendum non, dignissim quis nibh. Cras interdum dictum dui, at venenatis magna auctor a. In a turpis risus, quis mollis augue. Mauris cursus, metus eu accumsan cursus, arcu sapien posuere elit, in viverra nisi diam non arcu. Maecenas ultricies commodo diam, sit amet mattis sapien accumsan ut. Vivamus a felis in enim porta congue. Cras dui tortor, adipiscing imperdiet tempus eu, adipiscing id tellus. Quisque id varius metus. Suspendisse ac euismod neque. Nullam orci dui, tincidunt nec mollis quis, aliquet nec risus. Pellentesque et neque felis, a ullamcorper lacus. Quisque mollis, odio sed fringilla rutrum, elit ipsum adipiscing turpis, sit amet mollis purus neque sed nibh. Donec vitae arcu lorem. Suspendisse id elit felis, non condimentum mauris. Nullam ullamcorper volutpat urna vel feugiat.</p>', NULL, NULL, 1, 1, 6, 0, 0, NULL, 'Inherit', 'Inherit', 0, 21, 'None', 0),
(152, 22, 3, 1, 1, 1, 'HelpArticle', '2015-03-16 19:25:02', '2015-03-16 21:09:50', 'lorem-ipsum-dolor-sit-amet-consectetur-adipiscing-elit-ut-ac-tortor-vitae-lorem-lobortis', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut ac tortor vitae lorem lobortis', NULL, '<p>Donec massa urna, tristique sed lectus quis, suscipit ultricies velit. Curabitur pulvinar rutrum risus eu aliquet. Vestibulum at felis et ipsum lacinia fringilla. Praesent blandit ultricies velit non euismod. Integer fringilla, ipsum eu adipiscing venenatis, nisl nisl fermentum sem, nec suscipit felis arcu in augue. Nunc ac blandit lorem. Maecenas auctor justo odio, at eleifend nulla venenatis quis. Aenean semper, libero ac dictum bibendum, enim augue lacinia neque, quis aliquam lacus nulla sed nisi. Etiam eleifend scelerisque odio sit amet fermentum. Etiam at nunc est. Nam eu lobortis nulla. Pellentesque consectetur augue neque, ut porttitor massa tincidunt egestas. Fusce diam tellus, convallis rutrum faucibus porta, venenatis non velit. Nulla non convallis urna, lacinia mollis massa. Nam consequat tristique felis a egestas.</p>\n<p>Donec massa urna, tristique sed lectus quis, suscipit ultricies velit. Curabitur pulvinar rutrum risus eu aliquet. Vestibulum at felis et ipsum lacinia fringilla. Praesent blandit ultricies velit non euismod. Integer fringilla, ipsum eu adipiscing venenatis, nisl nisl fermentum sem, nec suscipit felis arcu in augue. Nunc ac blandit lorem. Maecenas auctor justo odio, at eleifend nulla venenatis quis. Aenean semper, libero ac dictum bibendum, enim augue lacinia neque, quis aliquam lacus nulla sed nisi. Etiam eleifend scelerisque odio sit amet fermentum. Etiam at nunc est. Nam eu lobortis nulla. Pellentesque consectetur augue neque, ut porttitor massa tincidunt egestas. Fusce diam tellus, convallis rutrum faucibus porta, venenatis non velit. Nulla non convallis urna, lacinia mollis massa. Nam consequat tristique felis a egestas.</p>\n<p>Donec massa urna, tristique sed lectus quis, suscipit ultricies velit. Curabitur pulvinar rutrum risus eu aliquet. Vestibulum at felis et ipsum lacinia fringilla. Praesent blandit ultricies velit non euismod. Integer fringilla, ipsum eu adipiscing venenatis, nisl nisl fermentum sem, nec suscipit felis arcu in augue. Nunc ac blandit lorem. Maecenas auctor justo odio, at eleifend nulla venenatis quis. Aenean semper, libero ac dictum bibendum, enim augue lacinia neque, quis aliquam lacus nulla sed nisi. Etiam eleifend scelerisque odio sit amet fermentum. Etiam at nunc est. Nam eu lobortis nulla. Pellentesque consectetur augue neque, ut porttitor massa tincidunt egestas. Fusce diam tellus, convallis rutrum faucibus porta, venenatis non velit. Nulla non convallis urna, lacinia mollis massa. Nam consequat tristique felis a egestas.</p>', NULL, NULL, 1, 1, 1, 0, 0, NULL, 'Inherit', 'Inherit', 0, 21, 'None', 0),
(153, 22, 4, 1, 1, 1, 'HelpArticle', '2015-03-16 19:25:02', '2015-03-16 21:36:55', 'lorem-ipsum-dolor-sit-amet-consectetur-adipiscing-elit-ut-ac-tortor-vitae-lorem-lobortis', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut ac tortor vitae lorem lobortis', NULL, '<p>Donec massa urna, tristique sed lectus quis, suscipit ultricies velit. Curabitur pulvinar rutrum risus eu aliquet. Vestibulum at felis et ipsum lacinia fringilla. Praesent blandit ultricies velit non euismod. Integer fringilla, ipsum eu adipiscing venenatis, nisl nisl fermentum sem, nec suscipit felis arcu in augue. Nunc ac blandit lorem. Maecenas auctor justo odio, at eleifend nulla venenatis quis. Aenean semper, libero ac dictum bibendum, enim augue lacinia neque, quis aliquam lacus nulla sed nisi. Etiam eleifend scelerisque odio sit amet fermentum. Etiam at nunc est. Nam eu lobortis nulla. Pellentesque consectetur augue neque, ut porttitor massa tincidunt egestas. Fusce diam tellus, convallis rutrum faucibus porta, venenatis non velit. Nulla non convallis urna, lacinia mollis massa. Nam consequat tristique felis a egestas.</p>\n<p>Donec massa urna, tristique sed lectus quis, suscipit ultricies velit. Curabitur pulvinar rutrum risus eu aliquet. Vestibulum at felis et ipsum lacinia fringilla. Praesent blandit ultricies velit non euismod. Integer fringilla, ipsum eu adipiscing venenatis, nisl nisl fermentum sem, nec suscipit felis arcu in augue. Nunc ac blandit lorem. Maecenas auctor justo odio, at eleifend nulla venenatis quis. Aenean semper, libero ac dictum bibendum, enim augue lacinia neque, quis aliquam lacus nulla sed nisi. Etiam eleifend scelerisque odio sit amet fermentum. Etiam at nunc est. Nam eu lobortis nulla. Pellentesque consectetur augue neque, ut porttitor massa tincidunt egestas. Fusce diam tellus, convallis rutrum faucibus porta, venenatis non velit. Nulla non convallis urna, lacinia mollis massa. Nam consequat tristique felis a egestas.</p>\n<p>Donec massa urna, tristique sed lectus quis, suscipit ultricies velit. Curabitur pulvinar rutrum risus eu aliquet. Vestibulum at felis et ipsum lacinia fringilla. Praesent blandit ultricies velit non euismod. Integer fringilla, ipsum eu adipiscing venenatis, nisl nisl fermentum sem, nec suscipit felis arcu in augue. Nunc ac blandit lorem. Maecenas auctor justo odio, at eleifend nulla venenatis quis. Aenean semper, libero ac dictum bibendum, enim augue lacinia neque, quis aliquam lacus nulla sed nisi. Etiam eleifend scelerisque odio sit amet fermentum. Etiam at nunc est. Nam eu lobortis nulla. Pellentesque consectetur augue neque, ut porttitor massa tincidunt egestas. Fusce diam tellus, convallis rutrum faucibus porta, venenatis non velit. Nulla non convallis urna, lacinia mollis massa. Nam consequat tristique felis a egestas.</p>', NULL, NULL, 1, 1, 1, 0, 0, NULL, 'Inherit', 'Inherit', 1, 21, 'None', 0),
(154, 22, 5, 1, 1, 1, 'HelpArticle', '2015-03-16 19:25:02', '2015-03-17 17:04:45', 'lorem-ipsum-dolor-sit-amet-consectetur-adipiscing-elit-ut-ac-tortor-vitae-lorem-lobortis', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut ac tortor vitae lorem lobortis', NULL, '<p>Donec massa urna, tristique sed lectus quis, suscipit ultricies velit. Curabitur pulvinar rutrum risus eu aliquet. Vestibulum at felis et ipsum lacinia fringilla. Praesent blandit ultricies velit non euismod. Integer fringilla, ipsum eu adipiscing venenatis, nisl nisl fermentum sem, nec suscipit felis arcu in augue. Nunc ac blandit lorem. Maecenas auctor justo odio, at eleifend nulla venenatis quis. Aenean semper, libero ac dictum bibendum, enim augue lacinia neque, quis aliquam lacus nulla sed nisi. Etiam eleifend scelerisque odio sit amet fermentum. Etiam at nunc est. Nam eu lobortis nulla. Pellentesque consectetur augue neque, ut porttitor massa tincidunt egestas. Fusce diam tellus, convallis rutrum faucibus porta, venenatis non velit. Nulla non convallis urna, lacinia mollis massa. Nam consequat tristique felis a egestas.</p>\n<p>Donec massa urna, tristique sed lectus quis, suscipit ultricies velit. Curabitur pulvinar rutrum risus eu aliquet. Vestibulum at felis et ipsum lacinia fringilla. Praesent blandit ultricies velit non euismod. Integer fringilla, ipsum eu adipiscing venenatis, nisl nisl fermentum sem, nec suscipit felis arcu in augue. Nunc ac blandit lorem. Maecenas auctor justo odio, at eleifend nulla venenatis quis. Aenean semper, libero ac dictum bibendum, enim augue lacinia neque, quis aliquam lacus nulla sed nisi. Etiam eleifend scelerisque odio sit amet fermentum. Etiam at nunc est. Nam eu lobortis nulla. Pellentesque consectetur augue neque, ut porttitor massa tincidunt egestas. Fusce diam tellus, convallis rutrum faucibus porta, venenatis non velit. Nulla non convallis urna, lacinia mollis massa. Nam consequat tristique felis a egestas.</p>\n<p>Donec massa urna, tristique sed lectus quis, suscipit ultricies velit. Curabitur pulvinar rutrum risus eu aliquet. Vestibulum at felis et ipsum lacinia fringilla. Praesent blandit ultricies velit non euismod. Integer fringilla, ipsum eu adipiscing venenatis, nisl nisl fermentum sem, nec suscipit felis arcu in augue. Nunc ac blandit lorem. Maecenas auctor justo odio, at eleifend nulla venenatis quis. Aenean semper, libero ac dictum bibendum, enim augue lacinia neque, quis aliquam lacus nulla sed nisi. Etiam eleifend scelerisque odio sit amet fermentum. Etiam at nunc est. Nam eu lobortis nulla. Pellentesque consectetur augue neque, ut porttitor massa tincidunt egestas. Fusce diam tellus, convallis rutrum faucibus porta, venenatis non velit. Nulla non convallis urna, lacinia mollis massa. Nam consequat tristique felis a egestas.</p>\n<p>ThemeStripe.</p>', NULL, NULL, 1, 1, 1, 0, 0, NULL, 'Inherit', 'Inherit', 1, 21, 'None', 0),
(155, 20, 12, 1, 1, 1, 'ServicePage', '2015-03-12 21:25:41', '2015-03-17 18:12:51', 'services', 'Services', NULL, '<table class="fluid-table col-md-12"><tbody><tr valign="top"><td class="col-md-7">\n<h4>Company Introduction</h4>\n<p>Sed at porta tellus. Sed sit amet ipsum non dolor tincidunt vestibulum eget et urna. In et placerat eros. Curabitur tristique lacinia tortor ut ornare. Proin vehicula rhoncus fermentum. Integer scelerisque aliquam turpis. Quisque pellentesque, sem vel molestie posuere, orci sapien interdum mauris, eget condimentum purus arcu ut augue.</p>\n<hr><p>[button,link="contact-us/",classes="btn btn-lg btn-red",location="left"]Contact us[/button]</p>\n</td>\n<td class="col-md-5">\n<h4>Video guide</h4>\n<p>[video,id="67449472",service="vimeo",width="480",height="320",location="left"]</p>\n</td>\n</tr></tbody></table>', NULL, NULL, 1, 1, 4, 0, 0, NULL, 'Inherit', 'Inherit', 0, 8, 'None', 0),
(156, 20, 13, 1, 1, 1, 'ServicePage', '2015-03-12 21:25:41', '2015-03-17 18:23:24', 'services', 'Services', NULL, '<table class="fluid-table col-md-12"><tbody><tr valign="top"><td class="col-md-7">\n<h4>Company Introduction</h4>\n<p>Sed at porta tellus. Sed sit amet ipsum non dolor tincidunt vestibulum eget et urna. In et placerat eros. Curabitur tristique lacinia tortor ut ornare. Proin vehicula rhoncus fermentum. Integer scelerisque aliquam turpis. Quisque pellentesque, sem vel molestie posuere, orci sapien interdum mauris, eget condimentum purus arcu ut augue.</p>\n<hr><p>[button,link="contact-us/",classes="btn btn-lg btn-red",location="left"]Contact us[/button]</p>\n</td>\n<td class="col-md-5">\n<h4>Video guide</h4>\n<p>[video,id="67449472",service="vimeo",width="480",height="320",location="left"]</p>\n</td>\n</tr></tbody></table><p> </p>\n<div class="row">\n<div class="col-sm-12">\n<h1 class="title-block">Main Services Provided By Your Company</h1>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent imperdiet pretium elit non lacinia. Integer in consequat metus. Curabitur dapibus velit sed scelerisque fermentum. Proin interdum purus nec pharetra semper.</p>\n</div>\n</div>', NULL, NULL, 1, 1, 4, 0, 0, NULL, 'Inherit', 'Inherit', 0, 8, 'None', 0),
(157, 21, 3, 1, 1, 1, 'HelpPage', '2015-03-16 19:24:00', '2015-03-17 18:27:31', 'help-center', 'Help Center', NULL, NULL, NULL, NULL, 1, 1, 3, 0, 0, NULL, 'Inherit', 'Inherit', 0, 8, 'None', 0),
(158, 20, 14, 1, 1, 1, 'ServicePage', '2015-03-12 21:25:41', '2015-03-17 18:27:59', 'services', 'Services', NULL, '<table class="fluid-table col-md-12"><tbody><tr valign="top"><td class="col-md-7">\n<h4>Company Introduction</h4>\n<p>Sed at porta tellus. Sed sit amet ipsum non dolor tincidunt vestibulum eget et urna. In et placerat eros. Curabitur tristique lacinia tortor ut ornare. Proin vehicula rhoncus fermentum. Integer scelerisque aliquam turpis. Quisque pellentesque, sem vel molestie posuere, orci sapien interdum mauris, eget condimentum purus arcu ut augue.</p>\n<hr><p>[button,link="contact-us/",classes="btn btn-lg btn-red",location="left"]Contact us[/button]</p>\n</td>\n<td class="col-md-5">\n<h4>Video guide</h4>\n<p>[video,id="67449472",service="vimeo",width="480",height="320",location="left"]</p>\n</td>\n</tr></tbody></table><p> </p>\n<div class="row">\n<div class="col-sm-12">\n<h1 class="title-block">Main Services Provided By Your Company</h1>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent imperdiet pretium elit non lacinia. Integer in consequat metus. Curabitur dapibus velit sed scelerisque fermentum. Proin interdum purus nec pharetra semper.</p>\n</div>\n</div>', NULL, NULL, 1, 1, 4, 0, 0, NULL, 'Inherit', 'Inherit', 0, 8, 'None', 0),
(159, 16, 3, 1, 1, 1, 'TimelinePage', '2015-02-08 18:05:28', '2015-03-17 18:44:28', 'timeline', 'Timeline', NULL, NULL, NULL, NULL, 1, 1, 5, 0, 0, NULL, 'Inherit', 'Inherit', 0, 8, 'None', 0),
(160, 19, 3, 1, 1, 1, 'TimelineItem', '2015-02-08 18:05:54', '2015-03-17 19:30:33', 'event-3', 'Event 003', NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus. Donec iaculis, est ut adipiscing cursus, lectus turpis tristique massa, faucibus faucibus urna odio nec ante. Integer magna purus, tincidunt ut vestibulum eget, mattis sit amet purus. Donec interdum orci nec felis pulvinar hendrerit. Donec suscipit turpis et libero fermentum non venenatis massa eleifend. Maecenas fringilla consectetur risus vel venenatis. Sed tincidunt tellus sit amet tellus mattis a malesuada dui vulputate. Aenean ut orci metus, vitae bibendum diam. Aliquam sit amet leo sed est convallis blandit vel sed libero. Integer leo nisi, viverra sit amet congue in, suscipit ac orci. Ut ut nulla at nulla posuere rutrum. Etiam cursus ultricies placerat. Praesent eu tellus nec enim pulvinar porta. Maecenas faucibus interdum turpis, sed rhoncus ante luctus vel. Duis ut orci nec metus lobortis commodo. Donec aliquet, leo non vestibulum dictum, ante justo molestie leo, id eleifend diam odio nec tellus. Cras consequat nunc a quam interdum luctus mollis velit viverra.</p>\n<p>Nulla at leo eros, nec porttitor erat. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed venenatis facilisis dolor id pulvinar. Suspendisse tincidunt, arcu vestibulum venenatis blandit, arcu quam scelerisque nibh, nec imperdiet tellus tellus nec mauris. Suspendisse cursus varius velit, vel ultricies tortor fringilla pretium. Pellentesque posuere lobortis vehicula. Proin scelerisque dapibus eros, eget iaculis metus ultrices vel. Morbi malesuada ligula sit amet mauris mollis sed vulputate tellus fringilla. Maecenas at velit sem. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum in arcu quis odio ullamcorper vulputate. Etiam tempor placerat lorem, id rhoncus erat vulputate sed. Pellentesque dapibus sollicitudin ipsum. Aliquam sollicitudin augue sit amet sapien tristique vel tristique nisl auctor. Aliquam porta, dui quis molestie vehicula, sem est luctus felis, id suscipit massa ipsum sed elit. Quisque vehicula nulla nec felis egestas id pellentesque risus condimentum. Nam varius purus quis erat egestas feugiat. Duis a odio eros, a vehicula sapien. Pellentesque ac dolor in velit aliquam gravida.</p>\n<p>Donec ut bibendum risus. Sed nisl turpis, pulvinar ut bibendum non, dignissim quis nibh. Cras interdum dictum dui, at venenatis magna auctor a. In a turpis risus, quis mollis augue. Mauris cursus, metus eu accumsan cursus, arcu sapien posuere elit, in viverra nisi diam non arcu. Maecenas ultricies commodo diam, sit amet mattis sapien accumsan ut. Vivamus a felis in enim porta congue. Cras dui tortor, adipiscing imperdiet tempus eu, adipiscing id tellus. Quisque id varius metus. Suspendisse ac euismod neque. Nullam orci dui, tincidunt nec mollis quis, aliquet nec risus. Pellentesque et neque felis, a ullamcorper lacus. Quisque mollis, odio sed fringilla rutrum, elit ipsum adipiscing turpis, sit amet mollis purus neque sed nibh. Donec vitae arcu lorem. Suspendisse id elit felis, non condimentum mauris. Nullam ullamcorper volutpat urna vel feugiat.</p>', NULL, NULL, 1, 1, 3, 0, 0, NULL, 'Inherit', 'Inherit', 0, 16, 'None', 0),
(161, 16, 4, 1, 1, 1, 'TimelinePage', '2015-02-08 18:05:28', '2015-03-17 19:33:52', 'timeline', 'Timeline', NULL, '<h2 class="title-block text-center">Timeline is a great way to showcase your company history, share news or events</h2>\n<p class="text-center">Donec tincidunt nec mi eu venenatis. Nulla facilisi. Maecenas venenatis condimentum porttitor. Aliquam erat volutpat. In ac mollis odio. Praesent ac mi nisi. Nulla congue mi at porttitor ultrices. Nulla pellentesque placerat elit, sit amet egestas mi consectetur eleifend. Integer molestie ultricies libero ut consectetur. Maecenas consectetur quis elit quis consequat. Sed tincidunt nulla in lorem ullamcorper, ut aliquam odio malesuada.</p>', NULL, NULL, 1, 1, 5, 0, 0, NULL, 'Inherit', 'Inherit', 0, 8, 'None', 0),
(162, 28, 1, 0, 1, 0, 'RedirectorPage', '2015-03-17 20:11:10', '2015-03-17 20:11:10', 'new-redirector-page', 'New Redirector Page', NULL, NULL, NULL, NULL, 1, 1, 6, 0, 1, NULL, 'Inherit', 'Inherit', 0, 8, 'None', 0),
(163, 28, 2, 1, 1, 1, 'RedirectorPage', '2015-03-17 20:11:10', '2015-03-17 20:11:36', '404-error-page', '404 Error Page', NULL, NULL, NULL, NULL, 1, 1, 6, 0, 0, NULL, 'Inherit', 'Inherit', 0, 8, 'None', 0),
(164, 9, 6, 1, 1, 1, 'PortfolioPage', '2015-01-27 09:45:10', '2015-03-18 18:57:37', 'portfolio', 'Portfolio', NULL, '<p class="text-danger"><span style="font-size: medium;">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris nec velit consequat, pharetra risus et, tempus mi.</span></p>', NULL, NULL, 1, 1, 3, 0, 0, NULL, 'Inherit', 'Inherit', 0, 0, 'None', 0),
(165, 9, 7, 1, 1, 1, 'PortfolioPage', '2015-01-27 09:45:10', '2015-03-18 18:58:36', 'portfolio', 'Portfolio', NULL, '<h5 class="text-red" style="text-align: center;">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris nec velit consequat, pharetra risus et, tempus mi.</h5>', NULL, NULL, 1, 1, 3, 0, 0, NULL, 'Inherit', 'Inherit', 0, 0, 'None', 0),
(172, 4, 4, 1, 1, 1, 'Blog', '2015-01-26 04:46:26', '2015-03-18 20:59:22', 'blog', 'Blog', NULL, NULL, NULL, NULL, 1, 1, 4, 0, 0, NULL, 'Inherit', 'Inherit', 0, 0, 'None', 0),
(173, 4, 5, 1, 1, 1, 'Blog', '2015-01-26 04:46:26', '2015-03-18 21:45:13', 'blog', 'Blog', NULL, NULL, NULL, NULL, 1, 1, 4, 0, 0, NULL, 'Inherit', 'Inherit', 0, 0, 'None', 0),
(174, 4, 6, 1, 1, 1, 'Blog', '2015-01-26 04:46:26', '2015-03-18 21:45:32', 'blog', 'Blog', NULL, NULL, NULL, NULL, 1, 1, 4, 0, 0, NULL, 'Inherit', 'Inherit', 0, 0, 'None', 0),
(176, 11, 4, 1, 1, 1, 'PortfolioItem', '2015-01-28 20:07:31', '2015-03-19 09:58:40', 'portfolio-item-2', 'Portfolio Item #2', NULL, '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec id urna dui. Donec venenatis eleifend convallis. Sed tellus urna, tempus eu laoreet eget, sollicitudin porta lectus. Donec iaculis, est ut adipiscing cursus, lectus turpis tristique massa, faucibus faucibus urna odio nec ante. Integer magna purus, tincidunt ut vestibulum eget, mattis sit amet purus. Donec interdum orci nec felis pulvinar hendrerit. Donec suscipit turpis et libero fermentum non venenatis massa eleifend. Maecenas fringilla consectetur risus vel venenatis. Sed tincidunt tellus sit amet tellus mattis a malesuada dui vulputate. Aenean ut orci metus, vitae bibendum diam. Aliquam sit amet leo sed est convallis blandit vel sed libero. Integer leo nisi, viverra sit amet congue in, suscipit ac orci. Ut ut nulla at nulla posuere rutrum. Etiam cursus ultricies placerat. Praesent eu tellus nec enim pulvinar porta. Maecenas faucibus interdum turpis, sed rhoncus ante luctus vel. Duis ut orci nec metus lobortis commodo. Donec aliquet, leo non vestibulum dictum, ante justo molestie leo, id eleifend diam odio nec tellus. Cras consequat nunc a quam interdum luctus mollis velit viverra.</p>', NULL, NULL, 1, 1, 1, 0, 0, NULL, 'Inherit', 'Inherit', 0, 9, 'None', 0);

-- --------------------------------------------------------

--
-- Table structure for table `SiteTree_ViewerGroups`
--

CREATE TABLE IF NOT EXISTS `SiteTree_ViewerGroups` (
`ID` int(11) NOT NULL,
  `SiteTreeID` int(11) NOT NULL DEFAULT '0',
  `GroupID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `SubmittedFileField`
--

CREATE TABLE IF NOT EXISTS `SubmittedFileField` (
`ID` int(11) NOT NULL,
  `UploadedFileID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `SubmittedForm`
--

CREATE TABLE IF NOT EXISTS `SubmittedForm` (
`ID` int(11) NOT NULL,
  `ClassName` enum('SubmittedForm') CHARACTER SET utf8 DEFAULT 'SubmittedForm',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `SubmittedByID` int(11) NOT NULL DEFAULT '0',
  `ParentID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `SubmittedFormField`
--

CREATE TABLE IF NOT EXISTS `SubmittedFormField` (
`ID` int(11) NOT NULL,
  `ClassName` enum('SubmittedFormField','SubmittedFileField') CHARACTER SET utf8 DEFAULT 'SubmittedFormField',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `Name` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `Value` mediumtext CHARACTER SET utf8,
  `Title` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `ParentID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `TagCloudWidget`
--

CREATE TABLE IF NOT EXISTS `TagCloudWidget` (
`ID` int(11) NOT NULL,
  `Title` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `Limit` int(11) NOT NULL DEFAULT '0',
  `Sortby` varchar(50) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `TeamPerson`
--

CREATE TABLE IF NOT EXISTS `TeamPerson` (
`ID` int(11) NOT NULL,
  `ClassName` enum('TeamPerson') CHARACTER SET utf8 DEFAULT 'TeamPerson',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `Name` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `JobTitle` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Bio` mediumtext CHARACTER SET utf8,
  `SortOrder` int(11) NOT NULL DEFAULT '0',
  `PhotoID` int(11) NOT NULL DEFAULT '0',
  `PageID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `TeamPerson`
--

INSERT INTO `TeamPerson` (`ID`, `ClassName`, `Created`, `LastEdited`, `Name`, `JobTitle`, `Bio`, `SortOrder`, `PhotoID`, `PageID`) VALUES
(1, 'TeamPerson', '2015-03-02 04:55:50', '2015-03-02 04:55:50', 'Bill Door', 'Founder / CEO', 'Morbi a massa ac tortor pulvinar cursus. Maecenas lobortis dapibus nibh ut malesuada. Mauris posuere semper nisi. ', 1, 27, 2),
(2, 'TeamPerson', '2015-03-02 04:57:14', '2015-03-02 04:57:14', 'Steve McCain', 'COO', 'Morbi a massa ac tortor pulvinar cursus. Maecenas lobortis dapibus nibh ut malesuada. Mauris posuere semper nisi. ', 2, 28, 2),
(3, 'TeamPerson', '2015-03-02 04:58:44', '2015-03-02 04:58:44', 'Natalia Vodianova', 'SEO Specialist', 'Morbi a massa ac tortor pulvinar cursus. Maecenas lobortis dapibus nibh ut malesuada. Mauris posuere semper nisi. ', 3, 29, 2);

-- --------------------------------------------------------

--
-- Table structure for table `Testimonial`
--

CREATE TABLE IF NOT EXISTS `Testimonial` (
`ID` int(11) NOT NULL,
  `ClassName` enum('Testimonial') CHARACTER SET utf8 DEFAULT 'Testimonial',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `Author` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Company` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Title` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Comment` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Date` datetime DEFAULT NULL,
  `PhotoID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Testimonial`
--

INSERT INTO `Testimonial` (`ID`, `ClassName`, `Created`, `LastEdited`, `Author`, `Company`, `Title`, `Comment`, `Date`, `PhotoID`) VALUES
(1, 'Testimonial', '2015-03-02 05:01:47', '2015-03-02 16:44:02', 'Peter', 'Peter & Friends INC', 'Amazing work', 'Aliquam dignissim neque est, eget molestie leo bibendum eget. Sed ligula enim, dignissim vitae porttitor eget, tristique non est. ', '2015-02-01 00:00:00', 32),
(2, 'Testimonial', '2015-03-02 05:02:47', '2015-03-02 16:44:02', 'John', 'John & Brothers LLC', 'Great User Experience', 'Aliquam dignissim neque est, eget molestie leo bibendum eget. Sed ligula enim, dignissim vitae porttitor eget, tristique non est. ', '2015-01-01 00:00:00', 33),
(3, 'Testimonial', '2015-03-02 10:54:40', '2015-03-02 16:44:02', 'Jack', 'Kenedy Production Ltd', 'Great job', 'Nullam pharetra augue dapibus quam porttitor, vitae tincidunt ante fringilla. Phasellus semper sit amet leo vitae porttitor. Donec malesuada bibendum quam id eleifend. Proin bibendum iaculis neque non ultrices. In et turpis vitae ipsum vulputate mattis tu', '2015-02-01 00:00:00', 0),
(4, 'Testimonial', '2015-03-02 17:32:08', '2015-03-02 17:32:08', 'Hattori Suzuki', 'Suzuki Motor Ltd', 'Hello', 'Vivamus ultricies accumsan est in accumsan. Praesent nec faucibus urna. Nullam tempus augue in ante egestas, fermentum condimentum leo imperdiet. Integer felis odio, pretium ut velit ut, gravida fermentum arcu. Praesent nec nunc a dolor sollicitudin. ', '2015-02-02 00:00:00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `TimelineItem`
--

CREATE TABLE IF NOT EXISTS `TimelineItem` (
`ID` int(11) NOT NULL,
  `ShortDescription` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Date` datetime DEFAULT NULL,
  `Links` mediumtext CHARACTER SET utf8
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `TimelineItem`
--

INSERT INTO `TimelineItem` (`ID`, `ShortDescription`, `Date`, `Links`) VALUES
(17, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam id ipsum varius, tincidunt odio nec, placerat enim. ', '2014-12-30 18:05:54', '{"scenario":"timeline_link","enable":true,"heading":"","items":{"hycrce":{"Text":"Button","Link":"#","LinkBehaviour":"0","HTMLClass":"btn btn-primary"},"x2h120":{"Text":"Google","Link":"https://google.com","LinkBehaviour":"3","HTMLClass":"btn btn-red"}}}'),
(18, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam id ipsum varius, tincidunt odio nec, placerat enim. ', '2015-02-10 18:05:54', '{"scenario":"timeline_link","enable":true,"heading":"","items":{"x2h120":{"Text":"Bing","Link":"https://bing.com","LinkBehaviour":"3","HTMLClass":"btn btn-blue"}}}'),
(19, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam id ipsum varius, tincidunt odio nec, placerat enim. ', '2015-03-10 18:05:54', '{"scenario":"timeline_link","enable":true,"heading":"","items":{}}');

-- --------------------------------------------------------

--
-- Table structure for table `TimelineItem_Live`
--

CREATE TABLE IF NOT EXISTS `TimelineItem_Live` (
`ID` int(11) NOT NULL,
  `ShortDescription` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Date` datetime DEFAULT NULL,
  `Links` mediumtext CHARACTER SET utf8
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `TimelineItem_Live`
--

INSERT INTO `TimelineItem_Live` (`ID`, `ShortDescription`, `Date`, `Links`) VALUES
(17, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam id ipsum varius, tincidunt odio nec, placerat enim. ', '2014-12-30 18:05:54', '{"scenario":"timeline_link","enable":true,"heading":"","items":{"hycrce":{"Text":"Button","Link":"#","LinkBehaviour":"0","HTMLClass":"btn btn-primary"},"x2h120":{"Text":"Google","Link":"https://google.com","LinkBehaviour":"3","HTMLClass":"btn btn-red"}}}'),
(18, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam id ipsum varius, tincidunt odio nec, placerat enim. ', '2015-02-10 18:05:54', '{"scenario":"timeline_link","enable":true,"heading":"","items":{"x2h120":{"Text":"Bing","Link":"https://bing.com","LinkBehaviour":"3","HTMLClass":"btn btn-blue"}}}'),
(19, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam id ipsum varius, tincidunt odio nec, placerat enim. ', '2015-03-10 18:05:54', '{"scenario":"timeline_link","enable":true,"heading":"","items":{}}');

-- --------------------------------------------------------

--
-- Table structure for table `TimelineItem_versions`
--

CREATE TABLE IF NOT EXISTS `TimelineItem_versions` (
`ID` int(11) NOT NULL,
  `RecordID` int(11) NOT NULL DEFAULT '0',
  `Version` int(11) NOT NULL DEFAULT '0',
  `ShortDescription` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `Date` datetime DEFAULT NULL,
  `Links` mediumtext CHARACTER SET utf8
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `TimelineItem_versions`
--

INSERT INTO `TimelineItem_versions` (`ID`, `RecordID`, `Version`, `ShortDescription`, `Date`, `Links`) VALUES
(1, 17, 1, NULL, '2015-02-08 18:05:54', NULL),
(6, 18, 1, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam id ipsum varius, tincidunt odio nec, placerat enim. ', '2015-02-10 18:05:54', '{"scenario":"timeline_link","enable":true,"heading":"","items":{"x2h120":{"Text":"Google","Link":"https://google.com","LinkBehavior":"3"}}}'),
(10, 17, 8, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam id ipsum varius, tincidunt odio nec, placerat enim. ', '2014-12-30 18:05:54', '{"scenario":"timeline_link","enable":true,"heading":"","items":{"x2h120":{"Text":"Google","Link":"https://google.com","LinkBehaviour":"3","HTMLClass":"btn btn-red"}}}'),
(11, 18, 2, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam id ipsum varius, tincidunt odio nec, placerat enim. ', '2015-02-10 18:05:54', '{"scenario":"timeline_link","enable":false,"heading":"","items":{"x2h120":{"Text":"Google","Link":"https://google.com","LinkBehaviour":"0","HTMLClass":""}}}'),
(7, 19, 1, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam id ipsum varius, tincidunt odio nec, placerat enim. ', '2015-02-10 18:05:54', '{"scenario":"timeline_link","enable":true,"heading":"","items":{"x2h120":{"Text":"Google","Link":"https://google.com","LinkBehavior":"3"}}}'),
(15, 17, 10, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam id ipsum varius, tincidunt odio nec, placerat enim. ', '2014-12-30 18:05:54', '{"scenario":"timeline_link","enable":true,"heading":"","items":{"hycrce":{"Text":"Button","Link":"#","LinkBehaviour":"0","HTMLClass":"btn btn-primary"},"x2h120":{"Text":"Google","Link":"https://google.com","LinkBehaviour":"3","HTMLClass":"btn btn-red"}}}'),
(12, 19, 2, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam id ipsum varius, tincidunt odio nec, placerat enim. ', '2015-02-10 18:05:54', '{"scenario":"timeline_link","enable":true,"heading":"","items":{}}'),
(13, 18, 3, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam id ipsum varius, tincidunt odio nec, placerat enim. ', '2015-02-10 18:05:54', '{"scenario":"timeline_link","enable":true,"heading":"","items":{"x2h120":{"Text":"Bing","Link":"https://bing.com","LinkBehaviour":"3","HTMLClass":"btn btn-blue"}}}'),
(14, 17, 9, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam id ipsum varius, tincidunt odio nec, placerat enim. ', '2014-12-30 18:05:54', '{"scenario":"timeline_link","enable":true,"heading":"","items":{"hycrce":{"Text":"Button","Link":"#","LinkBehaviour":"0","HTMLClass":"btn"},"x2h120":{"Text":"Google","Link":"https://google.com","LinkBehaviour":"3","HTMLClass":"btn btn-red"}}}'),
(16, 19, 3, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam id ipsum varius, tincidunt odio nec, placerat enim. ', '2015-03-10 18:05:54', '{"scenario":"timeline_link","enable":true,"heading":"","items":{}}');

-- --------------------------------------------------------

--
-- Table structure for table `TimelinePage`
--

CREATE TABLE IF NOT EXISTS `TimelinePage` (
`ID` int(11) NOT NULL,
  `ParentID` int(11) NOT NULL DEFAULT '0',
  `PageLength` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `TimelinePage`
--

INSERT INTO `TimelinePage` (`ID`, `ParentID`, `PageLength`) VALUES
(16, 0, 30);

-- --------------------------------------------------------

--
-- Table structure for table `TimelinePage_Live`
--

CREATE TABLE IF NOT EXISTS `TimelinePage_Live` (
`ID` int(11) NOT NULL,
  `ParentID` int(11) NOT NULL DEFAULT '0',
  `PageLength` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `TimelinePage_Live`
--

INSERT INTO `TimelinePage_Live` (`ID`, `ParentID`, `PageLength`) VALUES
(16, 8, 30);

-- --------------------------------------------------------

--
-- Table structure for table `TimelinePage_versions`
--

CREATE TABLE IF NOT EXISTS `TimelinePage_versions` (
`ID` int(11) NOT NULL,
  `RecordID` int(11) NOT NULL DEFAULT '0',
  `Version` int(11) NOT NULL DEFAULT '0',
  `ParentID` int(11) NOT NULL DEFAULT '0',
  `PageLength` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `TimelinePage_versions`
--

INSERT INTO `TimelinePage_versions` (`ID`, `RecordID`, `Version`, `ParentID`, `PageLength`) VALUES
(1, 16, 3, 0, 30),
(2, 16, 4, 0, 30);

-- --------------------------------------------------------

--
-- Table structure for table `UserDefinedForm`
--

CREATE TABLE IF NOT EXISTS `UserDefinedForm` (
`ID` int(11) NOT NULL,
  `SubmitButtonText` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `ClearButtonText` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `OnCompleteMessage` mediumtext CHARACTER SET utf8,
  `ShowClearButton` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `DisableSaveSubmissions` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `EnableLiveValidation` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `HideFieldLabels` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `DisableAuthenicatedFinishAction` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `DisableCsrfSecurityToken` tinyint(1) unsigned NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `UserDefinedForm`
--

INSERT INTO `UserDefinedForm` (`ID`, `SubmitButtonText`, `ClearButtonText`, `OnCompleteMessage`, `ShowClearButton`, `DisableSaveSubmissions`, `EnableLiveValidation`, `HideFieldLabels`, `DisableAuthenicatedFinishAction`, `DisableCsrfSecurityToken`) VALUES
(3, 'Send It', NULL, '<p>You are very important to us, all information received will always remain confidential. We will contact you as soon as we review your message.</p>', 0, 0, 0, 1, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `UserDefinedForm_EmailRecipient`
--

CREATE TABLE IF NOT EXISTS `UserDefinedForm_EmailRecipient` (
`ID` int(11) NOT NULL,
  `ClassName` enum('UserDefinedForm_EmailRecipient') CHARACTER SET utf8 DEFAULT 'UserDefinedForm_EmailRecipient',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `EmailAddress` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `EmailSubject` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `EmailFrom` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `EmailReplyTo` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `EmailBody` mediumtext CHARACTER SET utf8,
  `SendPlain` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `HideFormData` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `FormID` int(11) NOT NULL DEFAULT '0',
  `SendEmailFromFieldID` int(11) NOT NULL DEFAULT '0',
  `SendEmailToFieldID` int(11) NOT NULL DEFAULT '0',
  `SendEmailSubjectFieldID` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `UserDefinedForm_Live`
--

CREATE TABLE IF NOT EXISTS `UserDefinedForm_Live` (
`ID` int(11) NOT NULL,
  `SubmitButtonText` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `ClearButtonText` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `OnCompleteMessage` mediumtext CHARACTER SET utf8,
  `ShowClearButton` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `DisableSaveSubmissions` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `EnableLiveValidation` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `HideFieldLabels` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `DisableAuthenicatedFinishAction` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `DisableCsrfSecurityToken` tinyint(1) unsigned NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `UserDefinedForm_Live`
--

INSERT INTO `UserDefinedForm_Live` (`ID`, `SubmitButtonText`, `ClearButtonText`, `OnCompleteMessage`, `ShowClearButton`, `DisableSaveSubmissions`, `EnableLiveValidation`, `HideFieldLabels`, `DisableAuthenicatedFinishAction`, `DisableCsrfSecurityToken`) VALUES
(3, 'Send It', NULL, '<p>You are very important to us, all information received will always remain confidential. We will contact you as soon as we review your message.</p>', 0, 0, 0, 1, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `UserDefinedForm_versions`
--

CREATE TABLE IF NOT EXISTS `UserDefinedForm_versions` (
`ID` int(11) NOT NULL,
  `RecordID` int(11) NOT NULL DEFAULT '0',
  `Version` int(11) NOT NULL DEFAULT '0',
  `SubmitButtonText` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `ClearButtonText` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `OnCompleteMessage` mediumtext CHARACTER SET utf8,
  `ShowClearButton` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `DisableSaveSubmissions` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `EnableLiveValidation` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `HideFieldLabels` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `DisableAuthenicatedFinishAction` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `DisableCsrfSecurityToken` tinyint(1) unsigned NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `UserDefinedForm_versions`
--

INSERT INTO `UserDefinedForm_versions` (`ID`, `RecordID`, `Version`, `SubmitButtonText`, `ClearButtonText`, `OnCompleteMessage`, `ShowClearButton`, `DisableSaveSubmissions`, `EnableLiveValidation`, `HideFieldLabels`, `DisableAuthenicatedFinishAction`, `DisableCsrfSecurityToken`) VALUES
(6, 3, 10, 'Send It', NULL, '<p>You are very important to us, all information received will always remain confidential. We will contact you as soon as we review your message.</p>', 0, 0, 0, 0, 0, 0),
(7, 3, 11, 'Send It', NULL, '<p>You are very important to us, all information received will always remain confidential. We will contact you as soon as we review your message.</p>', 0, 0, 0, 0, 0, 0),
(8, 3, 12, 'Send It', NULL, '<p>You are very important to us, all information received will always remain confidential. We will contact you as soon as we review your message.</p>', 0, 0, 0, 1, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `VirtualPage`
--

CREATE TABLE IF NOT EXISTS `VirtualPage` (
`ID` int(11) NOT NULL,
  `VersionID` int(11) NOT NULL DEFAULT '0',
  `CopyContentFromID` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `VirtualPage_Live`
--

CREATE TABLE IF NOT EXISTS `VirtualPage_Live` (
`ID` int(11) NOT NULL,
  `VersionID` int(11) NOT NULL DEFAULT '0',
  `CopyContentFromID` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `VirtualPage_versions`
--

CREATE TABLE IF NOT EXISTS `VirtualPage_versions` (
`ID` int(11) NOT NULL,
  `RecordID` int(11) NOT NULL DEFAULT '0',
  `Version` int(11) NOT NULL DEFAULT '0',
  `VersionID` int(11) NOT NULL DEFAULT '0',
  `CopyContentFromID` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Widget`
--

CREATE TABLE IF NOT EXISTS `Widget` (
`ID` int(11) NOT NULL,
  `ClassName` enum('Widget','BlogArchiveWidget','ArchiveWidget','BlogCategoriesWidget','BlogRecentPostsWidget','BlogTagsWidget','TagCloudWidget','BlogEntryWidget','HTMLContentWidget','PageLinkWidget') CHARACTER SET utf8 DEFAULT 'Widget',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL,
  `Sort` int(11) NOT NULL DEFAULT '0',
  `Enabled` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ParentID` int(11) NOT NULL DEFAULT '0',
  `WidgetTitle` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `WidgetClassSuffix` varchar(60) CHARACTER SET utf8 DEFAULT NULL,
  `WidgetContent` mediumtext CHARACTER SET utf8,
  `Title` varchar(255) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Widget`
--

INSERT INTO `Widget` (`ID`, `ClassName`, `Created`, `LastEdited`, `Sort`, `Enabled`, `ParentID`, `WidgetTitle`, `WidgetClassSuffix`, `WidgetContent`, `Title`) VALUES
(1, 'HTMLContentWidget', '2015-03-06 20:11:01', '2015-03-06 21:17:29', 0, 1, 15, 'Recent Tweets', 'recent-tweets', '<a class="twitter-timeline" height="250" href="https://twitter.com/twitterdev" data-widget-id="243046062967885824" data-chrome="noheader nofooter noborders transparent" data-link-color="#838383" data-tweet-limit="2">Tweets by @twitterdev</a>', NULL),
(2, 'PageLinkWidget', '2015-03-06 20:20:28', '2015-03-06 21:17:29', 0, 1, 15, 'Quick Links', NULL, '4,2,3,16,9', NULL),
(3, 'HTMLContentWidget', '2015-03-06 20:21:45', '2015-03-06 21:17:29', 0, 1, 15, 'Contact Us', NULL, '<p>Do not hesitate to contact us if you have any questions or feature requests:</p>\r\n<p>\r\nSan Francisco, CA 94101<br/>\r\n1987 Lincoln Street<br/>\r\nPhone: +0 000 000 00 00<br/>\r\nFax: +0 000 000 00 00<br/>\r\n</p>', NULL),
(4, 'BlogCategoriesWidget', '2015-03-18 20:59:22', '2015-03-18 21:12:40', 0, 1, 18, 'Categories', NULL, NULL, 'Categories'),
(5, 'BlogEntryWidget', '2015-03-18 21:12:40', '2015-03-18 21:12:40', 1, 1, 18, 'Top stories', NULL, NULL, 'Blog Entries');

-- --------------------------------------------------------

--
-- Table structure for table `WidgetArea`
--

CREATE TABLE IF NOT EXISTS `WidgetArea` (
`ID` int(11) NOT NULL,
  `ClassName` enum('WidgetArea') CHARACTER SET utf8 DEFAULT 'WidgetArea',
  `Created` datetime DEFAULT NULL,
  `LastEdited` datetime DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `WidgetArea`
--

INSERT INTO `WidgetArea` (`ID`, `ClassName`, `Created`, `LastEdited`) VALUES
(1, 'WidgetArea', '2015-01-29 04:42:34', '2015-01-29 04:42:34'),
(2, 'WidgetArea', '2015-01-29 04:42:34', '2015-01-29 04:42:34'),
(3, 'WidgetArea', '2015-01-29 04:48:37', '2015-01-29 04:48:37'),
(4, 'WidgetArea', '2015-01-29 04:48:37', '2015-01-29 04:48:37'),
(5, 'WidgetArea', '2015-01-29 04:50:39', '2015-01-29 04:50:39'),
(6, 'WidgetArea', '2015-01-29 04:50:39', '2015-01-29 04:50:39'),
(7, 'WidgetArea', '2015-01-29 04:50:39', '2015-01-29 04:56:12'),
(8, 'WidgetArea', '2015-01-29 04:50:39', '2015-01-29 04:56:13'),
(9, 'WidgetArea', '2015-01-29 04:50:39', '2015-01-29 04:57:05'),
(10, 'WidgetArea', '2015-01-29 04:50:39', '2015-01-29 04:57:05'),
(11, 'WidgetArea', '2015-02-10 11:44:15', '2015-02-10 11:44:15'),
(12, 'WidgetArea', '2015-02-10 11:44:15', '2015-02-10 11:44:15'),
(13, 'WidgetArea', '2015-02-10 11:44:15', '2015-02-10 11:44:48'),
(14, 'WidgetArea', '2015-02-10 11:44:15', '2015-02-10 11:44:48'),
(15, 'WidgetArea', '2015-03-06 20:07:14', '2015-03-06 20:07:14'),
(16, 'WidgetArea', '2015-03-14 13:32:21', '2015-03-14 13:32:21'),
(17, 'WidgetArea', '2015-03-18 20:26:57', '2015-03-18 20:26:57'),
(18, 'WidgetArea', '2015-03-18 20:59:22', '2015-03-18 20:59:22');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `AboutPage`
--
ALTER TABLE `AboutPage`
 ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `AboutPage_Live`
--
ALTER TABLE `AboutPage_Live`
 ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `AboutPage_Testimonials`
--
ALTER TABLE `AboutPage_Testimonials`
 ADD PRIMARY KEY (`ID`), ADD KEY `AboutPageID` (`AboutPageID`), ADD KEY `TestimonialID` (`TestimonialID`);

--
-- Indexes for table `AboutPage_versions`
--
ALTER TABLE `AboutPage_versions`
 ADD PRIMARY KEY (`ID`), ADD UNIQUE KEY `RecordID_Version` (`RecordID`,`Version`), ADD KEY `RecordID` (`RecordID`), ADD KEY `Version` (`Version`);

--
-- Indexes for table `ArchiveWidget`
--
ALTER TABLE `ArchiveWidget`
 ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `BannerSlider`
--
ALTER TABLE `BannerSlider`
 ADD PRIMARY KEY (`ID`), ADD KEY `ImageID` (`ImageID`), ADD KEY `PageID` (`PageID`), ADD KEY `ClassName` (`ClassName`);

--
-- Indexes for table `Blog`
--
ALTER TABLE `Blog`
 ADD PRIMARY KEY (`ID`), ADD KEY `ParentID` (`ParentID`);

--
-- Indexes for table `BlogArchiveWidget`
--
ALTER TABLE `BlogArchiveWidget`
 ADD PRIMARY KEY (`ID`), ADD KEY `BlogID` (`BlogID`);

--
-- Indexes for table `BlogCategoriesWidget`
--
ALTER TABLE `BlogCategoriesWidget`
 ADD PRIMARY KEY (`ID`), ADD KEY `BlogID` (`BlogID`);

--
-- Indexes for table `BlogCategory`
--
ALTER TABLE `BlogCategory`
 ADD PRIMARY KEY (`ID`), ADD KEY `PageID` (`PageID`), ADD KEY `ClassName` (`ClassName`), ADD KEY `BlogID` (`BlogID`);

--
-- Indexes for table `BlogCategory_Entries`
--
ALTER TABLE `BlogCategory_Entries`
 ADD PRIMARY KEY (`ID`), ADD KEY `BlogCategoryID` (`BlogCategoryID`), ADD KEY `BlogEntryID` (`BlogEntryID`);

--
-- Indexes for table `BlogEntry`
--
ALTER TABLE `BlogEntry`
 ADD PRIMARY KEY (`ID`), ADD KEY `ThumbnailID` (`ThumbnailID`);

--
-- Indexes for table `BlogEntryWidget`
--
ALTER TABLE `BlogEntryWidget`
 ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `BlogEntry_Live`
--
ALTER TABLE `BlogEntry_Live`
 ADD PRIMARY KEY (`ID`), ADD KEY `ThumbnailID` (`ThumbnailID`);

--
-- Indexes for table `BlogEntry_versions`
--
ALTER TABLE `BlogEntry_versions`
 ADD PRIMARY KEY (`ID`), ADD UNIQUE KEY `RecordID_Version` (`RecordID`,`Version`), ADD KEY `RecordID` (`RecordID`), ADD KEY `Version` (`Version`), ADD KEY `ThumbnailID` (`ThumbnailID`);

--
-- Indexes for table `BlogHolder`
--
ALTER TABLE `BlogHolder`
 ADD PRIMARY KEY (`ID`), ADD KEY `OwnerID` (`OwnerID`);

--
-- Indexes for table `BlogHolder_Live`
--
ALTER TABLE `BlogHolder_Live`
 ADD PRIMARY KEY (`ID`), ADD KEY `OwnerID` (`OwnerID`);

--
-- Indexes for table `BlogHolder_versions`
--
ALTER TABLE `BlogHolder_versions`
 ADD PRIMARY KEY (`ID`), ADD UNIQUE KEY `RecordID_Version` (`RecordID`,`Version`), ADD KEY `RecordID` (`RecordID`), ADD KEY `Version` (`Version`), ADD KEY `OwnerID` (`OwnerID`);

--
-- Indexes for table `BlogPost`
--
ALTER TABLE `BlogPost`
 ADD PRIMARY KEY (`ID`), ADD KEY `FeaturedImageID` (`FeaturedImageID`);

--
-- Indexes for table `BlogPost_Authors`
--
ALTER TABLE `BlogPost_Authors`
 ADD PRIMARY KEY (`ID`), ADD KEY `BlogPostID` (`BlogPostID`), ADD KEY `MemberID` (`MemberID`);

--
-- Indexes for table `BlogPost_Categories`
--
ALTER TABLE `BlogPost_Categories`
 ADD PRIMARY KEY (`ID`), ADD KEY `BlogPostID` (`BlogPostID`), ADD KEY `BlogCategoryID` (`BlogCategoryID`);

--
-- Indexes for table `BlogPost_Live`
--
ALTER TABLE `BlogPost_Live`
 ADD PRIMARY KEY (`ID`), ADD KEY `FeaturedImageID` (`FeaturedImageID`);

--
-- Indexes for table `BlogPost_Tags`
--
ALTER TABLE `BlogPost_Tags`
 ADD PRIMARY KEY (`ID`), ADD KEY `BlogPostID` (`BlogPostID`), ADD KEY `BlogTagID` (`BlogTagID`);

--
-- Indexes for table `BlogPost_versions`
--
ALTER TABLE `BlogPost_versions`
 ADD PRIMARY KEY (`ID`), ADD UNIQUE KEY `RecordID_Version` (`RecordID`,`Version`), ADD KEY `RecordID` (`RecordID`), ADD KEY `Version` (`Version`), ADD KEY `FeaturedImageID` (`FeaturedImageID`);

--
-- Indexes for table `BlogRecentPostsWidget`
--
ALTER TABLE `BlogRecentPostsWidget`
 ADD PRIMARY KEY (`ID`), ADD KEY `BlogID` (`BlogID`);

--
-- Indexes for table `BlogTag`
--
ALTER TABLE `BlogTag`
 ADD PRIMARY KEY (`ID`), ADD KEY `BlogID` (`BlogID`), ADD KEY `ClassName` (`ClassName`);

--
-- Indexes for table `BlogTagsWidget`
--
ALTER TABLE `BlogTagsWidget`
 ADD PRIMARY KEY (`ID`), ADD KEY `BlogID` (`BlogID`);

--
-- Indexes for table `BlogTree`
--
ALTER TABLE `BlogTree`
 ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `BlogTree_Live`
--
ALTER TABLE `BlogTree_Live`
 ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `BlogTree_versions`
--
ALTER TABLE `BlogTree_versions`
 ADD PRIMARY KEY (`ID`), ADD UNIQUE KEY `RecordID_Version` (`RecordID`,`Version`), ADD KEY `RecordID` (`RecordID`), ADD KEY `Version` (`Version`);

--
-- Indexes for table `Blog_Contributors`
--
ALTER TABLE `Blog_Contributors`
 ADD PRIMARY KEY (`ID`), ADD KEY `BlogID` (`BlogID`), ADD KEY `MemberID` (`MemberID`);

--
-- Indexes for table `Blog_Editors`
--
ALTER TABLE `Blog_Editors`
 ADD PRIMARY KEY (`ID`), ADD KEY `BlogID` (`BlogID`), ADD KEY `MemberID` (`MemberID`);

--
-- Indexes for table `Blog_Live`
--
ALTER TABLE `Blog_Live`
 ADD PRIMARY KEY (`ID`), ADD KEY `ParentID` (`ParentID`);

--
-- Indexes for table `Blog_versions`
--
ALTER TABLE `Blog_versions`
 ADD PRIMARY KEY (`ID`), ADD UNIQUE KEY `RecordID_Version` (`RecordID`,`Version`), ADD KEY `RecordID` (`RecordID`), ADD KEY `Version` (`Version`), ADD KEY `ParentID` (`ParentID`);

--
-- Indexes for table `Blog_Writers`
--
ALTER TABLE `Blog_Writers`
 ADD PRIMARY KEY (`ID`), ADD KEY `BlogID` (`BlogID`), ADD KEY `MemberID` (`MemberID`);

--
-- Indexes for table `Box`
--
ALTER TABLE `Box`
 ADD PRIMARY KEY (`ID`), ADD KEY `PageID` (`PageID`), ADD KEY `ClassName` (`ClassName`);

--
-- Indexes for table `Comment`
--
ALTER TABLE `Comment`
 ADD PRIMARY KEY (`ID`), ADD KEY `AuthorID` (`AuthorID`), ADD KEY `ClassName` (`ClassName`), ADD KEY `ParentCommentID` (`ParentCommentID`);

--
-- Indexes for table `ContactAttribute`
--
ALTER TABLE `ContactAttribute`
 ADD PRIMARY KEY (`ID`), ADD KEY `PageID` (`PageID`), ADD KEY `ClassName` (`ClassName`);

--
-- Indexes for table `ContactPage`
--
ALTER TABLE `ContactPage`
 ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `ContactPage_Live`
--
ALTER TABLE `ContactPage_Live`
 ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `ContactPage_versions`
--
ALTER TABLE `ContactPage_versions`
 ADD PRIMARY KEY (`ID`), ADD UNIQUE KEY `RecordID_Version` (`RecordID`,`Version`), ADD KEY `RecordID` (`RecordID`), ADD KEY `Version` (`Version`);

--
-- Indexes for table `EditableFormField`
--
ALTER TABLE `EditableFormField`
 ADD PRIMARY KEY (`ID`), ADD KEY `ParentID` (`ParentID`), ADD KEY `ClassName` (`ClassName`);

--
-- Indexes for table `EditableFormField_Live`
--
ALTER TABLE `EditableFormField_Live`
 ADD PRIMARY KEY (`ID`), ADD KEY `ParentID` (`ParentID`), ADD KEY `ClassName` (`ClassName`);

--
-- Indexes for table `EditableFormField_versions`
--
ALTER TABLE `EditableFormField_versions`
 ADD PRIMARY KEY (`ID`), ADD KEY `RecordID_Version` (`RecordID`,`Version`), ADD KEY `RecordID` (`RecordID`), ADD KEY `Version` (`Version`), ADD KEY `AuthorID` (`AuthorID`), ADD KEY `PublisherID` (`PublisherID`), ADD KEY `ParentID` (`ParentID`), ADD KEY `ClassName` (`ClassName`);

--
-- Indexes for table `EditableOption`
--
ALTER TABLE `EditableOption`
 ADD PRIMARY KEY (`ID`), ADD KEY `ParentID` (`ParentID`), ADD KEY `ClassName` (`ClassName`);

--
-- Indexes for table `EditableOption_Live`
--
ALTER TABLE `EditableOption_Live`
 ADD PRIMARY KEY (`ID`), ADD KEY `ParentID` (`ParentID`), ADD KEY `ClassName` (`ClassName`);

--
-- Indexes for table `EditableOption_versions`
--
ALTER TABLE `EditableOption_versions`
 ADD PRIMARY KEY (`ID`), ADD KEY `RecordID_Version` (`RecordID`,`Version`), ADD KEY `RecordID` (`RecordID`), ADD KEY `Version` (`Version`), ADD KEY `AuthorID` (`AuthorID`), ADD KEY `PublisherID` (`PublisherID`), ADD KEY `ParentID` (`ParentID`), ADD KEY `ClassName` (`ClassName`);

--
-- Indexes for table `ErrorPage`
--
ALTER TABLE `ErrorPage`
 ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `ErrorPage_Live`
--
ALTER TABLE `ErrorPage_Live`
 ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `ErrorPage_versions`
--
ALTER TABLE `ErrorPage_versions`
 ADD PRIMARY KEY (`ID`), ADD UNIQUE KEY `RecordID_Version` (`RecordID`,`Version`), ADD KEY `RecordID` (`RecordID`), ADD KEY `Version` (`Version`);

--
-- Indexes for table `File`
--
ALTER TABLE `File`
 ADD PRIMARY KEY (`ID`), ADD KEY `ParentID` (`ParentID`), ADD KEY `OwnerID` (`OwnerID`), ADD KEY `ClassName` (`ClassName`), ADD FULLTEXT KEY `SearchFields` (`Filename`,`Title`,`Content`);

--
-- Indexes for table `Group`
--
ALTER TABLE `Group`
 ADD PRIMARY KEY (`ID`), ADD KEY `ParentID` (`ParentID`), ADD KEY `ClassName` (`ClassName`);

--
-- Indexes for table `Group_Members`
--
ALTER TABLE `Group_Members`
 ADD PRIMARY KEY (`ID`), ADD KEY `GroupID` (`GroupID`), ADD KEY `MemberID` (`MemberID`);

--
-- Indexes for table `Group_Roles`
--
ALTER TABLE `Group_Roles`
 ADD PRIMARY KEY (`ID`), ADD KEY `GroupID` (`GroupID`), ADD KEY `PermissionRoleID` (`PermissionRoleID`);

--
-- Indexes for table `HelpArticle`
--
ALTER TABLE `HelpArticle`
 ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `HelpArticle_Live`
--
ALTER TABLE `HelpArticle_Live`
 ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `HelpArticle_versions`
--
ALTER TABLE `HelpArticle_versions`
 ADD PRIMARY KEY (`ID`), ADD UNIQUE KEY `RecordID_Version` (`RecordID`,`Version`), ADD KEY `RecordID` (`RecordID`), ADD KEY `Version` (`Version`);

--
-- Indexes for table `HelpCategory`
--
ALTER TABLE `HelpCategory`
 ADD PRIMARY KEY (`ID`), ADD KEY `PageID` (`PageID`), ADD KEY `ClassName` (`ClassName`);

--
-- Indexes for table `HelpCategory_HelpArticles`
--
ALTER TABLE `HelpCategory_HelpArticles`
 ADD PRIMARY KEY (`ID`), ADD KEY `HelpCategoryID` (`HelpCategoryID`), ADD KEY `HelpArticleID` (`HelpArticleID`);

--
-- Indexes for table `HelpPage`
--
ALTER TABLE `HelpPage`
 ADD PRIMARY KEY (`ID`), ADD KEY `ParentID` (`ParentID`);

--
-- Indexes for table `HelpPage_Live`
--
ALTER TABLE `HelpPage_Live`
 ADD PRIMARY KEY (`ID`), ADD KEY `ParentID` (`ParentID`);

--
-- Indexes for table `HelpPage_versions`
--
ALTER TABLE `HelpPage_versions`
 ADD PRIMARY KEY (`ID`), ADD UNIQUE KEY `RecordID_Version` (`RecordID`,`Version`), ADD KEY `RecordID` (`RecordID`), ADD KEY `Version` (`Version`), ADD KEY `ParentID` (`ParentID`);

--
-- Indexes for table `HomePage`
--
ALTER TABLE `HomePage`
 ADD PRIMARY KEY (`ID`), ADD KEY `PortfolioPageID` (`PortfolioPageID`);

--
-- Indexes for table `HomePage_Live`
--
ALTER TABLE `HomePage_Live`
 ADD PRIMARY KEY (`ID`), ADD KEY `PortfolioPageID` (`PortfolioPageID`);

--
-- Indexes for table `HomePage_Testimonials`
--
ALTER TABLE `HomePage_Testimonials`
 ADD PRIMARY KEY (`ID`), ADD KEY `HomePageID` (`HomePageID`), ADD KEY `TestimonialID` (`TestimonialID`);

--
-- Indexes for table `HomePage_versions`
--
ALTER TABLE `HomePage_versions`
 ADD PRIMARY KEY (`ID`), ADD UNIQUE KEY `RecordID_Version` (`RecordID`,`Version`), ADD KEY `RecordID` (`RecordID`), ADD KEY `Version` (`Version`), ADD KEY `PortfolioPageID` (`PortfolioPageID`);

--
-- Indexes for table `Image`
--
ALTER TABLE `Image`
 ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `LoginAttempt`
--
ALTER TABLE `LoginAttempt`
 ADD PRIMARY KEY (`ID`), ADD KEY `MemberID` (`MemberID`), ADD KEY `ClassName` (`ClassName`);

--
-- Indexes for table `Member`
--
ALTER TABLE `Member`
 ADD PRIMARY KEY (`ID`), ADD KEY `Email` (`Email`), ADD KEY `ClassName` (`ClassName`), ADD KEY `PhotoID` (`PhotoID`), ADD KEY `BlogProfileImageID` (`BlogProfileImageID`);

--
-- Indexes for table `MemberPassword`
--
ALTER TABLE `MemberPassword`
 ADD PRIMARY KEY (`ID`), ADD KEY `MemberID` (`MemberID`), ADD KEY `ClassName` (`ClassName`);

--
-- Indexes for table `Page`
--
ALTER TABLE `Page`
 ADD PRIMARY KEY (`ID`), ADD KEY `SideBarID` (`SideBarID`);

--
-- Indexes for table `PageImage`
--
ALTER TABLE `PageImage`
 ADD PRIMARY KEY (`ID`), ADD KEY `PageID` (`PageID`);

--
-- Indexes for table `Page_Live`
--
ALTER TABLE `Page_Live`
 ADD PRIMARY KEY (`ID`), ADD KEY `SideBarID` (`SideBarID`);

--
-- Indexes for table `Page_versions`
--
ALTER TABLE `Page_versions`
 ADD PRIMARY KEY (`ID`), ADD UNIQUE KEY `RecordID_Version` (`RecordID`,`Version`), ADD KEY `RecordID` (`RecordID`), ADD KEY `Version` (`Version`), ADD KEY `SideBarID` (`SideBarID`);

--
-- Indexes for table `Permission`
--
ALTER TABLE `Permission`
 ADD PRIMARY KEY (`ID`), ADD KEY `GroupID` (`GroupID`), ADD KEY `Code` (`Code`), ADD KEY `ClassName` (`ClassName`);

--
-- Indexes for table `PermissionRole`
--
ALTER TABLE `PermissionRole`
 ADD PRIMARY KEY (`ID`), ADD KEY `ClassName` (`ClassName`);

--
-- Indexes for table `PermissionRoleCode`
--
ALTER TABLE `PermissionRoleCode`
 ADD PRIMARY KEY (`ID`), ADD KEY `RoleID` (`RoleID`), ADD KEY `ClassName` (`ClassName`);

--
-- Indexes for table `PortfolioCategory`
--
ALTER TABLE `PortfolioCategory`
 ADD PRIMARY KEY (`ID`), ADD KEY `PageID` (`PageID`), ADD KEY `ClassName` (`ClassName`);

--
-- Indexes for table `PortfolioCategory_PortfolioItems`
--
ALTER TABLE `PortfolioCategory_PortfolioItems`
 ADD PRIMARY KEY (`ID`), ADD KEY `PortfolioCategoryID` (`PortfolioCategoryID`), ADD KEY `PortfolioItemID` (`PortfolioItemID`);

--
-- Indexes for table `PortfolioItem`
--
ALTER TABLE `PortfolioItem`
 ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `PortfolioItem_Live`
--
ALTER TABLE `PortfolioItem_Live`
 ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `PortfolioItem_RelatedItems`
--
ALTER TABLE `PortfolioItem_RelatedItems`
 ADD PRIMARY KEY (`ID`), ADD KEY `PortfolioItemID` (`PortfolioItemID`), ADD KEY `ChildID` (`ChildID`);

--
-- Indexes for table `PortfolioItem_Testimonials`
--
ALTER TABLE `PortfolioItem_Testimonials`
 ADD PRIMARY KEY (`ID`), ADD KEY `PortfolioItemID` (`PortfolioItemID`), ADD KEY `TestimonialID` (`TestimonialID`);

--
-- Indexes for table `PortfolioItem_versions`
--
ALTER TABLE `PortfolioItem_versions`
 ADD PRIMARY KEY (`ID`), ADD UNIQUE KEY `RecordID_Version` (`RecordID`,`Version`), ADD KEY `RecordID` (`RecordID`), ADD KEY `Version` (`Version`);

--
-- Indexes for table `PortfolioPage`
--
ALTER TABLE `PortfolioPage`
 ADD PRIMARY KEY (`ID`), ADD KEY `ParentID` (`ParentID`);

--
-- Indexes for table `PortfolioPage_Live`
--
ALTER TABLE `PortfolioPage_Live`
 ADD PRIMARY KEY (`ID`), ADD KEY `ParentID` (`ParentID`);

--
-- Indexes for table `PortfolioPage_versions`
--
ALTER TABLE `PortfolioPage_versions`
 ADD PRIMARY KEY (`ID`), ADD UNIQUE KEY `RecordID_Version` (`RecordID`,`Version`), ADD KEY `RecordID` (`RecordID`), ADD KEY `Version` (`Version`), ADD KEY `ParentID` (`ParentID`);

--
-- Indexes for table `RedirectorPage`
--
ALTER TABLE `RedirectorPage`
 ADD PRIMARY KEY (`ID`), ADD KEY `LinkToID` (`LinkToID`);

--
-- Indexes for table `RedirectorPage_Live`
--
ALTER TABLE `RedirectorPage_Live`
 ADD PRIMARY KEY (`ID`), ADD KEY `LinkToID` (`LinkToID`);

--
-- Indexes for table `RedirectorPage_versions`
--
ALTER TABLE `RedirectorPage_versions`
 ADD PRIMARY KEY (`ID`), ADD UNIQUE KEY `RecordID_Version` (`RecordID`,`Version`), ADD KEY `RecordID` (`RecordID`), ADD KEY `Version` (`Version`), ADD KEY `LinkToID` (`LinkToID`);

--
-- Indexes for table `RSSWidget`
--
ALTER TABLE `RSSWidget`
 ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `SiteConfig`
--
ALTER TABLE `SiteConfig`
 ADD PRIMARY KEY (`ID`), ADD KEY `ClassName` (`ClassName`), ADD KEY `FooterWidgetID` (`FooterWidgetID`);

--
-- Indexes for table `SiteConfig_CreateTopLevelGroups`
--
ALTER TABLE `SiteConfig_CreateTopLevelGroups`
 ADD PRIMARY KEY (`ID`), ADD KEY `SiteConfigID` (`SiteConfigID`), ADD KEY `GroupID` (`GroupID`);

--
-- Indexes for table `SiteConfig_EditorGroups`
--
ALTER TABLE `SiteConfig_EditorGroups`
 ADD PRIMARY KEY (`ID`), ADD KEY `SiteConfigID` (`SiteConfigID`), ADD KEY `GroupID` (`GroupID`);

--
-- Indexes for table `SiteConfig_ViewerGroups`
--
ALTER TABLE `SiteConfig_ViewerGroups`
 ADD PRIMARY KEY (`ID`), ADD KEY `SiteConfigID` (`SiteConfigID`), ADD KEY `GroupID` (`GroupID`);

--
-- Indexes for table `SiteTree`
--
ALTER TABLE `SiteTree`
 ADD PRIMARY KEY (`ID`), ADD KEY `ParentID` (`ParentID`), ADD KEY `URLSegment` (`URLSegment`), ADD KEY `ClassName` (`ClassName`), ADD FULLTEXT KEY `SearchFields` (`Title`,`MenuTitle`,`Content`,`MetaDescription`);

--
-- Indexes for table `SiteTree_EditorGroups`
--
ALTER TABLE `SiteTree_EditorGroups`
 ADD PRIMARY KEY (`ID`), ADD KEY `SiteTreeID` (`SiteTreeID`), ADD KEY `GroupID` (`GroupID`);

--
-- Indexes for table `SiteTree_ImageTracking`
--
ALTER TABLE `SiteTree_ImageTracking`
 ADD PRIMARY KEY (`ID`), ADD KEY `SiteTreeID` (`SiteTreeID`), ADD KEY `FileID` (`FileID`);

--
-- Indexes for table `SiteTree_LinkTracking`
--
ALTER TABLE `SiteTree_LinkTracking`
 ADD PRIMARY KEY (`ID`), ADD KEY `SiteTreeID` (`SiteTreeID`), ADD KEY `ChildID` (`ChildID`);

--
-- Indexes for table `SiteTree_Live`
--
ALTER TABLE `SiteTree_Live`
 ADD PRIMARY KEY (`ID`), ADD KEY `ParentID` (`ParentID`), ADD KEY `URLSegment` (`URLSegment`), ADD KEY `ClassName` (`ClassName`), ADD FULLTEXT KEY `SearchFields` (`Title`,`MenuTitle`,`Content`,`MetaDescription`);

--
-- Indexes for table `SiteTree_versions`
--
ALTER TABLE `SiteTree_versions`
 ADD PRIMARY KEY (`ID`), ADD KEY `RecordID_Version` (`RecordID`,`Version`), ADD KEY `RecordID` (`RecordID`), ADD KEY `Version` (`Version`), ADD KEY `AuthorID` (`AuthorID`), ADD KEY `PublisherID` (`PublisherID`), ADD KEY `ParentID` (`ParentID`), ADD KEY `URLSegment` (`URLSegment`), ADD KEY `ClassName` (`ClassName`), ADD FULLTEXT KEY `SearchFields` (`Title`,`MenuTitle`,`Content`,`MetaDescription`);

--
-- Indexes for table `SiteTree_ViewerGroups`
--
ALTER TABLE `SiteTree_ViewerGroups`
 ADD PRIMARY KEY (`ID`), ADD KEY `SiteTreeID` (`SiteTreeID`), ADD KEY `GroupID` (`GroupID`);

--
-- Indexes for table `SubmittedFileField`
--
ALTER TABLE `SubmittedFileField`
 ADD PRIMARY KEY (`ID`), ADD KEY `UploadedFileID` (`UploadedFileID`);

--
-- Indexes for table `SubmittedForm`
--
ALTER TABLE `SubmittedForm`
 ADD PRIMARY KEY (`ID`), ADD KEY `SubmittedByID` (`SubmittedByID`), ADD KEY `ParentID` (`ParentID`), ADD KEY `ClassName` (`ClassName`);

--
-- Indexes for table `SubmittedFormField`
--
ALTER TABLE `SubmittedFormField`
 ADD PRIMARY KEY (`ID`), ADD KEY `ParentID` (`ParentID`), ADD KEY `ClassName` (`ClassName`);

--
-- Indexes for table `TagCloudWidget`
--
ALTER TABLE `TagCloudWidget`
 ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `TeamPerson`
--
ALTER TABLE `TeamPerson`
 ADD PRIMARY KEY (`ID`), ADD KEY `PhotoID` (`PhotoID`), ADD KEY `PageID` (`PageID`), ADD KEY `ClassName` (`ClassName`);

--
-- Indexes for table `Testimonial`
--
ALTER TABLE `Testimonial`
 ADD PRIMARY KEY (`ID`), ADD KEY `PhotoID` (`PhotoID`), ADD KEY `ClassName` (`ClassName`);

--
-- Indexes for table `TimelineItem`
--
ALTER TABLE `TimelineItem`
 ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `TimelineItem_Live`
--
ALTER TABLE `TimelineItem_Live`
 ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `TimelineItem_versions`
--
ALTER TABLE `TimelineItem_versions`
 ADD PRIMARY KEY (`ID`), ADD UNIQUE KEY `RecordID_Version` (`RecordID`,`Version`), ADD KEY `RecordID` (`RecordID`), ADD KEY `Version` (`Version`);

--
-- Indexes for table `TimelinePage`
--
ALTER TABLE `TimelinePage`
 ADD PRIMARY KEY (`ID`), ADD KEY `ParentID` (`ParentID`);

--
-- Indexes for table `TimelinePage_Live`
--
ALTER TABLE `TimelinePage_Live`
 ADD PRIMARY KEY (`ID`), ADD KEY `ParentID` (`ParentID`);

--
-- Indexes for table `TimelinePage_versions`
--
ALTER TABLE `TimelinePage_versions`
 ADD PRIMARY KEY (`ID`), ADD UNIQUE KEY `RecordID_Version` (`RecordID`,`Version`), ADD KEY `RecordID` (`RecordID`), ADD KEY `Version` (`Version`), ADD KEY `ParentID` (`ParentID`);

--
-- Indexes for table `UserDefinedForm`
--
ALTER TABLE `UserDefinedForm`
 ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `UserDefinedForm_EmailRecipient`
--
ALTER TABLE `UserDefinedForm_EmailRecipient`
 ADD PRIMARY KEY (`ID`), ADD KEY `FormID` (`FormID`), ADD KEY `SendEmailFromFieldID` (`SendEmailFromFieldID`), ADD KEY `SendEmailToFieldID` (`SendEmailToFieldID`), ADD KEY `SendEmailSubjectFieldID` (`SendEmailSubjectFieldID`), ADD KEY `ClassName` (`ClassName`);

--
-- Indexes for table `UserDefinedForm_Live`
--
ALTER TABLE `UserDefinedForm_Live`
 ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `UserDefinedForm_versions`
--
ALTER TABLE `UserDefinedForm_versions`
 ADD PRIMARY KEY (`ID`), ADD UNIQUE KEY `RecordID_Version` (`RecordID`,`Version`), ADD KEY `RecordID` (`RecordID`), ADD KEY `Version` (`Version`);

--
-- Indexes for table `VirtualPage`
--
ALTER TABLE `VirtualPage`
 ADD PRIMARY KEY (`ID`), ADD KEY `CopyContentFromID` (`CopyContentFromID`);

--
-- Indexes for table `VirtualPage_Live`
--
ALTER TABLE `VirtualPage_Live`
 ADD PRIMARY KEY (`ID`), ADD KEY `CopyContentFromID` (`CopyContentFromID`);

--
-- Indexes for table `VirtualPage_versions`
--
ALTER TABLE `VirtualPage_versions`
 ADD PRIMARY KEY (`ID`), ADD UNIQUE KEY `RecordID_Version` (`RecordID`,`Version`), ADD KEY `RecordID` (`RecordID`), ADD KEY `Version` (`Version`), ADD KEY `CopyContentFromID` (`CopyContentFromID`);

--
-- Indexes for table `Widget`
--
ALTER TABLE `Widget`
 ADD PRIMARY KEY (`ID`), ADD KEY `ParentID` (`ParentID`), ADD KEY `ClassName` (`ClassName`);

--
-- Indexes for table `WidgetArea`
--
ALTER TABLE `WidgetArea`
 ADD PRIMARY KEY (`ID`), ADD KEY `ClassName` (`ClassName`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `AboutPage`
--
ALTER TABLE `AboutPage`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `AboutPage_Live`
--
ALTER TABLE `AboutPage_Live`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `AboutPage_Testimonials`
--
ALTER TABLE `AboutPage_Testimonials`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `AboutPage_versions`
--
ALTER TABLE `AboutPage_versions`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=33;
--
-- AUTO_INCREMENT for table `ArchiveWidget`
--
ALTER TABLE `ArchiveWidget`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `BannerSlider`
--
ALTER TABLE `BannerSlider`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `Blog`
--
ALTER TABLE `Blog`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `BlogArchiveWidget`
--
ALTER TABLE `BlogArchiveWidget`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `BlogCategoriesWidget`
--
ALTER TABLE `BlogCategoriesWidget`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `BlogCategory`
--
ALTER TABLE `BlogCategory`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `BlogCategory_Entries`
--
ALTER TABLE `BlogCategory_Entries`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `BlogEntry`
--
ALTER TABLE `BlogEntry`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `BlogEntryWidget`
--
ALTER TABLE `BlogEntryWidget`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `BlogEntry_Live`
--
ALTER TABLE `BlogEntry_Live`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `BlogEntry_versions`
--
ALTER TABLE `BlogEntry_versions`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `BlogHolder`
--
ALTER TABLE `BlogHolder`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `BlogHolder_Live`
--
ALTER TABLE `BlogHolder_Live`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `BlogHolder_versions`
--
ALTER TABLE `BlogHolder_versions`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `BlogPost`
--
ALTER TABLE `BlogPost`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=30;
--
-- AUTO_INCREMENT for table `BlogPost_Authors`
--
ALTER TABLE `BlogPost_Authors`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `BlogPost_Categories`
--
ALTER TABLE `BlogPost_Categories`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `BlogPost_Live`
--
ALTER TABLE `BlogPost_Live`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=30;
--
-- AUTO_INCREMENT for table `BlogPost_Tags`
--
ALTER TABLE `BlogPost_Tags`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `BlogPost_versions`
--
ALTER TABLE `BlogPost_versions`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `BlogRecentPostsWidget`
--
ALTER TABLE `BlogRecentPostsWidget`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `BlogTag`
--
ALTER TABLE `BlogTag`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `BlogTagsWidget`
--
ALTER TABLE `BlogTagsWidget`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `BlogTree`
--
ALTER TABLE `BlogTree`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `BlogTree_Live`
--
ALTER TABLE `BlogTree_Live`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `BlogTree_versions`
--
ALTER TABLE `BlogTree_versions`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `Blog_Contributors`
--
ALTER TABLE `Blog_Contributors`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Blog_Editors`
--
ALTER TABLE `Blog_Editors`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Blog_Live`
--
ALTER TABLE `Blog_Live`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `Blog_versions`
--
ALTER TABLE `Blog_versions`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `Blog_Writers`
--
ALTER TABLE `Blog_Writers`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Box`
--
ALTER TABLE `Box`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `Comment`
--
ALTER TABLE `Comment`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `ContactAttribute`
--
ALTER TABLE `ContactAttribute`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `ContactPage`
--
ALTER TABLE `ContactPage`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `ContactPage_Live`
--
ALTER TABLE `ContactPage_Live`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `ContactPage_versions`
--
ALTER TABLE `ContactPage_versions`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `EditableFormField`
--
ALTER TABLE `EditableFormField`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `EditableFormField_Live`
--
ALTER TABLE `EditableFormField_Live`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `EditableFormField_versions`
--
ALTER TABLE `EditableFormField_versions`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT for table `EditableOption`
--
ALTER TABLE `EditableOption`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `EditableOption_Live`
--
ALTER TABLE `EditableOption_Live`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `EditableOption_versions`
--
ALTER TABLE `EditableOption_versions`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `ErrorPage`
--
ALTER TABLE `ErrorPage`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `ErrorPage_Live`
--
ALTER TABLE `ErrorPage_Live`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `ErrorPage_versions`
--
ALTER TABLE `ErrorPage_versions`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `File`
--
ALTER TABLE `File`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=45;
--
-- AUTO_INCREMENT for table `Group`
--
ALTER TABLE `Group`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `Group_Members`
--
ALTER TABLE `Group_Members`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `Group_Roles`
--
ALTER TABLE `Group_Roles`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `HelpArticle`
--
ALTER TABLE `HelpArticle`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=28;
--
-- AUTO_INCREMENT for table `HelpArticle_Live`
--
ALTER TABLE `HelpArticle_Live`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=28;
--
-- AUTO_INCREMENT for table `HelpArticle_versions`
--
ALTER TABLE `HelpArticle_versions`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `HelpCategory`
--
ALTER TABLE `HelpCategory`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `HelpCategory_HelpArticles`
--
ALTER TABLE `HelpCategory_HelpArticles`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `HelpPage`
--
ALTER TABLE `HelpPage`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT for table `HelpPage_Live`
--
ALTER TABLE `HelpPage_Live`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT for table `HelpPage_versions`
--
ALTER TABLE `HelpPage_versions`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `HomePage`
--
ALTER TABLE `HomePage`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `HomePage_Live`
--
ALTER TABLE `HomePage_Live`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `HomePage_Testimonials`
--
ALTER TABLE `HomePage_Testimonials`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `HomePage_versions`
--
ALTER TABLE `HomePage_versions`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT for table `Image`
--
ALTER TABLE `Image`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=45;
--
-- AUTO_INCREMENT for table `LoginAttempt`
--
ALTER TABLE `LoginAttempt`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Member`
--
ALTER TABLE `Member`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `MemberPassword`
--
ALTER TABLE `MemberPassword`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `Page`
--
ALTER TABLE `Page`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=30;
--
-- AUTO_INCREMENT for table `PageImage`
--
ALTER TABLE `PageImage`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=43;
--
-- AUTO_INCREMENT for table `Page_Live`
--
ALTER TABLE `Page_Live`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=30;
--
-- AUTO_INCREMENT for table `Page_versions`
--
ALTER TABLE `Page_versions`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=171;
--
-- AUTO_INCREMENT for table `Permission`
--
ALTER TABLE `Permission`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `PermissionRole`
--
ALTER TABLE `PermissionRole`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `PermissionRoleCode`
--
ALTER TABLE `PermissionRoleCode`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `PortfolioCategory`
--
ALTER TABLE `PortfolioCategory`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `PortfolioCategory_PortfolioItems`
--
ALTER TABLE `PortfolioCategory_PortfolioItems`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT for table `PortfolioItem`
--
ALTER TABLE `PortfolioItem`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `PortfolioItem_Live`
--
ALTER TABLE `PortfolioItem_Live`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `PortfolioItem_RelatedItems`
--
ALTER TABLE `PortfolioItem_RelatedItems`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `PortfolioItem_Testimonials`
--
ALTER TABLE `PortfolioItem_Testimonials`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `PortfolioItem_versions`
--
ALTER TABLE `PortfolioItem_versions`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `PortfolioPage`
--
ALTER TABLE `PortfolioPage`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `PortfolioPage_Live`
--
ALTER TABLE `PortfolioPage_Live`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `PortfolioPage_versions`
--
ALTER TABLE `PortfolioPage_versions`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `RedirectorPage`
--
ALTER TABLE `RedirectorPage`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=29;
--
-- AUTO_INCREMENT for table `RedirectorPage_Live`
--
ALTER TABLE `RedirectorPage_Live`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=29;
--
-- AUTO_INCREMENT for table `RedirectorPage_versions`
--
ALTER TABLE `RedirectorPage_versions`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `RSSWidget`
--
ALTER TABLE `RSSWidget`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `SiteConfig`
--
ALTER TABLE `SiteConfig`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `SiteConfig_CreateTopLevelGroups`
--
ALTER TABLE `SiteConfig_CreateTopLevelGroups`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `SiteConfig_EditorGroups`
--
ALTER TABLE `SiteConfig_EditorGroups`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `SiteConfig_ViewerGroups`
--
ALTER TABLE `SiteConfig_ViewerGroups`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `SiteTree`
--
ALTER TABLE `SiteTree`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=30;
--
-- AUTO_INCREMENT for table `SiteTree_EditorGroups`
--
ALTER TABLE `SiteTree_EditorGroups`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `SiteTree_ImageTracking`
--
ALTER TABLE `SiteTree_ImageTracking`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `SiteTree_LinkTracking`
--
ALTER TABLE `SiteTree_LinkTracking`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `SiteTree_Live`
--
ALTER TABLE `SiteTree_Live`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=30;
--
-- AUTO_INCREMENT for table `SiteTree_versions`
--
ALTER TABLE `SiteTree_versions`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=179;
--
-- AUTO_INCREMENT for table `SiteTree_ViewerGroups`
--
ALTER TABLE `SiteTree_ViewerGroups`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `SubmittedFileField`
--
ALTER TABLE `SubmittedFileField`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `SubmittedForm`
--
ALTER TABLE `SubmittedForm`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `SubmittedFormField`
--
ALTER TABLE `SubmittedFormField`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `TagCloudWidget`
--
ALTER TABLE `TagCloudWidget`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `TeamPerson`
--
ALTER TABLE `TeamPerson`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `Testimonial`
--
ALTER TABLE `Testimonial`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `TimelineItem`
--
ALTER TABLE `TimelineItem`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT for table `TimelineItem_Live`
--
ALTER TABLE `TimelineItem_Live`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT for table `TimelineItem_versions`
--
ALTER TABLE `TimelineItem_versions`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `TimelinePage`
--
ALTER TABLE `TimelinePage`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `TimelinePage_Live`
--
ALTER TABLE `TimelinePage_Live`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `TimelinePage_versions`
--
ALTER TABLE `TimelinePage_versions`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `UserDefinedForm`
--
ALTER TABLE `UserDefinedForm`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `UserDefinedForm_EmailRecipient`
--
ALTER TABLE `UserDefinedForm_EmailRecipient`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `UserDefinedForm_Live`
--
ALTER TABLE `UserDefinedForm_Live`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `UserDefinedForm_versions`
--
ALTER TABLE `UserDefinedForm_versions`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `VirtualPage`
--
ALTER TABLE `VirtualPage`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `VirtualPage_Live`
--
ALTER TABLE `VirtualPage_Live`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `VirtualPage_versions`
--
ALTER TABLE `VirtualPage_versions`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `Widget`
--
ALTER TABLE `Widget`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `WidgetArea`
--
ALTER TABLE `WidgetArea`
MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=19;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
